# Replit setup prompt for Royal Rewards

Paste this into Replit Agent after importing this ZIP:

> This is an existing Royal Rewards project built with Next.js 16, React 19, Drizzle ORM and PostgreSQL. Do not recreate it, replace its design, remove features, or generate fake users/transactions. Inspect the current files first.
>
> 1. Install dependencies from package.json, including devDependencies needed for the Next.js build.
> 2. Confirm the app starts with `npm run dev -- --hostname 0.0.0.0` and listens on port 3000.
> 3. Confirm the Replit PostgreSQL database is provisioned and `DATABASE_URL` is available in Secrets. Never print or reveal its value.
> 4. Run `npx drizzle-kit push` using the supplied `drizzle.config.ts` and the `DATABASE_URL` secret. If Replit separates development and production databases, ensure the production database receives the schema too, using its production `DATABASE_URL` privately.
> 5. Run `npm run typecheck`, `npm run lint`, and `npm run build`. Fix actual errors without removing security checks or functionality.
> 6. Preserve all eight games, server-side game outcomes, user registration/login, wallet ledger, withdrawal/add-points approval, private conversations, notifications, audit log, and role-based admin permissions.
> 7. Preserve the Global Blessing / Curse control in Admin → Website Settings. It must adjust newly credited points according to the configured percentage, and the active event must be shown to players. Existing balances and refunds must not be changed.
> 8. Do not set `ADMIN_DEV_LOGIN_SECRET` or `INSECURE_COOKIES` in production. Do not add credentials to source files or chat.
> 9. Prepare a production deployment using the `.replit` deployment commands. Tell me which Secrets still need to be added and the exact public URL after publishing.
>
> Stop and explain any missing credentials or account authorization that only I can complete. Do not invent credentials or claim deployment succeeded before it actually does.

## Secrets to configure privately in Replit

- `DATABASE_URL` — required PostgreSQL connection string.
- `APP_URL` — public deployed URL, including `https://`.
- `OWNER_EMAIL` — your verified Google account email; this account receives the Owner role.
- `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET` — required for the Google admin login.
- `OPENAI_API_KEY` — optional; only for the AI admin assistant.

Set `OWNER_EMAIL` to the Google account you control before deployment. The Google OAuth authorized redirect URI must be:

`https://YOUR-PUBLISHED-DOMAIN/api/auth/google/callback`

The Google account configured in `OWNER_EMAIL` must sign in with a verified Google account to receive the Owner role.
