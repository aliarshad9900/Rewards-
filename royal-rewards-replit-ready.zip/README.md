# 👑 Royal Rewards

A gaming rewards platform built with Next.js 16 (App Router), PostgreSQL and Drizzle ORM. It has 8 games whose results are decided on the server, a wallet with a full ledger, withdrawal and add-points requests that admins must approve, a private chat for each request, notifications, a role-based admin panel and an AI admin assistant.

## Setup
```bash
npm install
cp .env.example .env         # set DATABASE_URL etc.
npx drizzle-kit push         # create tables (schema: src/db/schema.ts)
npm run build && npm start   # or npm run dev
```
Game settings are added to the database the first time someone uses them. The app ships with no demo data and no fake statistics.

## Environment variables
| Var | Required | Purpose |
|---|---|---|
| `DATABASE_URL` | yes | PostgreSQL connection string |
| `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET` | for admin | Google OAuth credentials. Authorized redirect URI: `https://YOUR_DOMAIN/api/auth/google/callback` |
| `APP_URL` | recommended | Public origin, used to build the OAuth redirect URI (e.g. `https://rewards.example.com`) |
| `OWNER_EMAIL` | recommended | Verified Google account that receives the Owner role. Defaults to the original project email if omitted. |
| `OPENAI_API_KEY` / `OPENAI_MODEL` | optional | Turns on the conversational AI assistant. Without it, the assistant uses built-in analytics. |
| `ADMIN_DEV_LOGIN_SECRET` | dev only | Secret of 12+ characters that turns on a developer owner login on /admin/login. **Never set this in production.** |
| `INSECURE_COOKIES=1` | dev only | Lets cookies work over plain http when running in production mode on localhost |

## Admin access
* Only a verified Google login matching `OWNER_EMAIL` gets the Owner role. Set `OWNER_EMAIL` to the Google account you control before production. The server confirms the identity with Google and requires `email_verified`.
* The owner can invite Admins (with chosen permissions) or Support staff (chat only) from **Administrators**. Invited people sign in with Google.
* Permission checks run on the server for every admin page, server action and API route.

## Security
* Passwords: scrypt with a salt. Sessions: random tokens stored as SHA-256 hashes in httpOnly cookies, expiring after 7 days for users and 12 hours for admins.
* Every wallet change goes through `walletChange()` inside a DB transaction with `SELECT … FOR UPDATE`, and every change is recorded in `transactions` with a unique ID.
* Game outcomes are picked on the server with `crypto.randomInt` **when the round starts** and stored on the server. Refreshing the page resumes the same round, so you can't reroll. A finished session can't be replayed (409). Memory Match checks every flip on the server.
* Daily attempt limits, rate limits (login, register, games, chat, requests), idempotency keys on requests, and automatic flagging of suspicious game activity.
* Password reset: the user asks for a reset, an admin checks who they are and issues a one-time code (stored hashed, valid for 1 hour), and the user sets a new password at `/forgot`.
* All inputs are cleaned and checked on the server. Every admin action is written to the audit log.

## Testing checklist
1. Register at `/register`, note your User Number (RR1000xx), and check the 250-point bonus.
2. Sign out, then sign back in with your User Number and password.
3. Play all 8 games from `/app/games`. Check `/app/history` for entries, wins and refunds.
4. Redeem 50 Robux. 450 points are held, and you're taken to the chat for `#WR…`.
5. As admin, open **Conversations**: reply, add an internal note (the user can't see it), approve, reject or complete. Rejecting returns the held points.
6. Request points at `/app/add-points`. The balance only changes after an admin approves.
7. Try `/admin` without signing in (redirects to login), and call admin APIs with a user session (403).
8. Resize to mobile width: you get a bottom nav for players and a menu drawer for admins.

## Replit deployment
1. Import this ZIP into a new Replit App.
2. Add a Replit PostgreSQL database and copy its connection URL into the Secrets tool as `DATABASE_URL`.
3. Add `APP_URL` after deployment, using the public Replit URL.
4. Add `OWNER_EMAIL` with the verified Google account that should own the admin panel.
5. Add `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET` as Secrets if Google admin sign-in is needed. Set the OAuth callback to `https://YOUR_REPLIT_DOMAIN/api/auth/google/callback`.
6. Run `npx drizzle-kit push` against the database used by the published app, then use Deploy. If Replit provides separate development and production databases, ensure the production database schema is pushed too.
7. Never set `ADMIN_DEV_LOGIN_SECRET` or `INSECURE_COOKIES` for production.

The admin Settings page includes a global Blessing / Curse event. It adjusts newly credited points (game wins, daily rewards, welcome bonuses, approved add-points and positive admin grants). Existing balances and refunds are not changed. Players see an in-app banner and notification when the event changes.

## Deployment
Deploy to any Node host (Vercel, Railway, Render, a VPS) with managed PostgreSQL. Set the environment variables above, run `npx drizzle-kit push` once, then `npm run build && npm start`. Add your production callback URL to the Google OAuth client.

## Notes
* Robux redemptions are reviewed and fulfilled by hand. Nothing is ever marked paid automatically. Only offer them if the reward method is permitted for your use. The site isn't affiliated with Roblox.
* File attachments in chat are left out on purpose, because accepting uploads safely needs separate storage and malware scanning.
