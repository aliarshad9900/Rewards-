export function Flash({ sp }: { sp: { msg?: string; err?: string } }) {
  if (sp.msg) return <div className="card p-3 mb-4 !border-green-500/50 text-green-300 text-sm break-words">✅ {sp.msg}</div>;
  if (sp.err) return <div className="card p-3 mb-4 !border-red-500/50 text-red-300 text-sm">❌ {sp.err}</div>;
  return null;
}
