"use client";
import { useState } from "react";
type O = { label: string; kind: string; reward: number; prob: number };
type G = { key: string; enabled: boolean; entryCost: number; dailyLimit: number; instructions: string; config: Record<string, unknown> };
const FIELDS: Record<string, [string, string][]> = {
  box: [["boxCount", "Number of boxes"]], bunny: [["boxes", "Number of boxes"], ["reward", "Reward (pts)"]],
  lucky: [["max", "Number range (1..N)"], ["reward", "Exact-match reward"], ["nearReward", "Off-by-one reward (0 = off)"]],
  memory: [["pairs", "Pairs (2–12)"], ["reward", "Completion reward"], ["maxMoves", "Max moves to win"]],
  treasure: [["chests", "Number of chests"]], cards: [["cards", "Number of cards"]],
};
export function GameEditor({ g, action }: { g: G; action: (fd: FormData) => void }) {
  const [cfg, setCfg] = useState<Record<string, unknown>>(g.config);
  const outs = cfg.outcomes as O[] | undefined;
  const total = outs ? outs.reduce((s, o) => s + Number(o.prob || 0), 0) : 100;
  const setO = (i: number, k: keyof O, v: string) => { const n = [...outs!]; n[i] = { ...n[i], [k]: k === "label" || k === "kind" ? v : Number(v) }; setCfg({ ...cfg, outcomes: n }); };
  return (
    <form action={action} className="space-y-4">
      <input type="hidden" name="key" value={g.key} /><input type="hidden" name="config" value={JSON.stringify(cfg)} />
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 items-end">
        <label className="flex items-center gap-2"><input type="checkbox" name="enabled" defaultChecked={g.enabled} className="w-5 h-5 accent-amber-400" /> Enabled</label>
        <div><label className="label">Entry cost</label><input name="entryCost" type="number" min={0} defaultValue={g.entryCost} className="input" /></div>
        <div><label className="label">Daily attempt limit (0 = ∞)</label><input name="dailyLimit" type="number" min={0} defaultValue={g.dailyLimit} className="input" /></div>
        {(FIELDS[g.key] ?? []).map(([k, l]) => <div key={k}><label className="label">{l}</label><input type="number" value={String(cfg[k] ?? 0)} onChange={(e) => setCfg({ ...cfg, [k]: Number(e.target.value) })} className="input" /></div>)}
        {g.key === "box" && <div><label className="label">Box design</label><select className="input" value={String(cfg.boxStyle ?? "mixed")} onChange={(e) => setCfg({ ...cfg, boxStyle: e.target.value })}><option value="mixed">Purple & gold</option><option value="gold">All gold</option><option value="purple">All purple</option></select></div>}
        {g.key === "daily" && <label className="flex items-center gap-2"><input type="checkbox" checked={!!cfg.resetOnMiss} onChange={(e) => setCfg({ ...cfg, resetOnMiss: e.target.checked })} className="w-5 h-5 accent-amber-400" /> Missing a day resets streak</label>}
      </div>
      {g.key === "daily" && <div><label className="label">Rewards for days 1–7</label><div className="grid grid-cols-4 md:grid-cols-7 gap-2">{(cfg.rewards as number[]).map((r, i) => <input key={i} type="number" value={r} onChange={(e) => { const n = [...(cfg.rewards as number[])]; n[i] = Number(e.target.value); setCfg({ ...cfg, rewards: n }); }} className="input" />)}</div></div>}
      {outs && <div className="overflow-x-auto"><table className="table min-w-[520px]"><thead><tr><th>Label</th><th>Kind</th><th>Reward</th><th>Probability %</th><th></th></tr></thead><tbody>
        {outs.map((o, i) => <tr key={i}><td><input className="input !py-1" value={o.label} onChange={(e) => setO(i, "label", e.target.value)} /></td><td><select className="input !py-1" value={o.kind} onChange={(e) => setO(i, "kind", e.target.value)}><option value="lose">Lose</option><option value="refund">Money back</option><option value="win">Win</option></select></td><td><input type="number" className="input !py-1 w-24" value={o.reward} disabled={o.kind !== "win"} onChange={(e) => setO(i, "reward", e.target.value)} /></td><td><input type="number" step="0.01" className="input !py-1 w-24" value={o.prob} onChange={(e) => setO(i, "prob", e.target.value)} /></td><td><button type="button" className="text-red-400" onClick={() => setCfg({ ...cfg, outcomes: outs.filter((_, j) => j !== i) })}>✕</button></td></tr>)}
      </tbody></table><div className="flex justify-between items-center mt-2"><button type="button" className="btn-ghost !py-1 text-sm" onClick={() => setCfg({ ...cfg, outcomes: [...outs, { label: "New", kind: "lose", reward: 0, prob: 0 }] })}>+ Outcome</button><span className={`text-sm font-bold ${Math.abs(total - 100) < 1e-9 ? "text-green-400" : "text-red-400"}`}>Total: {Math.round(total * 100) / 100}%</span></div></div>}
      <div><label className="label">Instructions shown to players</label><textarea name="instructions" defaultValue={g.instructions} className="input min-h-20" /></div>
      <button className="btn-gold">Save {g.key}</button>
    </form>
  );
}
