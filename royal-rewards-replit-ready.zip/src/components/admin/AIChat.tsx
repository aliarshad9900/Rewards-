"use client";
import { useState } from "react";
type M = { role: "you" | "ai"; text: string; action?: Record<string, string> | null };
const QUICK = ["Analyse game statistics", "Detect unusual activity", "Explain pending requests", "Suggest reward balance improvements", "Help me understand settings", "Draft announcement: new weekend bonus"];
export function AIChat() {
  const [ms, setMs] = useState<M[]>([]); const [q, setQ] = useState(""); const [busy, setBusy] = useState(false);
  async function ask(text: string) { if (!text.trim()) return; setMs((m) => [...m, { role: "you", text }]); setQ(""); setBusy(true);
    const r = await fetch("/api/admin/ai", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message: text }) }); const j = await r.json(); setBusy(false);
    setMs((m) => [...m, { role: "ai", text: r.ok ? j.reply : "⚠️ " + j.error, action: j.action }]); }
  async function apply(a: Record<string, string>) { if (!confirm("Apply this ordinary action?")) return; const r = await fetch("/api/admin/ai", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ apply: a }) }); const j = await r.json(); setMs((m) => [...m, { role: "ai", text: r.ok ? "✅ " + j.message : "🔒 " + j.error }]); }
  return (
    <div className="card flex flex-col h-[calc(100vh-12rem)] min-h-[480px]">
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {!ms.length && <div className="text-center text-gray-400 py-10"><div className="text-6xl mb-3 anim-float">🤖</div><p>Ask me about game statistics, unusual activity, pending requests or settings.</p><p className="text-xs mt-2">I can never approve withdrawals, send rewards, change points, permissions or financial policies.</p></div>}
        {ms.map((m, i) => <div key={i} className={`flex ${m.role === "you" ? "justify-end" : ""}`}><div className={`max-w-[85%] rounded-2xl px-4 py-2 text-sm whitespace-pre-wrap ${m.role === "you" ? "bg-gradient-to-br from-amber-400 to-yellow-600 text-black" : "bg-white/5 border border-gold/20"}`}>{m.text}
          {m.action && <div className="mt-2 p-2 rounded-lg bg-black/40 border border-gold/30"><div className="text-xs text-gold">Proposed action: {m.action.type}</div><div className="text-xs text-gray-300">{m.action.title ?? m.action.key} {m.action.body}</div><button onClick={() => apply(m.action!)} className="btn-gold !py-1 !px-3 text-xs mt-2">Apply (requires your confirmation)</button></div>}</div></div>)}
        {busy && <div className="text-gray-400 text-sm animate-pulse">Analysing…</div>}
      </div>
      <div className="p-3 border-t border-white/10 space-y-2"><div className="flex gap-2 overflow-x-auto pb-1">{QUICK.map((x) => <button key={x} onClick={() => ask(x)} className="btn-ghost !py-1 !px-3 text-xs whitespace-nowrap">{x}</button>)}</div>
        <form onSubmit={(e) => { e.preventDefault(); ask(q); }} className="flex gap-2"><input value={q} onChange={(e) => setQ(e.target.value)} className="input" placeholder="Ask the assistant…" /><button className="btn-gold" disabled={busy}>Ask</button></form></div>
    </div>
  );
}
