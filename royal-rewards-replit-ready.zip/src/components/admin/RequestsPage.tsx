import Link from "next/link";
import { db } from "@/db";
import { conversations, requests, users, wallets } from "@/db/schema";
import { and, desc, eq } from "drizzle-orm";
import { PageTitle, Status, fmt } from "@/components/bits";
import { Flash } from "./Flash";
import { requestStatus } from "@/app/admin/actions";

const NEXT: Record<string, string[]> = { pending: ["under_review", "approved", "rejected"], under_review: ["approved", "rejected"], approved: ["completed", "rejected"], rejected: [], completed: [] };
const L: Record<string, string> = { under_review: "Review", approved: "Approve", rejected: "Reject", completed: "Complete" };

export async function RequestsPage({ kind, sp }: { kind: "withdrawal" | "add_points"; sp: { status?: string; msg?: string; err?: string } }) {
  const base = kind === "withdrawal" ? "/admin/withdrawals" : "/admin/add-points";
  const rows = await db.select({ r: requests, u: users, w: wallets, c: conversations.id }).from(requests).innerJoin(users, eq(users.id, requests.userId)).innerJoin(wallets, eq(wallets.userId, users.id)).leftJoin(conversations, eq(conversations.requestId, requests.id))
    .where(and(eq(requests.kind, kind), sp.status ? eq(requests.status, sp.status) : undefined)).orderBy(desc(requests.createdAt)).limit(200);
  return (
    <div><PageTitle title={kind === "withdrawal" ? "Withdrawal Requests" : "Add Points Requests"} sub={kind === "withdrawal" ? "Points are reserved on submission and returned on rejection. Mark completed only after manually fulfilling the reward." : "Points are added only when you approve. Every decision is audited."} icon={kind === "withdrawal" ? "💸" : "➕"} />
      <Flash sp={sp} />
      <div className="flex flex-wrap gap-2 mb-4">{["", "pending", "under_review", "approved", "rejected", "completed"].map((s) => <Link key={s} href={s ? `${base}?status=${s}` : base} className={(sp.status ?? "") === s ? "btn-gold !py-1.5 text-sm" : "btn-ghost !py-1.5 text-sm"}>{s ? s.replace("_", " ") : "All"}</Link>)}</div>
      <div className="space-y-3">{rows.map(({ r, u, w, c }) => (
        <div key={r.id} className="card p-4 grid md:grid-cols-[1fr_auto] gap-3">
          <div className="space-y-1"><div className="flex items-center gap-3"><span className="font-black text-gold">#{r.code}</span><Status s={r.status} /><span className="text-xs text-gray-500">{fmt(r.createdAt)}</span></div>
            <div className="text-sm">{kind === "withdrawal" ? <>Requested: <b>{r.robux} Robux</b> · Points: <b className="text-gold">{r.points}</b></> : <>Requested points: <b className="text-gold">{r.points}</b></>}</div>
            <div className="text-sm text-gray-400">User: <Link className="text-gold" href={`/admin/users?id=${u.id}`}>{u.userNumber}</Link> ({u.username}) · balance {w.available} {u.flagged && "⚠️ flagged"}</div>
            {r.userNote && <div className="text-sm text-gray-300">User note: “{r.userNote}”</div>}{r.adminNote && <div className="text-sm text-amber-300">Admin note: {r.adminNote}</div>}</div>
          <div className="flex flex-col gap-2 md:w-72">{c && <Link href={`/admin/conversations/${c}`} className="btn-ghost text-sm">💬 Open conversation</Link>}
            {NEXT[r.status].length > 0 && <form action={requestStatus} className="space-y-2"><input type="hidden" name="id" value={r.id} /><input type="hidden" name="back" value={base + (sp.status ? `?status=${sp.status}` : "")} /><input name="note" placeholder="Admin note (optional)" className="input !py-1.5 text-sm" />
              <div className="flex flex-wrap gap-1">{NEXT[r.status].map((s) => <button key={s} name="status" value={s} className={`${s === "rejected" ? "btn-danger" : s === "under_review" ? "btn-ghost" : "btn-gold"} !py-1 !px-3 text-xs flex-1`}>{L[s]}</button>)}</div></form>}</div>
        </div>))}
        {!rows.length && <p className="text-gray-500">No requests.</p>}</div>
    </div>
  );
}
