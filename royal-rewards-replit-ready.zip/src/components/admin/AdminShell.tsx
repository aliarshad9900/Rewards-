"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";

const NAV = [
  { href: "/admin", label: "Dashboard", icon: "📊", p: null },
  { href: "/admin/users", label: "Users", icon: "👥", p: "users" },
  { href: "/admin/wallets", label: "Wallets", icon: "👛", p: "wallets" },
  { href: "/admin/games", label: "Games", icon: "🎮", p: "games" },
  { href: "/admin/withdrawals", label: "Withdrawal Requests", icon: "💸", p: "requests" },
  { href: "/admin/add-points", label: "Add Points Requests", icon: "➕", p: "requests" },
  { href: "/admin/conversations", label: "Conversations", icon: "💬", p: "chat" },
  { href: "/admin/notifications", label: "Notifications", icon: "🔔", p: null },
  { href: "/admin/settings", label: "Website Settings", icon: "⚙️", p: "settings" },
  { href: "/admin/ai", label: "AI Assistant", icon: "🤖", p: "ai" },
  { href: "/admin/admins", label: "Administrators", icon: "🛡️", p: "owner" },
  { href: "/admin/audit", label: "Audit Logs", icon: "📜", p: "audit" },
];

export function AdminShell({ children, perms, email, role, unread, unreadChats }: { children: React.ReactNode; perms: string[]; email: string; role: string; unread: number; unreadChats: number }) {
  const path = usePathname(); const r = useRouter(); const [open, setOpen] = useState(false);
  const items = NAV.filter((n) => !n.p || perms.includes(n.p));
  const active = (h: string) => (h === "/admin" ? path === "/admin" : path.startsWith(h));
  async function logout() { await fetch("/api/auth/admin-logout", { method: "POST" }); r.push("/admin/login"); }
  const nav = (
    <nav className="space-y-1">
      {items.map((n) => <Link key={n.href} href={n.href} onClick={() => setOpen(false)} className={`flex items-center gap-3 px-3 py-2 rounded-xl text-sm ${active(n.href) ? "bg-gold/15 text-gold border border-gold/30" : "text-gray-300 hover:bg-white/5"}`}><span className="w-5 text-center">{n.icon}</span><span className="flex-1">{n.label}</span>
        {n.href === "/admin/notifications" && unread > 0 && <span className="badge bg-red-500 text-white">{unread}</span>}
        {n.href === "/admin/conversations" && unreadChats > 0 && <span className="badge bg-red-500 text-white">{unreadChats}</span>}</Link>)}
      <button onClick={logout} className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-sm text-gray-400 hover:bg-red-950/40"><span className="w-5">🚪</span>Logout</button>
    </nav>
  );
  return (
    <div className="min-h-screen lg:pl-64">
      <aside className="hidden lg:block fixed inset-y-0 left-0 w-64 overflow-y-auto border-r border-white/5 bg-black/50 backdrop-blur-xl p-4">
        <div className="mb-6"><div className="font-royal font-black text-lg text-gold-grad">👑 ROYAL ADMIN</div><div className="text-[11px] text-gray-500 truncate">{email}</div><span className="badge bg-gold/20 text-gold mt-1">{role}</span></div>{nav}
      </aside>
      <header className="lg:hidden sticky top-0 z-30 h-14 flex items-center justify-between px-4 bg-black/80 backdrop-blur-xl border-b border-white/5">
        <span className="font-royal font-black text-gold-grad">👑 ROYAL ADMIN</span>
        <button onClick={() => setOpen(!open)} className="btn-ghost !py-1 !px-3">{open ? "✕" : "☰"} {unread + unreadChats > 0 && <span className="badge bg-red-500 text-white">{unread + unreadChats}</span>}</button>
      </header>
      {open && <div className="lg:hidden fixed inset-x-0 top-14 bottom-0 z-30 bg-black/95 p-4 overflow-y-auto">{nav}</div>}
      <main key={path} className="p-4 lg:p-8 max-w-7xl mx-auto anim-fade">{children}</main>
    </div>
  );
}
