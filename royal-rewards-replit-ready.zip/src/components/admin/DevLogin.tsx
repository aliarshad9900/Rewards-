"use client";
import { useState } from "react";
export function DevLogin() {
  const [k, setK] = useState(""); const [e, setE] = useState("");
  return <form className="border-t border-white/10 pt-4 space-y-2 text-left" onSubmit={async (ev) => { ev.preventDefault(); const r = await fetch("/api/auth/admin-dev", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ key: k }) }); if (r.ok) location.href = "/admin"; else setE((await r.json()).error); }}>
    <label className="label">Developer owner key (testing only)</label><input type="password" className="input" value={k} onChange={(x) => setK(x.target.value)} />{e && <p className="text-red-400 text-xs">{e}</p>}<button className="btn-ghost w-full">Developer sign-in</button><p className="text-[10px] text-gray-500">Enabled because ADMIN_DEV_LOGIN_SECRET is set. Remove it in production.</p></form>;
}
