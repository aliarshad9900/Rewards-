"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

export function AuthForm({ mode }: { mode: "login" | "register" | "forgot" }) {
  const r = useRouter();
  const [f, setF] = useState<Record<string, string>>({});
  const [err, setErr] = useState(""); const [msg, setMsg] = useState(""); const [busy, setBusy] = useState(false);
  const [created, setCreated] = useState("");
  const [step, setStep] = useState<"request" | "reset">("request");
  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setErr(""); setMsg(""); setBusy(true);
    const url = mode === "login" ? "/api/auth/login" : mode === "register" ? "/api/auth/register" : step === "request" ? "/api/auth/forgot" : "/api/auth/reset";
    try {
      const res = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(f) });
      const j = await res.json();
      if (!res.ok) throw new Error(j.error || "Failed");
      if (mode === "login") { r.push("/app"); r.refresh(); }
      else if (mode === "register") setCreated(j.userNumber);
      else if (step === "request") { setMsg(j.message); }
      else { setMsg("Password updated! You can now sign in."); }
    } catch (e) { setErr((e as Error).message); } finally { setBusy(false); }
  }

  if (created) return (
    <div className="text-center anim-pop">
      <div className="text-6xl mb-3">🎉</div>
      <h2 className="text-2xl font-bold mb-1">Account created!</h2>
      <p className="text-gray-400 mb-4">Your unique User Number — save it, you need it to sign in:</p>
      <div className="glow-gold rounded-2xl py-4 text-4xl font-black tracking-widest text-gold-grad mb-3">{created}</div>
      <p className="text-gold font-semibold mb-6">+250 welcome bonus points credited 👑</p>
      <button className="btn-gold w-full" onClick={() => { r.push("/app"); r.refresh(); }}>Enter Royal Rewards</button>
    </div>
  );

  return (
    <form onSubmit={submit} className="space-y-4">
      <h2 className="text-2xl font-bold">{mode === "login" ? "Sign in" : mode === "register" ? "Create account" : "Forgot password"}</h2>
      {mode === "login" && <>
        <div><label className="label">User Number</label><input className="input uppercase" placeholder="RR100001" required onChange={set("userNumber")} /></div>
        <div><label className="label">Password</label><input className="input" type="password" required onChange={set("password")} /></div>
      </>}
      {mode === "register" && <>
        <div><label className="label">Username</label><input className="input" required minLength={3} maxLength={20} onChange={set("username")} /></div>
        <div><label className="label">Password</label><input className="input" type="password" required minLength={8} onChange={set("password")} /></div>
        <div><label className="label">Confirm password</label><input className="input" type="password" required minLength={8} onChange={set("confirm")} /></div>
        <p className="text-xs text-gray-400">A unique User Number is generated for you automatically. New accounts receive a one-time welcome bonus.</p>
      </>}
      {mode === "forgot" && <>
        <div className="flex gap-2 text-sm">
          <button type="button" onClick={() => setStep("request")} className={step === "request" ? "btn-gold !py-1.5" : "btn-ghost !py-1.5"}>1. Request code</button>
          <button type="button" onClick={() => setStep("reset")} className={step === "reset" ? "btn-gold !py-1.5" : "btn-ghost !py-1.5"}>2. I have a code</button>
        </div>
        <div><label className="label">User Number</label><input className="input uppercase" required onChange={set("userNumber")} /></div>
        {step === "request" ? <div><label className="label">Username</label><input className="input" required onChange={set("username")} /></div> : <>
          <div><label className="label">One-time reset code (from admin)</label><input className="input" required onChange={set("code")} /></div>
          <div><label className="label">New password</label><input className="input" type="password" minLength={8} required onChange={set("password")} /></div>
        </>}
        <p className="text-xs text-gray-400">For security, an administrator verifies your identity and issues a one-time code valid for 1 hour.</p>
      </>}
      {err && <p className="text-red-400 text-sm bg-red-950/50 rounded-lg p-2">{err}</p>}
      {msg && <p className="text-green-300 text-sm bg-green-950/40 rounded-lg p-2">{msg}</p>}
      <button className="btn-gold w-full" disabled={busy}>{busy ? "Please wait…" : mode === "login" ? "Sign In" : mode === "register" ? "Create Account" : step === "request" ? "Request reset" : "Set new password"}</button>
      <div className="flex justify-between text-sm">
        {mode !== "login" ? <Link href="/login" className="text-gold hover:underline">← Back to sign in</Link> : <Link href="/forgot" className="text-gray-400 hover:text-gold">Forgot password?</Link>}
        {mode === "login" && <Link href="/register" className="btn-ghost !py-1 !px-3">Create Account</Link>}
      </div>
    </form>
  );
}
