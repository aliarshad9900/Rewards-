"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";

type Msg = { id: number; sender: string; senderName: string; body: string; createdAt: string; internal?: boolean };
type Req = { code: string; kind: string; points: number; robux: number | null; status: string; adminNote?: string | null } | null;
type Data = { conversation: { id: number; subject: string; status: string }; request: Req; messages: Msg[]; user?: { userNumber: string; username: string; id: number }; canManage?: boolean };
const LBL: Record<string, string> = { pending: "Pending", under_review: "Under Review", approved: "Approved", rejected: "Rejected", completed: "Completed" };
const NEXT: Record<string, string[]> = { pending: ["under_review", "approved", "rejected"], under_review: ["pending", "approved", "rejected"], approved: ["completed", "rejected"], rejected: [], completed: [] };

export function ChatClient({ id, admin = false }: { id: number; admin?: boolean }) {
  const url = admin ? `/api/admin/conversations/${id}` : `/api/conversations/${id}`;
  const [d, setD] = useState<Data | null>(null); const [text, setText] = useState(""); const [note, setNote] = useState(false);
  const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);
  const end = useRef<HTMLDivElement>(null); const lastCount = useRef(0);
  const load = useCallback(async () => { const r = await fetch(url); const j = await r.json(); if (!r.ok) { setErr(j.error); return; } setD(j); }, [url]);
  useEffect(() => { load(); const t = setInterval(load, 4000); return () => clearInterval(t); }, [load]);
  useEffect(() => { if (d && d.messages.length !== lastCount.current) { lastCount.current = d.messages.length; end.current?.scrollIntoView({ behavior: "smooth" }); } }, [d]);
  async function post(body: Record<string, unknown>) {
    setBusy(true); setErr("");
    const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const j = await r.json(); setBusy(false); if (!r.ok) { setErr(j.error); return false; } await load(); return true;
  }
  async function send(e: React.FormEvent) { e.preventDefault(); if (!text.trim()) return; const ok = await post(admin ? { action: note ? "note" : "send", body: text } : { body: text }); if (ok) setText(""); }
  if (err && !d) return <div className="card p-6 text-red-300">{err}</div>;
  if (!d) return <div className="card p-6 animate-pulse h-96" />;
  const r = d.request;
  return (
    <div className="grid lg:grid-cols-[1fr_300px] gap-4">
      <div className="card flex flex-col h-[calc(100vh-11rem)] min-h-[480px] overflow-hidden">
        <div className="p-4 border-b border-gold/20 bg-black/30">
          <Link href={admin ? "/admin/conversations" : "/app/messages"} className="text-xs text-gray-400 hover:text-gold">← All conversations</Link>
          <h2 className="font-bold text-lg text-gold">{d.conversation.subject}</h2>
          {r && <div className="text-sm text-gray-300 flex flex-wrap gap-x-4">{r.kind === "withdrawal" ? <span>Requested amount: <b className="text-gold">{r.robux} Robux</b> ({r.points} pts)</span> : <span>Requested points: <b className="text-gold">{r.points}</b></span>}<span>Status: <span className={`badge b-${r.status}`}>{LBL[r.status]}</span></span></div>}
          {admin && d.user && <div className="text-xs text-gray-400 mt-1">User: <Link className="text-gold" href={`/admin/users?q=${d.user.userNumber}`}>{d.user.userNumber}</Link> ({d.user.username})</div>}
        </div>
        <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-[radial-gradient(ellipse_at_top,rgba(120,40,200,.15),transparent)]">
          {d.messages.map((m) => {
            const mine = admin ? m.sender === "admin" : m.sender === "user";
            if (m.sender === "system") return <div key={m.id} className="mx-auto max-w-md text-center text-xs text-gray-300 bg-black/40 border border-gold/20 rounded-xl px-3 py-2 whitespace-pre-line">{m.body}<div className="text-[10px] text-gray-500 mt-1">{new Date(m.createdAt).toLocaleString()}</div></div>;
            return <div key={m.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}><div className={`max-w-[80%] rounded-2xl px-4 py-2 ${m.internal ? "bg-amber-950/70 border border-dashed border-amber-500/60" : mine ? "bg-gradient-to-br from-amber-400 to-yellow-600 text-black rounded-br-sm" : "bg-white/10 border border-gold/20 rounded-bl-sm"}`}>
              <div className={`text-[11px] font-bold ${mine && !m.internal ? "text-black/70" : "text-gold"}`}>{m.internal ? "🔒 Internal note · " : ""}{m.senderName}</div>
              <div className="whitespace-pre-wrap break-words text-sm">{m.body}</div>
              <div className={`text-[10px] mt-1 ${mine && !m.internal ? "text-black/60" : "text-gray-500"}`}>{new Date(m.createdAt).toLocaleString()}</div></div></div>;
          })}
          <div ref={end} />
        </div>
        {d.conversation.status === "closed" && !admin ? <div className="p-4 text-center text-gray-400 text-sm border-t border-white/10">This conversation has been closed.</div> :
        <form onSubmit={send} className="p-3 border-t border-gold/20 bg-black/40 flex gap-2 items-end">
          {admin && <label className="text-xs text-gray-400 flex flex-col items-center gap-1 cursor-pointer"><input type="checkbox" checked={note} onChange={(e) => setNote(e.target.checked)} />Internal</label>}
          <textarea value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(e); } }} placeholder={note ? "Internal note (user cannot see)…" : "Type a message…"} rows={1} maxLength={2000} className="input resize-none flex-1" />
          <button className="btn-gold" disabled={busy || !text.trim()}>Send</button>
        </form>}
        {err && <p className="text-red-400 text-sm px-4 pb-2">{err}</p>}
      </div>
      <aside className="space-y-4">
        {r && <div className="card p-4 text-sm space-y-1"><h3 className="font-bold text-gold mb-2">Request #{r.code}</h3><p>Type: {r.kind === "withdrawal" ? "Withdrawal" : "Add Points"}</p>{r.robux && <p>Reward: {r.robux} Robux</p>}<p>Points: {r.points}</p><p>Status: <span className={`badge b-${r.status}`}>{LBL[r.status]}</span></p>{admin && r.adminNote && <p className="text-amber-300">Admin note: {r.adminNote}</p>}</div>}
        {admin && r && d.canManage && NEXT[r.status].length > 0 && <AdminActions status={r.status} onAct={(status, body) => post({ action: "status", status, body })} busy={busy} />}
        {admin && <button onClick={() => post({ action: d.conversation.status === "closed" ? "reopen" : "close" })} className="btn-ghost w-full">{d.conversation.status === "closed" ? "Reopen conversation" : "✔ Close as resolved"}</button>}
        {!admin && <div className="card p-4 text-xs text-gray-400">Only you and Royal Rewards administrators can see this conversation. Admins will never ask for your password.</div>}
      </aside>
    </div>
  );
}
function AdminActions({ status, onAct, busy }: { status: string; onAct: (s: string, note: string) => void; busy: boolean }) {
  const [n, setN] = useState("");
  return <div className="card p-4 space-y-2"><h3 className="font-bold text-gold">Admin decision</h3><input className="input text-sm" placeholder="Administrative note (optional)" value={n} onChange={(e) => setN(e.target.value)} />
    {NEXT[status].map((s) => <button key={s} disabled={busy} onClick={() => { if (confirm(`Change status to ${LBL[s]}?`)) onAct(s, n); }} className={s === "rejected" ? "btn-danger w-full" : s === "approved" || s === "completed" ? "btn-gold w-full" : "btn-ghost w-full"}>{s === "approved" ? "✅ Approve" : s === "rejected" ? "❌ Reject" : s === "completed" ? "🏆 Mark completed" : `→ ${LBL[s]}`}</button>)}</div>;
}
