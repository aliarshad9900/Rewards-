import { STATUS_LABEL_PUBLIC } from "@/lib/labels";
export function Status({ s }: { s: string }) { return <span className={`badge b-${s}`}>{STATUS_LABEL_PUBLIC[s] ?? s}</span>; }
export function fmt(d: Date | string) { return new Date(d).toLocaleString("en-GB", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }); }
export function PageTitle({ title, sub, icon }: { title: string; sub?: string; icon?: string }) {
  return <div className="mb-6"><h1 className="text-2xl md:text-3xl font-black flex items-center gap-3">{icon && <span>{icon}</span>}<span className="text-gold-grad font-royal">{title}</span></h1>{sub && <p className="text-gray-400 mt-1">{sub}</p>}</div>;
}
export function Stat({ label, value, icon, hint }: { label: string; value: string | number; icon: string; hint?: string }) {
  return <div className="card p-4"><div className="flex items-center justify-between text-gray-400 text-xs uppercase tracking-widest">{label}<span className="text-xl">{icon}</span></div><div className="mt-2 text-2xl font-black text-gold">{typeof value === "number" ? value.toLocaleString() : value}</div>{hint && <div className="text-xs text-gray-500 mt-1">{hint}</div>}</div>;
}
export const TX_LABEL: Record<string, string> = { welcome_bonus: "Welcome Bonus", game_entry: "Game Entry", game_win: "Game Win", game_refund: "Money Back", withdrawal_reserve: "Withdrawal Reserve", withdrawal_refund: "Withdrawal Refund", withdrawal_complete: "Withdrawal Paid", add_points: "Points Added", admin_adjust: "Admin Adjustment", daily_reward: "Daily Reward" };
