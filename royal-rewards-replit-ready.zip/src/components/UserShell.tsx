"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Logo } from "./Logo";

const NAV = [
  { href: "/app", label: "Home", icon: "🏠" },
  { href: "/app/games", label: "Games", icon: "🎮" },
  { href: "/app/wallet", label: "Wallet", icon: "👛" },
  { href: "/app/redeem", label: "Redeem", icon: "🎁" },
  { href: "/app/add-points", label: "Add Points", icon: "➕" },
  { href: "/app/messages", label: "Messages", icon: "💬" },
  { href: "/app/history", label: "History", icon: "📜" },
  { href: "/app/profile", label: "Profile", icon: "👤" },
];
const MOBILE = ["/app", "/app/games", "/app/wallet", "/app/messages", "/app/profile"];

export function UserShell({ children, userNumber, balance, unread, avatar, siteName, logo, globalEvent, globalEventPercent }: { children: React.ReactNode; userNumber: string; balance: number; unread: number; avatar: string; siteName: string; logo: string; globalEvent: "off" | "blessing" | "curse"; globalEventPercent: number }) {
  const path = usePathname(); const router = useRouter();
  const [bal, setBal] = useState(balance); const [un, setUn] = useState(unread);
  const [bump, setBump] = useState(false);
  useEffect(() => { setBal(balance); setUn(unread); }, [balance, unread]);
  useEffect(() => {
    const poll = async () => { try { const r = await fetch("/api/me"); if (r.status === 401) { router.push("/login"); return; } const j = await r.json(); setBal(j.balance); setUn(j.unread); } catch {} };
    const onBal = (e: Event) => { const v = (e as CustomEvent).detail; if (typeof v === "number") { setBal(v); setBump(true); setTimeout(() => setBump(false), 500); } };
    window.addEventListener("rr:balance", onBal);
    const t = setInterval(poll, 15000);
    return () => { clearInterval(t); window.removeEventListener("rr:balance", onBal); };
  }, [router]);
  const active = (h: string) => (h === "/app" ? path === "/app" : path.startsWith(h));
  async function logout() { await fetch("/api/auth/logout", { method: "POST" }); router.push("/login"); router.refresh(); }

  return (
    <div className="min-h-screen lg:pl-64">
      <aside className="hidden lg:flex fixed inset-y-0 left-0 w-64 flex-col border-r border-white/5 bg-black/40 backdrop-blur-xl p-5">
        <Link href="/app"><Logo name={siteName} logo={logo} /></Link>
        <nav className="mt-8 space-y-1 flex-1">
          {NAV.map((n) => (
            <Link key={n.href} href={n.href} className={`flex items-center gap-3 px-3 py-2.5 rounded-xl transition-colors ${active(n.href) ? "bg-gold/15 text-gold border border-gold/30" : "text-gray-300 hover:bg-white/5"}`}>
              <span className="text-lg w-6 text-center">{n.icon}</span>{n.label}
            </Link>
          ))}
        </nav>
        <button onClick={logout} className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-gray-400 hover:bg-red-950/40 hover:text-red-300"><span className="w-6 text-center">🚪</span>Logout</button>
      </aside>
      <header className="sticky top-0 z-30 flex items-center justify-between gap-3 px-4 lg:px-8 h-16 bg-black/60 backdrop-blur-xl border-b border-white/5">
        <Link href="/app" className="lg:hidden"><Logo name={siteName} logo={logo} size="sm" /></Link>
        <div className="hidden lg:block text-sm text-gray-400">Signed in as <span className="text-white font-semibold">{userNumber}</span></div>
        <div className="flex items-center gap-2 sm:gap-3">
          <Link href="/app/wallet" className={`flex items-center gap-1.5 rounded-full border border-gold/40 bg-gold/10 px-3 py-1.5 text-sm font-bold text-gold transition-transform ${bump ? "scale-110" : ""}`}>🪙 {bal.toLocaleString()}</Link>
          <Link href="/app/notifications" className="relative w-9 h-9 grid place-items-center rounded-full hover:bg-white/5" aria-label="Notifications">🔔{un > 0 && <span className="absolute -top-0.5 -right-0.5 min-w-5 h-5 px-1 rounded-full bg-red-500 text-[10px] font-bold grid place-items-center">{un > 99 ? "99+" : un}</span>}</Link>
          <Link href="/app/profile" className="flex items-center gap-2"><span className="w-9 h-9 grid place-items-center rounded-full bg-gradient-to-br from-purple-600 to-amber-500 text-lg">{avatar}</span><span className="hidden sm:block text-xs font-semibold text-gray-300">{userNumber}</span></Link>
          <button onClick={logout} className="lg:hidden text-gray-400 text-sm px-1" aria-label="Logout">🚪</button>
        </div>
      </header>
      {globalEvent !== "off" && <div className={`mx-4 lg:mx-8 mt-4 rounded-xl border px-4 py-3 text-sm font-semibold ${globalEvent === "blessing" ? "border-amber-400/40 bg-amber-400/10 text-amber-200" : "border-violet-400/40 bg-violet-500/10 text-violet-200"}`} role="status">{globalEvent === "blessing" ? `✨ Global Blessing is active — +${globalEventPercent}% on newly earned points!` : `🌑 Global Curse is active — ${globalEventPercent}% fewer points from new point credits.`}</div>}
      <main key={path} className="p-4 lg:p-8 pb-28 lg:pb-10 max-w-7xl mx-auto anim-fade">{children}</main>
      <nav className="lg:hidden fixed bottom-0 inset-x-0 z-30 grid grid-cols-5 bg-black/85 backdrop-blur-xl border-t border-gold/20 pb-[env(safe-area-inset-bottom)]">
        {NAV.filter((n) => MOBILE.includes(n.href)).map((n) => (
          <Link key={n.href} href={n.href} className={`flex flex-col items-center py-2 text-[11px] ${active(n.href) ? "text-gold" : "text-gray-400"}`}><span className="text-xl">{n.icon}</span>{n.label}</Link>
        ))}
      </nav>
    </div>
  );
}
