export function Logo({ name = "ROYAL REWARDS", logo = "👑", size = "md" }: { name?: string; logo?: string; size?: "sm" | "md" | "lg" }) {
  const s = size === "lg" ? "text-4xl md:text-5xl" : size === "sm" ? "text-lg" : "text-xl";
  const isUrl = /^https?:\/\//.test(logo);
  return (
    <div className="flex items-center gap-2 select-none">
      {isUrl ? <img src={logo} alt="" className={size === "lg" ? "h-14 w-14" : "h-8 w-8"} /> : <span className={`${s} drop-shadow-[0_0_12px_rgba(245,197,66,.6)]`}>{logo}</span>}
      <span className={`font-royal font-black ${s} text-gold-grad`}>{name}</span>
    </div>
  );
}
