import { Logo } from "./Logo";
import { getSettings } from "@/lib/core";
import { GAME_META, GAME_KEYS } from "@/lib/gameMeta";
import Link from "next/link";

export async function AuthLayout({ children }: { children: React.ReactNode }) {
  const s = await getSettings();
  return (
    <main className="min-h-screen grid lg:grid-cols-2">
      <section className="relative hidden lg:flex flex-col justify-center p-14 overflow-hidden">
        <div className="absolute -top-40 -left-40 w-[500px] h-[500px] rounded-full bg-purple-700/30 blur-3xl" />
        <Logo name={s.siteName} logo={s.logo} size="lg" />
        <h1 className="mt-8 text-5xl font-black leading-tight">Play games.<br /><span className="text-gold-grad">Earn points.</span><br />Unlock rewards.</h1>
        <p className="mt-4 text-gray-400 max-w-md">Eight royal games, fair server-side results, and a transparent rewards wallet reviewed by real administrators.</p>
        <div className="mt-10 grid grid-cols-4 gap-3 max-w-md">
          {GAME_KEYS.map((k, i) => <div key={k} className="card aspect-square flex items-center justify-center text-3xl anim-float" style={{ animationDelay: `${i * 0.3}s` }} title={GAME_META[k].name}>{GAME_META[k].icon}</div>)}
        </div>
      </section>
      <section className="flex items-center justify-center p-5">
        <div className="w-full max-w-md">
          <div className="lg:hidden flex justify-center mb-6"><Logo name={s.siteName} logo={s.logo} size="lg" /></div>
          <div className="card glow-gold p-7 anim-fade">{children}</div>
          <p className="text-center text-xs text-gray-500 mt-6">Administrator? <Link href="/admin/login" className="text-gold">Admin sign-in</Link> · Points have no cash value.</p>
        </div>
      </section>
    </main>
  );
}
