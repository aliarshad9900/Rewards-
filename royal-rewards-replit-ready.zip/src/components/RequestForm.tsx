"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export function RequestForm({ kind, balance, options, rateP, rateR, min, max }: { kind: "withdrawal" | "add_points"; balance: number; options?: number[]; rateP?: number; rateR?: number; min?: number; max?: number }) {
  const r = useRouter();
  const [amount, setAmount] = useState<number>(kind === "withdrawal" ? options?.[0] ?? 0 : 100);
  const [note, setNote] = useState(""); const [confirm, setConfirm] = useState(false); const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);
  const [key] = useState(() => crypto.randomUUID());
  const points = kind === "withdrawal" ? Math.ceil((amount * (rateP ?? 1)) / (rateR ?? 1)) : amount;
  const enough = kind !== "withdrawal" || balance >= points;
  async function submit() {
    setBusy(true); setErr("");
    const res = await fetch("/api/requests", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ kind, amount, key, note }) });
    const j = await res.json();
    if (!res.ok) { setBusy(false); setErr(j.error); return; }
    r.push(`/app/messages/${j.conversationId}`); r.refresh();
  }
  return (
    <div className="card p-6 space-y-5">
      {kind === "withdrawal" ? <div><label className="label">Choose reward amount</label><div className="grid grid-cols-2 sm:grid-cols-4 gap-3">{options!.map((o) => { const p = Math.ceil((o * rateP!) / rateR!); return <button key={o} type="button" onClick={() => { setAmount(o); setConfirm(false); }} className={`rounded-2xl p-4 border transition-all ${amount === o ? "glow-gold bg-gold/10 scale-[1.03]" : "border-white/10 hover:border-gold/40"}`}><div className="text-2xl font-black text-gold">{o}</div><div className="text-xs text-gray-400">Robux</div><div className="text-xs mt-1">{p} pts</div></button>; })}</div></div>
        : <div><label className="label">Points to request ({min}–{max})</label><div className="flex gap-2 flex-wrap mb-2">{[50, 100, 250, 500, 1000].filter((v) => v >= min! && v <= max!).map((v) => <button key={v} type="button" onClick={() => { setAmount(v); setConfirm(false); }} className={amount === v ? "btn-gold !py-1.5" : "btn-ghost !py-1.5"}>{v}</button>)}</div><input type="number" className="input" min={min} max={max} value={amount} onChange={(e) => { setAmount(Math.floor(Number(e.target.value))); setConfirm(false); }} /></div>}
      <div><label className="label">Note for admin (optional)</label><textarea className="input" maxLength={500} value={note} onChange={(e) => setNote(e.target.value)} placeholder={kind === "withdrawal" ? "e.g. your Roblox username" : "Why are you requesting these points?"} /></div>
      {!confirm ? <button className="btn-gold w-full" disabled={!enough || !amount} onClick={() => setConfirm(true)}>{enough ? "Review request" : `Not enough points (need ${points})`}</button> :
        <div className="rounded-2xl border border-gold/50 bg-black/40 p-5 anim-pop space-y-2">
          <h3 className="font-bold text-gold">Request summary</h3>
          {kind === "withdrawal" ? <><p>Reward: <b>{amount} Robux</b></p><p>Points required: <b className="text-gold">{points}</b></p><p>Balance after reservation: <b>{balance - points}</b></p><p className="text-xs text-gray-400">Points are reserved now. If the request is rejected, they return to your balance.</p></> :
            <><p>Points requested: <b className="text-gold">{amount}</b></p><p className="text-xs text-gray-400">Nothing is added until an administrator approves.</p></>}
          <div className="flex gap-2 pt-2"><button className="btn-ghost flex-1" onClick={() => setConfirm(false)}>Back</button><button className="btn-gold flex-1" disabled={busy} onClick={submit}>{busy ? "Submitting…" : "Confirm & submit"}</button></div>
        </div>}
      {err && <p className="text-red-400 text-sm">{err}</p>}
    </div>
  );
}
