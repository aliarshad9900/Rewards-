"use client";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { GAME_META, type GameKey } from "@/lib/gameMeta";

type Outcome = { label: string; kind: string; reward: number; prob: number };
type Result = { kind: string; reward: number; label: string; refund?: number; index?: number; pos?: number; number?: number; choice?: number; moves?: number };
type Sess = { id: string; status: string; result: Result | null; cost: number; memory?: { size: number; moves: number; maxMoves: number; faces: Record<string, string>; matched: number[] } };
type State = { game: { key: string; name: string; enabled: boolean; entryCost: number; dailyLimit: number; instructions: string; config: Record<string, unknown> }; session: Sess | null; playsToday: number; daily: { streak: number; claimedToday: boolean; nextDayIndex: number; nextReset: string } | null; balance: number };

const emitBalance = (b: unknown) => { if (typeof b === "number") window.dispatchEvent(new CustomEvent("rr:balance", { detail: b })); };

export function GameClient({ gameKey }: { gameKey: GameKey }) {
  const meta = GAME_META[gameKey];
  const [st, setSt] = useState<State | null>(null);
  const [err, setErr] = useState("");
  const [result, setResult] = useState<Result | null>(null);
  const [showRules, setShowRules] = useState(false);
  const load = useCallback(async () => { const r = await fetch(`/api/games/${gameKey}`); const j = await r.json(); if (!r.ok) setErr(j.error); else { setSt(j); emitBalance(j.balance); } }, [gameKey]);
  useEffect(() => { load(); }, [load]);

  const api = useCallback(async (body: Record<string, unknown>, deferBalance = false) => {
    setErr("");
    const r = await fetch(`/api/games/${gameKey}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const j = await r.json();
    if (!r.ok) throw new Error(j.error || "Error");
    if (!deferBalance) emitBalance(j.balance);
    return j;
  }, [gameKey]);

  /** start (or resume) a round then play the choice */
  const playRound = useCallback(async (choice: number) => {
    let sid = st?.session?.status === "open" ? st.session.id : null;
    if (!sid) { const s = await api({ action: "start" }); sid = s.session.id; }
    const j = await api({ action: "play", sessionId: sid, choice }, true);
    return j as { result: Result; balance: number };
  }, [api, st]);

  const finishRound = useCallback((res: Result, balance: number) => { emitBalance(balance); setResult(res); }, []);
  const reset = useCallback(() => { setResult(null); load(); }, [load]);

  if (!st) return <div className="card h-96 animate-pulse">{err && <p className="p-6 text-red-300">{err}</p>}</div>;
  const g = st.game;
  const limitHit = g.dailyLimit > 0 && st.playsToday >= g.dailyLimit && st.session?.status !== "open";
  const resumable = st.session?.status === "open";
  const common = { st, api, playRound, finishRound, setErr, reset, disabled: !g.enabled || limitHit, resumable };

  return (
    <div className="space-y-5">
      <div className={`card overflow-hidden`}>
        <div className={`bg-gradient-to-r ${meta.grad} p-5 md:p-6 flex items-center gap-4 relative`}>
          <div className="absolute inset-0 bg-black/30" />
          <span className="relative text-5xl md:text-6xl anim-float">{meta.icon}</span>
          <div className="relative flex-1"><Link href="/app/games" className="text-xs text-white/70">← All games</Link><h1 className="text-2xl md:text-3xl font-black font-royal">{g.name}</h1><p className="text-white/80 text-sm">{meta.tagline}</p></div>
          <button onClick={() => setShowRules((v) => !v)} className="relative btn-ghost !text-white !border-white/40 text-sm">📖 Rules</button>
        </div>
        <div className="flex flex-wrap gap-x-6 gap-y-1 px-5 py-3 text-sm bg-black/30">
          <span>Entry: <b className="text-gold">{g.entryCost ? `${g.entryCost} pts` : "Free"}</b></span>
          {g.dailyLimit > 0 && <span>Attempts today: <b className="text-gold">{st.playsToday}/{g.dailyLimit}</b></span>}
          <span>Results: <b className="text-green-400">Server-verified 🔒</b></span>
        </div>
        {showRules && <div className="px-5 py-4 text-sm text-gray-300 border-t border-white/5 anim-fade whitespace-pre-line">{g.instructions}<RulesTable g={g} /></div>}
      </div>
      {!g.enabled && <div className="card p-4 text-amber-300">This game is currently disabled by the administrators.</div>}
      {limitHit && <div className="card p-4 text-amber-300">You have used all attempts for today. Come back tomorrow!</div>}
      {resumable && <div className="card p-3 text-sm text-gold">↻ You have an unfinished round (entry already paid). Make your pick to finish it.</div>}
      {err && <div className="card p-3 text-red-300 text-sm">{err}</div>}
      <div className="card p-4 md:p-8 relative overflow-hidden">
        {gameKey === "wheel" && <Wheel {...common} />}
        {(gameKey === "box" || gameKey === "treasure" || gameKey === "cards") && <PickGame {...common} variant={gameKey} />}
        {gameKey === "bunny" && <Bunny {...common} />}
        {gameKey === "lucky" && <Lucky {...common} />}
        {gameKey === "memory" && <Memory {...common} />}
        {gameKey === "daily" && <Daily {...common} />}
      </div>
      {result && <ResultModal r={result} onClose={reset} />}
    </div>
  );
}

function RulesTable({ g }: { g: State["game"] }) {
  const outs = g.config.outcomes as Outcome[] | undefined;
  if (!outs) return null;
  return <table className="table mt-3 max-w-sm"><thead><tr><th>Result</th><th>Probability</th></tr></thead><tbody>{outs.map((o, i) => <tr key={i}><td>{o.label}{o.kind === "win" ? ` (+${o.reward})` : ""}</td><td>{o.prob}%</td></tr>)}</tbody></table>;
}

type Common = { st: State; api: (b: Record<string, unknown>, d?: boolean) => Promise<Record<string, unknown>>; playRound: (c: number) => Promise<{ result: Result; balance: number }>; finishRound: (r: Result, b: number) => void; setErr: (s: string) => void; reset: () => void; disabled: boolean; resumable: boolean };

function costLabel(st: State, resumable: boolean) { return resumable ? "(already paid)" : st.game.entryCost ? `for ${st.game.entryCost} pts` : "(free)"; }

/* ---------------- WHEEL ---------------- */
const WCOL = ["#5b21b6", "#d4a017", "#111018", "#b91c1c", "#7c3aed", "#f5c542", "#27272a", "#dc2626"];
function Wheel({ st, playRound, finishRound, setErr, disabled, resumable }: Common) {
  const outs = st.game.config.outcomes as Outcome[];
  const [rot, setRot] = useState(0); const [spinning, setSpinning] = useState(false);
  const pending = useRef<{ r: Result; b: number } | null>(null);
  const segs = useMemo(() => { let a = 0; return outs.map((o, i) => { const s = a; a += (o.prob / 100) * 360; return { ...o, a0: s, a1: a, color: WCOL[i % WCOL.length] }; }); }, [outs]);
  const pt = (deg: number, r: number) => { const t = (deg * Math.PI) / 180; return [150 + r * Math.sin(t), 150 - r * Math.cos(t)]; };
  async function spin() {
    if (spinning) return; setSpinning(true);
    try {
      const j = await playRound(0);
      const seg = segs[j.result.index ?? 0];
      const width = seg.a1 - seg.a0;
      const want = seg.a0 + width / 2 + (Math.random() - 0.5) * width * 0.6;
      const cur = rot % 360;
      const delta = (((360 - want - cur) % 360) + 360) % 360;
      pending.current = { r: j.result, b: j.balance };
      setRot(rot + 360 * 6 + delta);
    } catch (e) { setErr((e as Error).message); setSpinning(false); }
  }
  function done() { setSpinning(false); if (pending.current) { finishRound(pending.current.r, pending.current.b); pending.current = null; } }
  return (
    <div className="flex flex-col items-center gap-6">
      <div className="relative w-[min(86vw,420px)] aspect-square">
        <div className="absolute left-1/2 -translate-x-1/2 -top-3 z-10 w-0 h-0 border-l-[18px] border-r-[18px] border-t-[34px] border-l-transparent border-r-transparent border-t-[var(--gold)] drop-shadow-[0_0_10px_rgba(245,197,66,.9)]" />
        <div className="absolute inset-0 rounded-full glow-gold anim-glow" />
        <svg viewBox="0 0 300 300" className="w-full h-full" style={{ transform: `rotate(${rot}deg)`, transition: spinning ? "transform 4.8s cubic-bezier(.12,.75,.12,1)" : "none", willChange: "transform" }} onTransitionEnd={done}>
          {segs.map((s, i) => { const [x0, y0] = pt(s.a0, 145), [x1, y1] = pt(s.a1, 145); const large = s.a1 - s.a0 > 180 ? 1 : 0; const mid = (s.a0 + s.a1) / 2; const [tx, ty] = pt(mid, 95);
            return <g key={i}><path d={`M150 150 L${x0} ${y0} A145 145 0 ${large} 1 ${x1} ${y1} Z`} fill={s.color} stroke="#f5c542" strokeWidth="1.5" />
              <text x={tx} y={ty} fill={s.color === "#d4a017" || s.color === "#f5c542" ? "#1a1006" : "#fff"} fontSize="13" fontWeight="800" textAnchor="middle" dominantBaseline="middle" transform={`rotate(${mid} ${tx} ${ty})`}>{s.label}</text></g>; })}
          <circle cx="150" cy="150" r="146" fill="none" stroke="#f5c542" strokeWidth="4" />
          {Array.from({ length: 24 }).map((_, i) => { const [x, y] = pt(i * 15, 146); return <circle key={i} cx={x} cy={y} r="2.5" fill="#fff8d6" />; })}
          <circle cx="150" cy="150" r="26" fill="#0b0712" stroke="#f5c542" strokeWidth="4" /><text x="150" y="152" textAnchor="middle" dominantBaseline="middle" fontSize="20">👑</text>
        </svg>
      </div>
      <button className="btn-gold text-xl !px-12 !py-4" onClick={spin} disabled={spinning || disabled}>{spinning ? "Spinning…" : `SPIN ${costLabel(st, resumable)}`}</button>
    </div>
  );
}

/* ---------------- BOX / TREASURE / CARDS ---------------- */
function PickGame({ st, playRound, finishRound, setErr, disabled, resumable, variant }: Common & { variant: "box" | "treasure" | "cards" }) {
  const c = st.game.config;
  const n = Number(variant === "box" ? c.boxCount : variant === "treasure" ? c.chests : c.cards);
  const style = String(c.boxStyle ?? "mixed");
  const [sel, setSel] = useState<number | null>(null); const [busy, setBusy] = useState(false);
  const [opened, setOpened] = useState<{ i: number; r: Result } | null>(null);
  async function go() {
    if (sel === null) return; setBusy(true);
    try { const j = await playRound(sel); setTimeout(() => setOpened({ i: sel, r: j.result }), variant === "cards" ? 50 : 700); setTimeout(() => finishRound(j.result, j.balance), variant === "cards" ? 1100 : 1700); }
    catch (e) { setErr((e as Error).message); setBusy(false); }
  }
  const icon = variant === "box" ? "🎁" : variant === "treasure" ? "🧰" : "🂠";
  const verb = variant === "box" ? "Open box" : variant === "treasure" ? "Open chest" : "Flip card";
  const revealIcon = (r: Result) => r.kind === "win" ? (variant === "treasure" ? (r.reward >= 30 ? "👑" : r.reward >= 10 ? "💰" : "🪙") : variant === "cards" ? (r.reward >= 15 ? "🤴" : "👸") : "💎") : r.kind === "refund" ? "↩️" : variant === "cards" ? "🃏" : "💨";
  return (
    <div className="flex flex-col items-center gap-6">
      <p className="text-gray-300">{sel === null ? `Select a ${variant === "box" ? "mystery box" : variant === "treasure" ? "treasure chest" : "card"}` : "Great choice! Confirm to reveal."}</p>
      <div className={`grid gap-4 w-full max-w-3xl ${n <= 3 ? "grid-cols-3" : n <= 4 ? "grid-cols-2 sm:grid-cols-4" : n <= 6 ? "grid-cols-3" : "grid-cols-3 sm:grid-cols-5"}`}>
        {Array.from({ length: n }).map((_, i) => {
          const isSel = sel === i, isOpen = opened?.i === i;
          const gold = style === "gold" || (style === "mixed" && i % 2 === 1);
          if (variant === "cards") return (
            <button key={i} disabled={busy || disabled} onClick={() => setSel(i)} className={`flip aspect-[2/3] transition-transform duration-200 ${isSel ? "-translate-y-3" : "hover:-translate-y-1"}`}>
              <div className={`flip-inner ${isOpen ? "flipped" : ""}`}>
                <div className={`flip-face bg-gradient-to-br from-purple-800 to-purple-950 border-2 ${isSel ? "border-[var(--gold)] glow-gold" : "border-gold/40"}`}><div className="absolute inset-2 rounded-xl border border-gold/30 bg-[repeating-linear-gradient(45deg,transparent_0_8px,rgba(245,197,66,.08)_8px_16px)]" /><span className="text-4xl">⚜️</span></div>
                <div className="flip-face flip-back bg-gradient-to-br from-amber-100 to-amber-300 text-black flex-col border-2 border-[var(--gold)]">{opened && <><span className="text-5xl">{revealIcon(opened.r)}</span><span className="text-xs font-bold mt-2 px-1 text-center">{opened.r.label}</span></>}</div>
              </div>
            </button>);
          return (
            <button key={i} disabled={busy || disabled} onClick={() => setSel(i)} className={`relative aspect-square rounded-2xl flex items-center justify-center transition-all duration-200 ${gold ? "bg-gradient-to-br from-amber-400 via-yellow-600 to-amber-800" : "bg-gradient-to-br from-fuchsia-700 via-purple-800 to-purple-950"} ${isSel ? "glow-gold scale-105 ring-2 ring-[var(--gold)]" : "hover:scale-[1.03] border border-gold/30"} ${opened && !isOpen ? "opacity-40" : ""}`}>
              <div className="absolute inset-0 rounded-2xl bg-[radial-gradient(circle_at_30%_25%,rgba(255,255,255,.35),transparent_55%)]" />
              {isOpen ? <span className="text-5xl anim-pop flex flex-col items-center">{revealIcon(opened!.r)}<span className="text-xs font-bold mt-1 text-white drop-shadow">{opened!.r.label}</span></span>
                : <span className={`text-5xl md:text-6xl ${busy && isSel ? "anim-shake" : isSel ? "" : "anim-float"}`} style={{ animationDelay: `${i * 0.2}s` }}>{icon}</span>}
              {isOpen && opened!.r.kind === "win" && <Coins />}
            </button>);
        })}
      </div>
      <button className="btn-gold !px-10" disabled={sel === null || busy || disabled} onClick={go}>{busy ? "Revealing…" : `${verb} ${costLabel(st, resumable)}`}</button>
    </div>
  );
}

/* ---------------- BUNNY ---------------- */
function Bunny({ st, playRound, finishRound, setErr, disabled, resumable }: Common) {
  const n = Number(st.game.config.boxes);
  const [sel, setSel] = useState<number | null>(null); const [busy, setBusy] = useState(false); const [rev, setRev] = useState<Result | null>(null);
  async function go() {
    if (sel === null) return; if (!confirm(`You only get ONE pick. Open box ${sel + 1}?`)) return; setBusy(true);
    try { const j = await playRound(sel); setTimeout(() => setRev(j.result), 600); setTimeout(() => finishRound(j.result, j.balance), 1800); }
    catch (e) { setErr((e as Error).message); setBusy(false); }
  }
  return (
    <div className="flex flex-col items-center gap-6">
      <p className="text-gray-300 text-center">One golden bunny 🐰 hides in one of these boxes. Prize: <b className="text-gold">{String(st.game.config.reward)} points</b>. One pick only!</p>
      <div className={`grid gap-4 md:gap-6 w-full max-w-2xl`} style={{ gridTemplateColumns: `repeat(${Math.min(n, 5)}, minmax(0,1fr))` }}>
        {Array.from({ length: n }).map((_, i) => { const has = rev && rev.pos === i; const picked = sel === i;
          return <button key={i} disabled={busy || disabled} onClick={() => setSel(i)} className={`relative aspect-[4/5] rounded-3xl transition-all duration-200 bg-gradient-to-b from-purple-700 to-purple-950 border-2 ${picked ? "border-[var(--gold)] glow-gold -translate-y-2" : "border-purple-500/40 hover:-translate-y-1"}`}>
            <div className={`absolute inset-x-0 top-0 h-1/4 rounded-t-3xl bg-gradient-to-b from-purple-500 to-purple-700 border-b-4 border-[var(--gold)] transition-transform duration-500 origin-left ${rev ? "-rotate-[25deg] -translate-y-4" : ""}`} />
            <div className="absolute left-1/2 -translate-x-1/2 top-[22%] w-6 h-full bg-[var(--gold)]/70" />
            <div className="absolute inset-0 flex items-center justify-center pt-6">{rev ? (has ? <span className="text-6xl anim-pop drop-shadow-[0_0_20px_rgba(245,197,66,.9)]">🐰</span> : <span className="text-3xl opacity-60 anim-pop">✖</span>) : <span className="text-4xl font-black text-gold/80">?</span>}</div>
            {has && rev?.kind === "win" && <Coins />}
          </button>; })}
      </div>
      <button className="btn-gold !px-10" disabled={sel === null || busy || disabled} onClick={go}>{busy ? "Opening…" : `Open my box ${costLabel(st, resumable)}`}</button>
    </div>
  );
}

/* ---------------- LUCKY NUMBER ---------------- */
function Lucky({ st, playRound, finishRound, setErr, disabled, resumable }: Common) {
  const max = Number(st.game.config.max);
  const [sel, setSel] = useState<number | null>(null); const [busy, setBusy] = useState(false); const [win, setWin] = useState<number | null>(null);
  async function go() { if (sel === null) return; setBusy(true);
    try { const j = await playRound(sel); setTimeout(() => setWin(j.result.number ?? null), 900); setTimeout(() => finishRound(j.result, j.balance), 1800); }
    catch (e) { setErr((e as Error).message); setBusy(false); } }
  return (
    <div className="flex flex-col items-center gap-6">
      <p className="text-gray-300">Pick a number from 1 to {max}. Exact match wins <b className="text-gold">{String(st.game.config.reward)} pts</b>{Number(st.game.config.nearReward) > 0 && <> · off by one wins {String(st.game.config.nearReward)} pts</>}.</p>
      <div className="grid grid-cols-5 sm:grid-cols-10 gap-2 md:gap-3 w-full max-w-3xl">
        {Array.from({ length: max }, (_, i) => i + 1).map((v) => <button key={v} disabled={busy || disabled} onClick={() => setSel(v)} className={`aspect-square rounded-xl text-xl md:text-2xl font-black transition-all duration-200 border ${win === v ? "bg-gradient-to-br from-yellow-300 to-amber-600 text-black glow-gold anim-pop" : sel === v ? "bg-gold/20 border-[var(--gold)] text-gold glow-gold scale-110" : "bg-purple-950/70 border-purple-500/30 hover:border-gold/60 hover:text-gold"} ${busy && sel === v && win === null ? "animate-pulse" : ""}`}>{v}</button>)}
      </div>
      <button className="btn-gold !px-10" disabled={sel === null || busy || disabled} onClick={go}>{busy ? "Drawing…" : `Lock in ${sel ?? ""} ${costLabel(st, resumable)}`}</button>
    </div>
  );
}

/* ---------------- MEMORY ---------------- */
function Memory({ st, api, finishRound, setErr, disabled, resumable }: Common) {
  const [sess, setSess] = useState<Sess | null>(st.session?.status === "open" ? st.session : null);
  const [faces, setFaces] = useState<Record<string, string>>(sess?.memory?.faces ?? {});
  const [matched, setMatched] = useState<number[]>(sess?.memory?.matched ?? []);
  const [moves, setMoves] = useState(sess?.memory?.moves ?? 0);
  const [lock, setLock] = useState(false);
  const size = sess?.memory?.size ?? Number(st.game.config.pairs) * 2;
  const maxMoves = sess?.memory?.maxMoves ?? Number(st.game.config.maxMoves);
  useEffect(() => { // hide unmatched faces left over from a previous mismatch on resume
    if (sess?.memory) { const f = sess.memory.faces; const open = Object.keys(f).map(Number).filter((i) => !sess.memory!.matched.includes(i)); if (open.length === 2) { const c = { ...f }; open.forEach((i) => delete c[i]); setFaces(c); } }
  }, [sess]);
  async function begin() { try { const j = await api({ action: "start" }); setSess(j.session as Sess); const m = (j.session as Sess).memory!; setFaces(m.faces); setMatched(m.matched); setMoves(m.moves); } catch (e) { setErr((e as Error).message); } }
  async function flip(i: number) {
    if (!sess || lock || faces[i] !== undefined) return; setLock(true);
    try {
      const j = await api({ action: "play", sessionId: sess.id, choice: i }, true) as { memory: { faces: Record<string, string>; matched: number[]; moves: number; mismatch: number[] | null }; result: Result | null; balance: number };
      setFaces(j.memory.faces); setMatched(j.memory.matched); setMoves(j.memory.moves);
      if (j.result) { setTimeout(() => finishRound(j.result!, j.balance), 700); return; }
      if (j.memory.mismatch) { const mm = j.memory.mismatch; setTimeout(() => { setFaces((f) => { const c = { ...f }; mm.forEach((x) => delete c[x]); return c; }); setLock(false); }, 850); }
      else setLock(false);
    } catch (e) { setErr((e as Error).message); setLock(false); }
  }
  if (!sess) return <div className="text-center space-y-4 py-8"><div className="text-7xl anim-float">🃏</div><p className="text-gray-300">Match {String(st.game.config.pairs)} pairs within {maxMoves} moves to win <b className="text-gold">{String(st.game.config.reward)} pts</b>.</p><button className="btn-gold !px-10" disabled={disabled} onClick={begin}>Start game {costLabel(st, resumable)}</button></div>;
  const cols = size <= 8 ? 4 : size <= 12 ? 4 : size <= 16 ? 4 : 6;
  return (
    <div className="flex flex-col items-center gap-5">
      <div className="flex gap-6 text-sm"><span>Moves: <b className={moves > maxMoves ? "text-red-400" : "text-gold"}>{moves}</b> / {maxMoves}</span><span>Pairs: <b className="text-gold">{matched.length / 2}</b> / {size / 2}</span></div>
      <div className="grid gap-2 md:gap-3 w-full max-w-xl" style={{ gridTemplateColumns: `repeat(${cols}, minmax(0,1fr))` }}>
        {Array.from({ length: size }).map((_, i) => { const up = faces[i] !== undefined; const ok = matched.includes(i);
          return <button key={i} onClick={() => flip(i)} className="flip aspect-[3/4]" disabled={up}>
            <div className={`flip-inner ${up ? "flipped" : ""}`}>
              <div className="flip-face bg-gradient-to-br from-purple-700 to-purple-950 border border-gold/40 hover:border-gold"><span className="text-2xl text-gold/70">⚜️</span></div>
              <div className={`flip-face flip-back text-3xl md:text-4xl ${ok ? "bg-gradient-to-br from-yellow-200 to-amber-500 glow-gold" : "bg-gradient-to-br from-white to-purple-200"}`}>{faces[i]}</div>
            </div></button>; })}
      </div>
    </div>
  );
}

/* ---------------- DAILY ---------------- */
function Daily({ st, api, finishRound, setErr, disabled }: Common) {
  const d = st.daily!; const rewards = st.game.config.rewards as number[];
  const [busy, setBusy] = useState(false); const [left, setLeft] = useState("");
  useEffect(() => { const t = () => { const ms = new Date(d.nextReset).getTime() - Date.now(); if (ms <= 0) { setLeft("now"); return; } const h = Math.floor(ms / 3.6e6), m = Math.floor((ms % 3.6e6) / 6e4), s = Math.floor((ms % 6e4) / 1000); setLeft(`${h}h ${m}m ${s}s`); }; t(); const i = setInterval(t, 1000); return () => clearInterval(i); }, [d.nextReset]);
  const doneCount = d.claimedToday ? ((d.streak - 1) % 7) + 1 : d.streak % 7;
  const todayIdx = d.claimedToday ? (d.streak - 1) % 7 : d.streak % 7;
  async function claim() { setBusy(true); try { const j = await api({ action: "claim" }, true) as { reward: number; streak: number; dayIdx: number; balance: number }; finishRound({ kind: "win", reward: j.reward, label: `Day ${j.dayIdx + 1} reward · streak ${j.streak}` }, j.balance); } catch (e) { setErr((e as Error).message); setBusy(false); } }
  return (
    <div className="space-y-6">
      <div className="flex flex-wrap justify-center gap-6 text-center">
        <div><div className="text-4xl font-black text-gold">🔥 {d.streak}</div><div className="text-xs text-gray-400 tracking-widest">DAY STREAK</div></div>
        <div><div className="text-2xl font-bold font-mono">{d.claimedToday ? left : "Ready!"}</div><div className="text-xs text-gray-400 tracking-widest">{d.claimedToday ? "NEXT REWARD IN" : "TODAY'S GIFT"}</div></div>
      </div>
      <div className="grid grid-cols-4 sm:grid-cols-7 gap-3">
        {rewards.map((r, i) => { const claimed = i < doneCount; const isToday = i === todayIdx && !d.claimedToday;
          return <div key={i} className={`rounded-2xl p-3 text-center border transition-all ${isToday ? "glow-gold anim-glow bg-gold/10 scale-105" : claimed ? "border-green-500/40 bg-green-950/30" : "border-white/10 bg-black/30"} ${i === 6 ? "col-span-2 sm:col-span-1" : ""}`}>
            <div className="text-xs text-gray-400">Day {i + 1}</div><div className={`text-4xl my-1 ${isToday ? "anim-float" : ""}`}>{claimed ? "✅" : i === 6 ? "👑" : "🎁"}</div><div className="font-bold text-gold">+{r}</div></div>; })}
      </div>
      <div className="text-center"><button className="btn-gold text-lg !px-12" disabled={busy || disabled || d.claimedToday} onClick={claim}>{d.claimedToday ? "Claimed today ✔" : busy ? "Claiming…" : "Claim today's reward"}</button>
        <p className="text-xs text-gray-500 mt-3">{st.game.config.resetOnMiss ? "Missing a day resets your streak to Day 1." : "Missing a day does not reset your streak."} Days reset at 00:00 UTC.</p></div>
    </div>
  );
}

/* ---------------- FX ---------------- */
function Coins() { return <div className="pointer-events-none absolute inset-0">{Array.from({ length: 10 }).map((_, i) => <span key={i} className="absolute left-1/2 top-1/2 text-xl" style={{ animation: `coin 1.2s ease-out ${i * 0.06}s both`, ["--dx" as string]: `${(i - 5) * 18}px` }}>🪙</span>)}</div>; }
function Confetti() {
  const pieces = useMemo(() => Array.from({ length: 36 }).map((_, i) => ({ left: Math.random() * 100, dx: (Math.random() - 0.5) * 200, delay: Math.random() * 0.6, color: ["#f5c542", "#a855f7", "#fff", "#ef4444"][i % 4], dur: 1.8 + Math.random() * 1.2 })), []);
  return <div className="pointer-events-none fixed inset-0 z-[60] overflow-hidden">{pieces.map((p, i) => <span key={i} className="absolute top-0 w-2 h-3 rounded-sm" style={{ left: `${p.left}%`, background: p.color, animation: `confetti ${p.dur}s ease-in ${p.delay}s both`, ["--dx" as string]: `${p.dx}px` }} />)}</div>;
}
function ResultModal({ r, onClose }: { r: Result; onClose: () => void }) {
  const win = r.kind === "win" && r.reward > 0, refund = r.kind === "refund";
  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm grid place-items-center p-4" onClick={onClose}>
      {win && <Confetti />}
      <div className="card glow-gold p-8 max-w-sm w-full text-center anim-pop" onClick={(e) => e.stopPropagation()}>
        <div className="text-7xl mb-3">{win ? "🏆" : refund ? "↩️" : "😔"}</div>
        <h2 className="text-3xl font-black font-royal text-gold-grad">{win ? "VICTORY!" : refund ? "MONEY BACK" : "No luck"}</h2>
        <p className="text-gray-300 mt-2">{r.label}</p>
        {win && <p className="text-4xl font-black text-gold mt-3">+{r.reward} pts</p>}
        {refund && <p className="text-lg text-gold mt-3">Entry refunded{r.refund ? `: +${r.refund} pts` : ""} — try again!</p>}
        <button className="btn-gold w-full mt-6" onClick={onClose}>{refund ? "Try again" : "Play again"}</button>
      </div>
    </div>
  );
}
