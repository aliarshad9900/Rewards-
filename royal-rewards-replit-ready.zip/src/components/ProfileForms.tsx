"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
const AV = ["👑", "🦁", "🐉", "🗡️", "🛡️", "💎", "🏰", "🔮", "🐰", "🦅"];
export function ProfileForms(p: { displayName: string; avatar: string; bio: string }) {
  const r = useRouter(); const [f, setF] = useState(p); const [pw, setPw] = useState({ current: "", next: "" }); const [msg, setMsg] = useState("");
  async function call(body: object) { setMsg(""); const res = await fetch("/api/profile", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }); const j = await res.json(); setMsg(res.ok ? "✅ Saved" : "❌ " + j.error); if (res.ok) r.refresh(); return res.ok; }
  return (<div className="grid lg:grid-cols-2 gap-5">
    <form className="card p-6 space-y-3" onSubmit={(e) => { e.preventDefault(); call({ action: "profile", ...f }); }}><h3 className="font-bold text-gold">Profile</h3>
      <div><label className="label">Avatar</label><div className="flex flex-wrap gap-2">{AV.map((a) => <button type="button" key={a} onClick={() => setF({ ...f, avatar: a })} className={`w-11 h-11 rounded-full text-xl ${f.avatar === a ? "glow-gold bg-gold/10" : "bg-white/5"}`}>{a}</button>)}</div></div>
      <div><label className="label">Display name</label><input className="input" maxLength={30} value={f.displayName} onChange={(e) => setF({ ...f, displayName: e.target.value })} /></div>
      <div><label className="label">Bio</label><textarea className="input" maxLength={200} value={f.bio} onChange={(e) => setF({ ...f, bio: e.target.value })} /></div>
      <button className="btn-gold">Save profile</button></form>
    <div className="space-y-5"><form className="card p-6 space-y-3" onSubmit={async (e) => { e.preventDefault(); if (await call({ action: "password", ...pw })) setPw({ current: "", next: "" }); }}><h3 className="font-bold text-gold">Change password</h3>
      <input className="input" type="password" placeholder="Current password" value={pw.current} onChange={(e) => setPw({ ...pw, current: e.target.value })} required />
      <input className="input" type="password" placeholder="New password (min 8)" minLength={8} value={pw.next} onChange={(e) => setPw({ ...pw, next: e.target.value })} required />
      <button className="btn-gold">Update password</button></form>
      <div className="card p-6 space-y-2"><h3 className="font-bold text-gold">Sessions</h3><p className="text-sm text-gray-400">Sessions expire automatically after 7 days.</p><button className="btn-ghost" onClick={async () => { await call({ action: "logout_all" }); r.push("/login"); }}>Sign out everywhere</button></div>
      {msg && <p className="text-sm">{msg}</p>}</div>
  </div>);
}
