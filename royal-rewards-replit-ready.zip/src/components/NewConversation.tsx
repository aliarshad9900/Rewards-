"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
export function NewConversation() {
  const r = useRouter(); const [s, setS] = useState(""); const [b, setB] = useState(""); const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);
  async function go(e: React.FormEvent) { e.preventDefault(); setBusy(true); setErr("");
    const res = await fetch("/api/conversations", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ subject: s, body: b }) });
    const j = await res.json(); setBusy(false); if (!res.ok) return setErr(j.error); r.push(`/app/messages/${j.id}`); }
  return <form onSubmit={go} className="card p-5 space-y-3 h-fit"><h3 className="font-bold text-gold">✉️ Contact Admin</h3><div><label className="label">Subject</label><input className="input" value={s} onChange={(e) => setS(e.target.value)} required maxLength={100} /></div><div><label className="label">Message</label><textarea className="input min-h-28" value={b} onChange={(e) => setB(e.target.value)} required maxLength={2000} /></div>{err && <p className="text-red-400 text-sm">{err}</p>}<button className="btn-gold w-full" disabled={busy}>Start conversation</button></form>;
}
