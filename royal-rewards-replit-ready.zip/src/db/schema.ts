import { pgTable, serial, text, integer, boolean, timestamp, jsonb, uniqueIndex, index } from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  userNumber: text("user_number").notNull().unique(),
  username: text("username").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  status: text("status").notNull().default("active"), // active | suspended
  flagged: boolean("flagged").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  lastActiveAt: timestamp("last_active_at").notNull().defaultNow(),
});

export const profiles = pgTable("profiles", {
  userId: integer("user_id").primaryKey().references(() => users.id),
  displayName: text("display_name"),
  avatar: text("avatar").notNull().default("👑"),
  bio: text("bio"),
});

export const wallets = pgTable("wallets", {
  userId: integer("user_id").primaryKey().references(() => users.id),
  available: integer("available").notNull().default(0),
  reserved: integer("reserved").notNull().default(0),
  totalEarned: integer("total_earned").notNull().default(0),
  totalWithdrawn: integer("total_withdrawn").notNull().default(0),
  frozen: boolean("frozen").notNull().default(false),
  welcomeBonusGiven: boolean("welcome_bonus_given").notNull().default(false),
});

export const transactions = pgTable("transactions", {
  id: text("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  type: text("type").notNull(), // welcome_bonus, game_entry, game_win, game_refund, withdrawal_reserve, withdrawal_refund, withdrawal_complete, add_points, admin_adjust, daily_reward
  amount: integer("amount").notNull(),
  status: text("status").notNull().default("completed"),
  description: text("description").notNull(),
  refId: text("ref_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (t) => [index("tx_user_idx").on(t.userId)]);

export const admins = pgTable("admins", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  name: text("name"),
  role: text("role").notNull().default("support"), // owner | admin | support
  permissions: jsonb("permissions").$type<string[]>().notNull().default([]),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const sessions = pgTable("sessions", {
  id: text("id").primaryKey(), // sha256 of token
  userId: integer("user_id"),
  adminId: integer("admin_id"),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const gameSettings = pgTable("game_settings", {
  key: text("key").primaryKey(),
  name: text("name").notNull(),
  enabled: boolean("enabled").notNull().default(true),
  entryCost: integer("entry_cost").notNull().default(0),
  dailyLimit: integer("daily_limit").notNull().default(0),
  instructions: text("instructions").notNull().default(""),
  config: jsonb("config").$type<Record<string, unknown>>().notNull().default({}),
});

export const gameSessions = pgTable("game_sessions", {
  id: text("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  gameKey: text("game_key").notNull(),
  status: text("status").notNull().default("open"), // open | finished
  secret: jsonb("secret").$type<Record<string, unknown>>().notNull().default({}),
  result: jsonb("result").$type<Record<string, unknown>>(),
  cost: integer("cost").notNull().default(0),
  reward: integer("reward").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  finishedAt: timestamp("finished_at"),
}, (t) => [index("gs_user_idx").on(t.userId, t.gameKey)]);

export const dailyState = pgTable("daily_state", {
  userId: integer("user_id").primaryKey().references(() => users.id),
  streak: integer("streak").notNull().default(0),
  lastClaimDay: text("last_claim_day"),
});

export const requests = pgTable("requests", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  kind: text("kind").notNull(), // withdrawal | add_points
  userId: integer("user_id").notNull().references(() => users.id),
  points: integer("points").notNull(),
  robux: integer("robux"),
  status: text("status").notNull().default("pending"),
  userNote: text("user_note"),
  adminNote: text("admin_note"),
  idempotencyKey: text("idempotency_key").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (t) => [uniqueIndex("req_idem_idx").on(t.userId, t.idempotencyKey)]);

export const conversations = pgTable("conversations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  requestId: integer("request_id").references(() => requests.id),
  subject: text("subject").notNull(),
  status: text("status").notNull().default("open"),
  userUnread: integer("user_unread").notNull().default(0),
  adminUnread: integer("admin_unread").notNull().default(0),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id").notNull().references(() => conversations.id),
  sender: text("sender").notNull(), // user | admin | system
  senderName: text("sender_name").notNull(),
  body: text("body").notNull(),
  internal: boolean("internal").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  forAdmin: boolean("for_admin").notNull().default(false),
  title: text("title").notNull(),
  body: text("body").notNull().default(""),
  link: text("link"),
  read: boolean("read").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const announcements = pgTable("announcements", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  body: text("body").notNull(),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  actor: text("actor").notNull(),
  action: text("action").notNull(),
  details: text("details").notNull().default(""),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const passwordResets = pgTable("password_resets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  tokenHash: text("token_hash").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  used: boolean("used").notNull().default(false),
});

export const settings = pgTable("settings", {
  key: text("key").primaryKey(),
  value: jsonb("value").notNull(),
});
