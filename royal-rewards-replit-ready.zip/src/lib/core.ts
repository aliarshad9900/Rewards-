import "server-only";
import crypto from "crypto";
import { db } from "@/db";
import { auditLogs, notifications, settings, transactions, wallets } from "@/db/schema";
import { eq } from "drizzle-orm";

export type Tx = Parameters<Parameters<typeof db.transaction>[0]>[0];
export type DbLike = typeof db | Tx;

export class AppError extends Error {
  status: number;
  constructor(msg: string, status = 400) { super(msg); this.status = status; }
}

export const genId = (prefix: string) => prefix + crypto.randomBytes(6).toString("hex").toUpperCase();

export function sanitize(s: unknown, max = 2000): string {
  if (typeof s !== "string") return "";
  // strip control chars and angle brackets; React escapes output anyway
  return s.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "").replace(/[<>]/g, "").trim().slice(0, max);
}

export const DEFAULT_SETTINGS = {
  siteName: "ROYAL REWARDS",
  logo: "👑",
  gold: "#f5c542",
  purple: "#1c1030",
  welcomeBonus: 250,
  rateP: 450,
  rateR: 50,
  redeemOptions: [50, 100, 200, 500] as number[],
  minAddPoints: 10,
  maxAddPoints: 10000,
  maintenance: false,
  maintenanceMessage: "Royal Rewards is undergoing scheduled maintenance. Please check back soon.",
  processingTime: "1–5 business days after approval",
  rewardNotice:
    "Redemptions are reviewed manually by administrators. Approval is not guaranteed and rewards are only fulfilled where the reward method is permitted and available. Royal Rewards is not affiliated with Roblox Corporation.",
  terms:
    "1. Points have no cash value.\n2. One account per person.\n3. Abuse, automation or exploiting bugs leads to suspension and forfeiture of points.\n4. All redemption and add-points requests require manual administrator approval.\n5. Administrators may adjust rewards, rates and games at any time.",
  aiAllowed: ["announcement_draft", "game_instructions"] as string[],
  globalEvent: "off" as "off" | "blessing" | "curse",
  globalEventPercent: 10,
};
export type SiteSettings = typeof DEFAULT_SETTINGS;

export async function getSettings(): Promise<SiteSettings> {
  const rows = await db.select().from(settings);
  const out: Record<string, unknown> = { ...DEFAULT_SETTINGS };
  for (const r of rows) out[r.key] = r.value;
  return out as SiteSettings;
}

export async function setSetting(key: keyof SiteSettings, value: unknown) {
  await db.insert(settings).values({ key, value }).onConflictDoUpdate({ target: settings.key, set: { value } });
}

/** Apply the currently active global event to a newly earned point reward. */
export async function applyGlobalEvent(basePoints: number) {
  const site = await getSettings();
  const multiplier = site.globalEvent === "blessing" ? 1 + site.globalEventPercent / 100 : site.globalEvent === "curse" ? 1 - site.globalEventPercent / 100 : 1;
  const points = Math.max(0, Math.round(basePoints * multiplier));
  const label = site.globalEvent === "blessing" ? `Blessing +${site.globalEventPercent}%` : site.globalEvent === "curse" ? `Curse -${site.globalEventPercent}%` : "";
  return { points, label, mode: site.globalEvent, percent: site.globalEventPercent };
}

export async function audit(actor: string, action: string, details = "", d: DbLike = db) {
  await d.insert(auditLogs).values({ actor, action, details: details.slice(0, 2000) });
}

export async function notify(d: DbLike, n: { userId?: number | null; forAdmin?: boolean; title: string; body?: string; link?: string }) {
  await d.insert(notifications).values({
    userId: n.userId ?? null, forAdmin: !!n.forAdmin, title: n.title, body: n.body ?? "", link: n.link ?? null,
  });
}

/** Atomically change a wallet. Must be called inside db.transaction. Locks the wallet row. */
export async function walletChange(tx: Tx, o: {
  userId: number; available?: number; reserved?: number; earned?: number; withdrawn?: number;
  type: string; description: string; refId?: string; status?: string; amount?: number; bypassFreeze?: boolean;
}) {
  const [w] = await tx.select().from(wallets).where(eq(wallets.userId, o.userId)).for("update");
  if (!w) throw new AppError("Wallet not found", 404);
  if (w.frozen && !o.bypassFreeze) throw new AppError("Your wallet is frozen. Contact admin.", 403);
  const av = w.available + (o.available ?? 0);
  const rs = w.reserved + (o.reserved ?? 0);
  if (av < 0) throw new AppError("Insufficient points");
  if (rs < 0) throw new AppError("Reserved balance error");
  await tx.update(wallets).set({
    available: av, reserved: rs,
    totalEarned: w.totalEarned + (o.earned ?? 0),
    totalWithdrawn: w.totalWithdrawn + (o.withdrawn ?? 0),
  }).where(eq(wallets.userId, o.userId));
  const id = genId("TX");
  await tx.insert(transactions).values({
    id, userId: o.userId, type: o.type, amount: o.amount ?? (o.available ?? 0),
    status: o.status ?? "completed", description: o.description, refId: o.refId ?? null,
  });
  return { id, available: av, reserved: rs };
}

const buckets = new Map<string, number[]>();
export function rateLimit(key: string, max: number, windowMs: number): boolean {
  const now = Date.now();
  const arr = (buckets.get(key) ?? []).filter((t) => now - t < windowMs);
  if (arr.length >= max) { buckets.set(key, arr); return false; }
  arr.push(now); buckets.set(key, arr);
  if (buckets.size > 5000) for (const [k, v] of buckets) if (!v.some((t) => now - t < 3600_000)) buckets.delete(k);
  return true;
}

export function errorJson(e: unknown) {
  if (e instanceof AppError) return Response.json({ error: e.message }, { status: e.status });
  console.error(e);
  return Response.json({ error: "Server error" }, { status: 500 });
}
