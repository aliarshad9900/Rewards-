import "server-only";
import { db } from "@/db";
import { conversations, messages, requests } from "@/db/schema";
import { and, eq, sql } from "drizzle-orm";
import { AppError, applyGlobalEvent, audit, getSettings, notify, walletChange, type Tx } from "./core";

export const STATUS_LABEL: Record<string, string> = { pending: "Pending", under_review: "Under Review", approved: "Approved", rejected: "Rejected", completed: "Completed" };

export async function createRequest(u: { id: number; userNumber: string; username: string }, kind: "withdrawal" | "add_points", amount: number, idem: string, note: string) {
  const s = await getSettings();
  let points: number, robux: number | null = null;
  if (kind === "withdrawal") {
    if (!s.redeemOptions.includes(amount)) throw new AppError("Invalid redemption option");
    robux = amount;
    points = Math.ceil((amount * s.rateP) / s.rateR);
  } else {
    if (!Number.isInteger(amount) || amount < s.minAddPoints || amount > s.maxAddPoints) throw new AppError(`Amount must be between ${s.minAddPoints} and ${s.maxAddPoints}`);
    points = amount;
  }
  if (!/^[a-zA-Z0-9-]{8,64}$/.test(idem)) throw new AppError("Invalid request key");
  const [existing] = await db.select().from(requests).where(and(eq(requests.userId, u.id), eq(requests.idempotencyKey, idem)));
  if (existing) {
    const [c] = await db.select().from(conversations).where(eq(conversations.requestId, existing.id));
    return { request: existing, conversationId: c?.id };
  }
  return db.transaction(async (tx) => {
    const [r] = await tx.insert(requests).values({ code: "TMP-" + idem, kind, userId: u.id, points, robux, userNote: note || null, idempotencyKey: idem }).returning();
    const code = (kind === "withdrawal" ? "WR" : "AP") + (10000 + r.id);
    await tx.update(requests).set({ code }).where(eq(requests.id, r.id));
    if (kind === "withdrawal") {
      await walletChange(tx, { userId: u.id, available: -points, reserved: points, type: "withdrawal_reserve", status: "pending", description: `Reserved for ${code} (${robux} Robux)`, refId: code });
    }
    const subject = kind === "withdrawal" ? `Withdrawal Request #${code}` : `Add Points Request #${code}`;
    const [c] = await tx.insert(conversations).values({ userId: u.id, requestId: r.id, subject, adminUnread: 1 }).returning();
    const summary = kind === "withdrawal"
      ? `${subject}\nRequested amount: ${robux} Robux\nPoints reserved: ${points}\nStatus: Pending`
      : `${subject}\nRequested points: ${points}\nStatus: Pending`;
    await tx.insert(messages).values({ conversationId: c.id, sender: "system", senderName: "Royal Rewards", body: summary });
    if (note) await tx.insert(messages).values({ conversationId: c.id, sender: "user", senderName: u.userNumber, body: note });
    await notify(tx, { userId: u.id, title: "Request submitted", body: `${subject} is pending review.`, link: `/app/messages/${c.id}` });
    await notify(tx, { forAdmin: true, title: kind === "withdrawal" ? "💸 New withdrawal request" : "➕ New add-points request", body: `${u.userNumber} – ${subject}`, link: `/admin/conversations/${c.id}` });
    await audit(u.userNumber, "request_created", `${code} ${kind} points=${points}`, tx);
    return { request: { ...r, code }, conversationId: c.id };
  });
}

const ALLOWED: Record<string, string[]> = {
  pending: ["under_review", "approved", "rejected"],
  under_review: ["pending", "approved", "rejected"],
  approved: ["completed", "rejected"],
  rejected: [], completed: [],
};

export async function setRequestStatus(requestId: number, status: string, actor: string, note?: string) {
  if (!STATUS_LABEL[status]) throw new AppError("Invalid status");
  return db.transaction(async (tx: Tx) => {
    const [r] = await tx.select().from(requests).where(eq(requests.id, requestId)).for("update");
    if (!r) throw new AppError("Request not found", 404);
    if (r.status === status) return r;
    if (!ALLOWED[r.status].includes(status)) throw new AppError(`Cannot move from ${STATUS_LABEL[r.status]} to ${STATUS_LABEL[status]}`);
    if (r.kind === "add_points" && r.status === "approved" && status === "rejected") throw new AppError("Points already added; use a manual deduction instead");
    if (r.kind === "withdrawal") {
      if (status === "rejected") await walletChange(tx, { userId: r.userId, available: r.points, reserved: -r.points, type: "withdrawal_refund", description: `${r.code} rejected – points returned`, refId: r.code, bypassFreeze: true });
      if (status === "completed") await walletChange(tx, { userId: r.userId, reserved: -r.points, withdrawn: r.points, amount: -r.points, status: "completed", type: "withdrawal_complete", description: `${r.code} completed – ${r.robux} Robux fulfilled by admin`, refId: r.code, bypassFreeze: true });
    } else if (status === "approved") {
      const adjusted = await applyGlobalEvent(r.points);
      await walletChange(tx, { userId: r.userId, available: adjusted.points, earned: adjusted.points, type: "add_points", description: `${r.code} approved by admin${adjusted.label ? ` (${adjusted.label})` : ""}`, refId: r.code, bypassFreeze: true });
    }
    const [u] = await tx.update(requests).set({ status, updatedAt: new Date(), adminNote: note ? note : r.adminNote }).where(eq(requests.id, r.id)).returning();
    const [c] = await tx.select().from(conversations).where(eq(conversations.requestId, r.id));
    if (c) {
      await tx.insert(messages).values({ conversationId: c.id, sender: "system", senderName: "Royal Rewards", body: `Status changed to: ${STATUS_LABEL[status]}${status === "rejected" && r.kind === "withdrawal" ? ` – ${r.points} points returned to your balance` : ""}${status === "approved" && r.kind === "add_points" ? ` – points added to your wallet (global event rules applied if active)` : ""}` });
      await tx.update(conversations).set({ userUnread: sql`${conversations.userUnread} + 1`, updatedAt: new Date() }).where(eq(conversations.id, c.id));
    }
    const titles: Record<string, string> = { approved: "✅ Request approved", rejected: "❌ Request rejected", completed: "🏆 Reward completed", under_review: "🔎 Request under review", pending: "Request pending" };
    await notify(tx, { userId: r.userId, title: titles[status], body: `${r.code}: ${STATUS_LABEL[status]}`, link: c ? `/app/messages/${c.id}` : "/app/wallet" });
    await audit(actor, "request_status", `${r.code}: ${r.status} → ${status}${note ? ` (${note})` : ""}`, tx);
    return u;
  });
}
