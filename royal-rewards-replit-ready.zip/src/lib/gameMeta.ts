export const GAME_KEYS = ["wheel", "box", "bunny", "lucky", "memory", "treasure", "cards", "daily"] as const;
export type GameKey = (typeof GAME_KEYS)[number];
export const GAME_META: Record<GameKey, { name: string; icon: string; tagline: string; grad: string }> = {
  wheel: { name: "Spin the Wheel", icon: "🎡", tagline: "Spin the royal wheel of fortune", grad: "from-fuchsia-700 via-purple-800 to-amber-600" },
  box: { name: "Box Opening", icon: "🎁", tagline: "Unseal a mystery box", grad: "from-purple-700 via-violet-900 to-yellow-600" },
  bunny: { name: "Find the Bunny", icon: "🐰", tagline: "One chance. Find the golden bunny.", grad: "from-amber-500 via-purple-800 to-black" },
  lucky: { name: "Lucky Number", icon: "🔢", tagline: "Pick the number fate has chosen", grad: "from-indigo-700 via-purple-900 to-amber-500" },
  memory: { name: "Memory Match", icon: "🃏", tagline: "Match every royal pair", grad: "from-violet-700 via-fuchsia-900 to-amber-600" },
  treasure: { name: "Treasure Hunt", icon: "💰", tagline: "Raid the royal treasure chests", grad: "from-yellow-600 via-amber-800 to-purple-900" },
  cards: { name: "Lucky Cards", icon: "🂡", tagline: "Flip a card, reveal your fate", grad: "from-red-700 via-purple-900 to-amber-500" },
  daily: { name: "Daily Reward", icon: "📅", tagline: "Claim daily, build your streak", grad: "from-emerald-600 via-purple-900 to-amber-500" },
};
export const MEMORY_SYMBOLS = ["👑", "💎", "🏆", "⚜️", "🗡️", "🛡️", "🦁", "🐉", "🔮", "🏰", "💍", "🪙"];
