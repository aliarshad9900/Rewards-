import "server-only";
import crypto from "crypto";
import { db } from "@/db";
import { dailyState, gameSessions, gameSettings, users } from "@/db/schema";
import { and, eq, gte, sql } from "drizzle-orm";
import { AppError, applyGlobalEvent, audit, genId, notify, rateLimit, walletChange, type Tx } from "./core";
import { GAME_KEYS, GAME_META, MEMORY_SYMBOLS, type GameKey } from "./gameMeta";

export type Outcome = { label: string; kind: "lose" | "refund" | "win"; reward: number; prob: number };
const STD: Outcome[] = [
  { label: "Lose", kind: "lose", reward: 0, prob: 50 },
  { label: "Money Back", kind: "refund", reward: 0, prob: 25 },
  { label: "Win 10", kind: "win", reward: 10, prob: 10 },
  { label: "Win 5", kind: "win", reward: 5, prob: 15 },
];

export const GAME_DEFAULTS: Record<GameKey, { entryCost: number; dailyLimit: number; instructions: string; config: Record<string, unknown> }> = {
  wheel: { entryCost: 5, dailyLimit: 0, instructions: "Pay the entry cost and press SPIN. The result is decided securely on our server before the wheel turns. 'Money Back' refunds your entry so you can try again.", config: { outcomes: STD } },
  box: { entryCost: 5, dailyLimit: 0, instructions: "Choose one mystery box and confirm. The server seals the contents before you open it. 'Money Back' refunds your entry.", config: { outcomes: STD, boxCount: 6, boxStyle: "mixed" } },
  bunny: { entryCost: 0, dailyLimit: 1, instructions: "The golden bunny hides in one box. You get exactly ONE pick per round. Find it to win the prize! Refreshing will not give you another attempt.", config: { boxes: 3, reward: 200 } },
  lucky: { entryCost: 5, dailyLimit: 0, instructions: "Choose one number. If it matches the server's secret winning number you win the jackpot. Neighbouring numbers may win a consolation prize.", config: { max: 10, reward: 40, nearReward: 0 } },
  memory: { entryCost: 5, dailyLimit: 0, instructions: "Flip two cards at a time to find matching pairs. Clear the board within the move limit to win. Every flip is verified by the server.", config: { pairs: 6, reward: 15, maxMoves: 14 } },
  treasure: { entryCost: 5, dailyLimit: 0, instructions: "Pick one treasure chest. Some hide royal gold, others are empty. Contents are determined by the server.", config: { chests: 6, outcomes: [
    { label: "Empty Chest", kind: "lose", reward: 0, prob: 55 },
    { label: "Coin Pouch", kind: "win", reward: 5, prob: 25 },
    { label: "Gold Pile", kind: "win", reward: 15, prob: 15 },
    { label: "Royal Treasure", kind: "win", reward: 50, prob: 5 },
  ] } },
  cards: { entryCost: 5, dailyLimit: 0, instructions: "Select one mystery card from the table. The server decides your fate before the card flips.", config: { cards: 5, outcomes: [
    { label: "Joker – Lose", kind: "lose", reward: 0, prob: 55 },
    { label: "Money Back", kind: "refund", reward: 0, prob: 20 },
    { label: "Queen +8", kind: "win", reward: 8, prob: 15 },
    { label: "King +20", kind: "win", reward: 20, prob: 10 },
  ] } },
  daily: { entryCost: 0, dailyLimit: 0, instructions: "Claim one reward per day (UTC). Claim on consecutive days to climb the 7-day calendar for bigger rewards.", config: { rewards: [5, 10, 15, 20, 25, 30, 60], resetOnMiss: true } },
};

export async function ensureGames() {
  await db.insert(gameSettings).values(GAME_KEYS.map((k) => ({ key: k, name: GAME_META[k].name, ...GAME_DEFAULTS[k] }))).onConflictDoNothing();
}
export async function getGame(key: string) {
  if (!(GAME_KEYS as readonly string[]).includes(key)) throw new AppError("Unknown game", 404);
  await ensureGames();
  const [g] = await db.select().from(gameSettings).where(eq(gameSettings.key, key));
  return g;
}

const int = (v: unknown, min: number, max: number, name: string) => {
  const n = Number(v);
  if (!Number.isInteger(n) || n < min || n > max) throw new AppError(`${name} must be a whole number between ${min} and ${max}`);
  return n;
};
export function validateOutcomes(raw: unknown): Outcome[] {
  if (!Array.isArray(raw) || raw.length < 2 || raw.length > 12) throw new AppError("Outcomes must have 2–12 entries");
  const out = raw.map((o: Record<string, unknown>, i) => {
    const kind = String(o.kind);
    if (!["lose", "refund", "win"].includes(kind)) throw new AppError(`Outcome ${i + 1}: invalid kind`);
    const prob = Number(o.prob);
    if (!Number.isFinite(prob) || prob < 0 || prob > 100 || Math.round(prob * 100) !== prob * 100) throw new AppError(`Outcome ${i + 1}: probability must be 0–100 with max 2 decimals`);
    return { label: String(o.label ?? "").slice(0, 30) || kind, kind: kind as Outcome["kind"], reward: kind === "win" ? int(o.reward, 0, 100000, "Reward") : 0, prob };
  });
  const total = out.reduce((s, o) => s + Math.round(o.prob * 100), 0);
  if (total !== 10000) throw new AppError(`Probabilities must total exactly 100% (currently ${total / 100}%)`);
  return out;
}
export function validateConfig(key: GameKey, c: Record<string, unknown>): Record<string, unknown> {
  switch (key) {
    case "wheel": return { outcomes: validateOutcomes(c.outcomes) };
    case "box": return { outcomes: validateOutcomes(c.outcomes), boxCount: int(c.boxCount, 2, 9, "Box count"), boxStyle: ["mixed", "gold", "purple"].includes(String(c.boxStyle)) ? c.boxStyle : "mixed" };
    case "bunny": return { boxes: int(c.boxes, 2, 9, "Boxes"), reward: int(c.reward, 0, 100000, "Reward") };
    case "lucky": return { max: int(c.max, 2, 50, "Range"), reward: int(c.reward, 0, 100000, "Reward"), nearReward: int(c.nearReward ?? 0, 0, 100000, "Near reward") };
    case "memory": return { pairs: int(c.pairs, 2, 12, "Pairs"), reward: int(c.reward, 0, 100000, "Reward"), maxMoves: int(c.maxMoves, 2, 200, "Max moves") };
    case "treasure": return { chests: int(c.chests, 2, 12, "Chests"), outcomes: validateOutcomes(c.outcomes) };
    case "cards": return { cards: int(c.cards, 2, 10, "Cards"), outcomes: validateOutcomes(c.outcomes) };
    case "daily": {
      if (!Array.isArray(c.rewards) || c.rewards.length !== 7) throw new AppError("Daily rewards must have 7 values");
      return { rewards: c.rewards.map((r) => int(r, 0, 100000, "Daily reward")), resetOnMiss: !!c.resetOnMiss };
    }
  }
}

function pickOutcome(outcomes: Outcome[]): number {
  const r = crypto.randomInt(0, 10000);
  let acc = 0;
  for (let i = 0; i < outcomes.length; i++) { acc += Math.round(outcomes[i].prob * 100); if (r < acc) return i; }
  return outcomes.length - 1;
}
function shuffle<T>(a: T[]): T[] {
  for (let i = a.length - 1; i > 0; i--) { const j = crypto.randomInt(0, i + 1); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
}
const today = () => new Date().toISOString().slice(0, 10);
const startOfDayUTC = () => new Date(today() + "T00:00:00.000Z");

/** Public view of a session (never leaks secrets) */
function publicSession(s: typeof gameSessions.$inferSelect) {
  const sec = s.secret as Record<string, unknown>;
  const base = { id: s.id, status: s.status, result: s.result, cost: s.cost };
  if (s.gameKey === "memory") {
    const deck = sec.deck as string[];
    const matched = sec.matched as number[];
    const open = sec.open as number[];
    return { ...base, memory: { size: deck.length, moves: sec.moves, maxMoves: sec.maxMoves, faces: Object.fromEntries([...matched, ...open].map((i) => [i, deck[i]])), matched } };
  }
  return base;
}

export async function gameState(userId: number, key: string) {
  const g = await getGame(key);
  const [open] = await db.select().from(gameSessions).where(and(eq(gameSessions.userId, userId), eq(gameSessions.gameKey, key), eq(gameSessions.status, "open"))).limit(1);
  const [{ c }] = await db.select({ c: sql<number>`count(*)::int` }).from(gameSessions).where(and(eq(gameSessions.userId, userId), eq(gameSessions.gameKey, key), gte(gameSessions.createdAt, startOfDayUTC())));
  const cfg = { ...g.config } as Record<string, unknown>;
  let daily = null;
  if (key === "daily") {
    const [d] = await db.select().from(dailyState).where(eq(dailyState.userId, userId));
    const t = today();
    const y = new Date(Date.now() - 86400_000).toISOString().slice(0, 10);
    const streakAlive = d?.lastClaimDay === t || d?.lastClaimDay === y;
    const streak = d ? (streakAlive || !cfg.resetOnMiss ? d.streak : 0) : 0;
    const claimedToday = d?.lastClaimDay === t;
    const next = new Date(startOfDayUTC().getTime() + 86400_000);
    daily = { streak, claimedToday, nextDayIndex: claimedToday ? streak % 7 : streak % 7, nextReset: next.toISOString() };
  }
  return {
    game: { key: g.key, name: g.name, enabled: g.enabled, entryCost: g.entryCost, dailyLimit: g.dailyLimit, instructions: g.instructions, config: cfg },
    session: open ? publicSession(open) : null,
    playsToday: c, daily,
  };
}

async function finish(tx: Tx, s: typeof gameSessions.$inferSelect, outcome: { kind: string; reward: number; label: string; extra?: Record<string, unknown> }) {
  let reward = 0;
  const name = GAME_META[s.gameKey as GameKey].name;
  if (outcome.kind === "refund" && s.cost > 0) {
    await walletChange(tx, { userId: s.userId, available: s.cost, type: "game_refund", description: `${name}: money back`, refId: s.id, bypassFreeze: true });
  } else if (outcome.kind === "win" && outcome.reward > 0) {
    const adjusted = await applyGlobalEvent(outcome.reward);
    reward = adjusted.points;
    const eventLabel = adjusted.label ? ` (${adjusted.label})` : "";
    await walletChange(tx, { userId: s.userId, available: reward, earned: reward, type: "game_win", description: `${name}: ${outcome.label}${eventLabel}`, refId: s.id, bypassFreeze: true });
    await notify(tx, { userId: s.userId, title: `🎉 You won ${reward} points!`, body: `${name} — ${outcome.label}${eventLabel}`, link: "/app/history" });
  }
  const result = { kind: outcome.kind, reward, label: outcome.label, refund: outcome.kind === "refund" ? s.cost : 0, ...(outcome.extra ?? {}) };
  await tx.update(gameSessions).set({ status: "finished", result, reward, finishedAt: new Date() }).where(eq(gameSessions.id, s.id));
  return result;
}

export async function startGame(userId: number, userNumber: string, key: string) {
  const g = await getGame(key);
  if (key === "daily") throw new AppError("Use claim for daily reward");
  if (!g.enabled) throw new AppError("This game is currently disabled", 403);
  if (!rateLimit(`game:${userId}`, 30, 60_000)) {
    await db.update(users).set({ flagged: true }).where(eq(users.id, userId));
    await notify(db, { forAdmin: true, title: "⚠️ Suspicious activity", body: `${userNumber} exceeded game rate limits`, link: "/admin/users?q=" + userNumber });
    await audit("system", "suspicious_activity", `${userNumber} game rate limit exceeded`);
    throw new AppError("Too many attempts. Slow down.", 429);
  }
  return db.transaction(async (tx) => {
    // serialize per-user per-game starts
    await tx.execute(sql`select pg_advisory_xact_lock(${userId}, ${GAME_KEYS.indexOf(key as GameKey)})`);
    const [open] = await tx.select().from(gameSessions).where(and(eq(gameSessions.userId, userId), eq(gameSessions.gameKey, key), eq(gameSessions.status, "open"))).limit(1);
    if (open) return publicSession(open); // refreshing never grants a new roll
    if (g.dailyLimit > 0) {
      const [{ c }] = await tx.select({ c: sql<number>`count(*)::int` }).from(gameSessions).where(and(eq(gameSessions.userId, userId), eq(gameSessions.gameKey, key), gte(gameSessions.createdAt, startOfDayUTC())));
      if (c >= g.dailyLimit) throw new AppError(`Daily attempt limit reached (${g.dailyLimit}). Come back tomorrow!`, 429);
    }
    const id = genId("GS");
    if (g.entryCost > 0) await walletChange(tx, { userId, available: -g.entryCost, type: "game_entry", description: `${g.name}: entry`, refId: id });
    const cfg = g.config as Record<string, unknown>;
    let secret: Record<string, unknown> = {};
    if (cfg.outcomes) secret = { outcome: pickOutcome(cfg.outcomes as Outcome[]) };
    if (key === "bunny") secret = { pos: crypto.randomInt(0, Number(cfg.boxes)) };
    if (key === "lucky") secret = { number: crypto.randomInt(1, Number(cfg.max) + 1) };
    if (key === "memory") {
      const pairs = Number(cfg.pairs);
      const syms = MEMORY_SYMBOLS.slice(0, pairs);
      secret = { deck: shuffle([...syms, ...syms]), matched: [], open: [], moves: 0, maxMoves: Number(cfg.maxMoves), reward: Number(cfg.reward) };
    }
    const [s] = await tx.insert(gameSessions).values({ id, userId, gameKey: key, secret, cost: g.entryCost }).returning();
    return publicSession(s);
  });
}

export async function playGame(userId: number, key: string, sessionId: string, choice: number) {
  const g = await getGame(key);
  return db.transaction(async (tx) => {
    const [s] = await tx.select().from(gameSessions).where(and(eq(gameSessions.id, sessionId), eq(gameSessions.userId, userId), eq(gameSessions.gameKey, key))).for("update");
    if (!s) throw new AppError("Session not found", 404);
    if (s.status !== "open") throw new AppError("This round is already finished", 409);
    const sec = s.secret as Record<string, unknown>;
    const cfg = g.config as Record<string, unknown>;
    if (key === "memory") return memoryFlip(tx, s, choice);
    if (cfg.outcomes && key !== "lucky" && key !== "bunny") {
      const outs = cfg.outcomes as Outcome[];
      const idx = Math.min(Number(sec.outcome), outs.length - 1);
      const o = outs[idx];
      return { result: await finish(tx, s, { ...o, extra: { index: idx, choice } }) };
    }
    if (key === "bunny") {
      const boxes = Number(cfg.boxes);
      if (!Number.isInteger(choice) || choice < 0 || choice >= boxes) throw new AppError("Invalid box");
      const win = choice === sec.pos;
      return { result: await finish(tx, s, { kind: win ? "win" : "lose", reward: Number(cfg.reward), label: win ? "Found the golden bunny!" : "The bunny was elsewhere", extra: { pos: sec.pos, choice } }) };
    }
    if (key === "lucky") {
      const max = Number(cfg.max);
      if (!Number.isInteger(choice) || choice < 1 || choice > max) throw new AppError("Invalid number");
      const n = Number(sec.number);
      const exact = choice === n, near = Math.abs(choice - n) === 1 && Number(cfg.nearReward) > 0;
      return { result: await finish(tx, s, { kind: exact || near ? "win" : "lose", reward: exact ? Number(cfg.reward) : Number(cfg.nearReward), label: exact ? `Exact match: ${n}` : near ? `So close! Number was ${n}` : `Winning number was ${n}`, extra: { number: n, choice } }) };
    }
    throw new AppError("Unsupported");
  });
}

async function memoryFlip(tx: Tx, s: typeof gameSessions.$inferSelect, idx: number) {
  const sec = { ...(s.secret as Record<string, unknown>) };
  const deck = sec.deck as string[];
  let open = [...(sec.open as number[])];
  const matched = [...(sec.matched as number[])];
  let moves = Number(sec.moves);
  if (!Number.isInteger(idx) || idx < 0 || idx >= deck.length) throw new AppError("Invalid card");
  if (open.length === 2) open = []; // previous mismatch flips back
  if (matched.includes(idx) || open.includes(idx)) throw new AppError("Card already face up");
  open.push(idx);
  let mismatch: number[] | null = null;
  if (open.length === 2) {
    moves++;
    if (deck[open[0]] === deck[open[1]]) { matched.push(...open); open = []; }
    else mismatch = [...open];
  }
  const faces = Object.fromEntries([...matched, ...open].map((i) => [i, deck[i]]));
  const updated = { ...sec, open, matched, moves };
  await tx.update(gameSessions).set({ secret: updated }).where(eq(gameSessions.id, s.id));
  let result = null;
  if (matched.length === deck.length) {
    const win = moves <= Number(sec.maxMoves);
    result = await finish(tx, s, { kind: win ? "win" : "lose", reward: Number(sec.reward), label: win ? `Board cleared in ${moves} moves` : `Cleared in ${moves} moves (limit ${sec.maxMoves})`, extra: { moves } });
  } else if (moves >= Number(sec.maxMoves) && mismatch) {
    result = await finish(tx, s, { kind: "lose", reward: 0, label: `Out of moves (${moves})`, extra: { moves, deck } });
  }
  return { memory: { faces, matched, moves, mismatch, maxMoves: sec.maxMoves }, result };
}

export async function claimDaily(userId: number) {
  const g = await getGame("daily");
  if (!g.enabled) throw new AppError("Daily reward is currently disabled", 403);
  const cfg = g.config as { rewards: number[]; resetOnMiss: boolean };
  return db.transaction(async (tx) => {
    await tx.insert(dailyState).values({ userId }).onConflictDoNothing();
    const [d] = await tx.select().from(dailyState).where(eq(dailyState.userId, userId)).for("update");
    const t = today();
    if (d.lastClaimDay === t) throw new AppError("Already claimed today. Come back tomorrow!", 409);
    const y = new Date(Date.now() - 86400_000).toISOString().slice(0, 10);
    const streak = d.lastClaimDay === y || !cfg.resetOnMiss ? d.streak + 1 : 1;
    const dayIdx = (streak - 1) % 7;
    const baseReward = cfg.rewards[dayIdx];
    const adjusted = await applyGlobalEvent(baseReward);
    const reward = adjusted.points;
    await tx.update(dailyState).set({ streak, lastClaimDay: t }).where(eq(dailyState.userId, userId));
    const id = genId("GS");
    await tx.insert(gameSessions).values({ id, userId, gameKey: "daily", status: "finished", reward, result: { kind: "win", reward, baseReward, label: `Day ${dayIdx + 1}` }, finishedAt: new Date() });
    if (reward > 0) {
      const eventLabel = adjusted.label ? ` (${adjusted.label})` : "";
      await walletChange(tx, { userId, available: reward, earned: reward, type: "daily_reward", description: `Daily reward – day ${dayIdx + 1} (streak ${streak})${eventLabel}`, refId: id });
      await notify(tx, { userId, title: `📅 Daily reward: +${reward} points`, body: `Streak: ${streak} day(s)${eventLabel}` });
    }
    return { reward, baseReward, streak, dayIdx };
  });
}
