import "server-only";
import crypto from "crypto";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { db } from "@/db";
import { admins, profiles, sessions, users, wallets } from "@/db/schema";
import { and, eq, gt } from "drizzle-orm";

export const OWNER_EMAIL = (process.env.OWNER_EMAIL || "aliarshadswl99@gmail.com").trim().toLowerCase();
export const USER_COOKIE = "rr_s";
export const ADMIN_COOKIE = "rr_a";
export const PERMS = ["users", "wallets", "games", "requests", "chat", "settings", "audit", "ai"] as const;
export type Perm = (typeof PERMS)[number];

export function hashPassword(pw: string): string {
  const salt = crypto.randomBytes(16).toString("hex");
  const h = crypto.scryptSync(pw, salt, 64).toString("hex");
  return `scrypt$${salt}$${h}`;
}
export function verifyPassword(pw: string, stored: string): boolean {
  const [, salt, h] = stored.split("$");
  if (!salt || !h) return false;
  const calc = crypto.scryptSync(pw, salt, 64);
  const buf = Buffer.from(h, "hex");
  return buf.length === calc.length && crypto.timingSafeEqual(buf, calc);
}
export const sha256 = (s: string) => crypto.createHash("sha256").update(s).digest("hex");

export async function createSession(kind: "user" | "admin", id: number) {
  const token = crypto.randomBytes(32).toString("base64url");
  const ttl = kind === "user" ? 7 * 86400_000 : 12 * 3600_000;
  await db.insert(sessions).values({
    id: sha256(token), userId: kind === "user" ? id : null, adminId: kind === "admin" ? id : null,
    expiresAt: new Date(Date.now() + ttl),
  });
  const c = await cookies();
  c.set(kind === "user" ? USER_COOKIE : ADMIN_COOKIE, token, {
    httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production" && process.env.INSECURE_COOKIES !== "1",
    path: "/", maxAge: ttl / 1000,
  });
}

export async function destroySession(kind: "user" | "admin") {
  const c = await cookies();
  const name = kind === "user" ? USER_COOKIE : ADMIN_COOKIE;
  const t = c.get(name)?.value;
  if (t) await db.delete(sessions).where(eq(sessions.id, sha256(t)));
  c.delete(name);
}

export async function getUser() {
  const c = await cookies();
  const t = c.get(USER_COOKIE)?.value;
  if (!t) return null;
  const [row] = await db
    .select({ user: users, wallet: wallets, profile: profiles })
    .from(sessions)
    .innerJoin(users, eq(users.id, sessions.userId))
    .innerJoin(wallets, eq(wallets.userId, users.id))
    .leftJoin(profiles, eq(profiles.userId, users.id))
    .where(and(eq(sessions.id, sha256(t)), gt(sessions.expiresAt, new Date())));
  if (!row) return null;
  return row;
}
export type CurrentUser = NonNullable<Awaited<ReturnType<typeof getUser>>>;

export async function requireUser() {
  const u = await getUser();
  if (!u) redirect("/login");
  return u;
}

/** For API routes: returns active (non-suspended) user or null */
export async function apiUser() {
  const u = await getUser();
  if (!u || u.user.status !== "active") return null;
  db.update(users).set({ lastActiveAt: new Date() }).where(eq(users.id, u.user.id)).catch(() => {});
  return u;
}

export async function getAdmin() {
  const c = await cookies();
  const t = c.get(ADMIN_COOKIE)?.value;
  if (!t) return null;
  const [row] = await db
    .select({ admin: admins })
    .from(sessions)
    .innerJoin(admins, eq(admins.id, sessions.adminId))
    .where(and(eq(sessions.id, sha256(t)), gt(sessions.expiresAt, new Date())));
  if (!row || !row.admin.active) return null;
  // Owner role is only valid for the verified owner email
  if (row.admin.role === "owner" && row.admin.email !== OWNER_EMAIL) return null;
  return row.admin;
}
export type CurrentAdmin = NonNullable<Awaited<ReturnType<typeof getAdmin>>>;

export function hasPerm(a: CurrentAdmin, p: Perm | "owner") {
  if (a.role === "owner") return true;
  if (p === "owner") return false;
  if (a.role === "support") return p === "chat";
  return a.permissions.includes(p);
}

export async function requireAdmin(p?: Perm | "owner") {
  const a = await getAdmin();
  if (!a) redirect("/admin/login");
  if (p && !hasPerm(a, p)) redirect("/admin?denied=1");
  return a;
}
export async function apiAdmin(p?: Perm | "owner") {
  const a = await getAdmin();
  if (!a) return null;
  if (p && !hasPerm(a, p)) return null;
  return a;
}
