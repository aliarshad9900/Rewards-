import { db } from "@/db";
import { transactions } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { and, desc, eq, type SQL } from "drizzle-orm";
import { PageTitle, Status, TX_LABEL, fmt } from "@/components/bits";

export default async function History({ searchParams }: { searchParams: Promise<{ type?: string; status?: string }> }) {
  const u = await requireUser(); const sp = await searchParams;
  const conds: SQL[] = [eq(transactions.userId, u.user.id)];
  if (sp.type && TX_LABEL[sp.type]) conds.push(eq(transactions.type, sp.type));
  if (sp.status === "pending" || sp.status === "completed") conds.push(eq(transactions.status, sp.status));
  const rows = await db.select().from(transactions).where(and(...conds)).orderBy(desc(transactions.createdAt)).limit(300);
  return (
    <div>
      <PageTitle title="Transaction History" sub="A permanent record of every point movement." icon="📜" />
      <form className="card p-4 mb-4 flex flex-wrap gap-3 items-end">
        <div><label className="label">Type</label><select name="type" defaultValue={sp.type ?? ""} className="input"><option value="">All types</option>{Object.entries(TX_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></div>
        <div><label className="label">Status</label><select name="status" defaultValue={sp.status ?? ""} className="input"><option value="">All</option><option value="completed">Completed</option><option value="pending">Pending</option></select></div>
        <button className="btn-gold">Filter</button>
      </form>
      <div className="card overflow-x-auto"><table className="table min-w-[640px]"><thead><tr><th>Transaction ID</th><th>Date</th><th>Type</th><th>Points</th><th>Status</th><th>Description</th></tr></thead>
        <tbody>{rows.map((t) => <tr key={t.id}><td className="font-mono text-xs text-gray-400">{t.id}</td><td className="whitespace-nowrap">{fmt(t.createdAt)}</td><td>{TX_LABEL[t.type] ?? t.type}</td><td className={t.amount > 0 ? "text-green-400 font-bold" : t.amount < 0 ? "text-red-300 font-bold" : ""}>{t.amount > 0 ? "+" : ""}{t.amount}</td><td><Status s={t.status} /></td><td className="text-gray-300">{t.description}</td></tr>)}
        {!rows.length && <tr><td colSpan={6} className="text-center text-gray-500 py-8">No transactions found.</td></tr>}</tbody></table></div>
    </div>
  );
}
