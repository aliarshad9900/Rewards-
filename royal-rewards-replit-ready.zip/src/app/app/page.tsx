import Link from "next/link";
import { db } from "@/db";
import { announcements, gameSessions, requests, transactions } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { and, desc, eq, inArray } from "drizzle-orm";
import { GAME_META, type GameKey } from "@/lib/gameMeta";
import { Status, TX_LABEL, fmt } from "@/components/bits";

const CARDS = [
  { href: "/app/games", icon: "🎮", t: "Play Games", d: "8 royal games" },
  { href: "/app/wallet", icon: "👛", t: "My Wallet", d: "Balance & totals" },
  { href: "/app/redeem", icon: "🎁", t: "Redeem Rewards", d: "Request a reward" },
  { href: "/app/add-points", icon: "➕", t: "Add Points Request", d: "Ask admin for points" },
  { href: "/app/messages", icon: "💬", t: "Contact Admin", d: "Private support chat" },
  { href: "/app/history", icon: "📜", t: "Transaction History", d: "Every point, recorded" },
  { href: "/app/profile", icon: "⚙️", t: "Profile & Settings", d: "Avatar & security" },
];

export default async function Dashboard() {
  const u = await requireUser();
  const [recentGames, recentTx, pending, ann] = await Promise.all([
    db.select().from(gameSessions).where(and(eq(gameSessions.userId, u.user.id), eq(gameSessions.status, "finished"))).orderBy(desc(gameSessions.createdAt)).limit(5),
    db.select().from(transactions).where(eq(transactions.userId, u.user.id)).orderBy(desc(transactions.createdAt)).limit(6),
    db.select().from(requests).where(and(eq(requests.userId, u.user.id), inArray(requests.status, ["pending", "under_review", "approved"]))).orderBy(desc(requests.createdAt)),
    db.select().from(announcements).where(eq(announcements.active, true)).orderBy(desc(announcements.createdAt)).limit(3),
  ]);
  return (
    <div className="space-y-8">
      <section className="grid lg:grid-cols-5 gap-5">
        <div className="lg:col-span-3 card p-6 md:p-8 relative overflow-hidden">
          <div className="absolute -right-10 -top-10 text-[180px] opacity-10 anim-float">👑</div>
          <p className="text-gray-400 text-sm">Hello, {u.profile?.displayName ?? u.user.username} · {u.user.userNumber}</p>
          <h1 className="text-3xl md:text-4xl font-black mt-1 font-royal text-gold-grad">Welcome to Royal Rewards</h1>
          <p className="text-gray-300 mt-2">Play games. Earn points. Unlock rewards.</p>
          <div className="mt-6 flex flex-wrap gap-3"><Link href="/app/games" className="btn-gold">🎮 Play now</Link><Link href="/app/games/daily" className="btn-ghost">📅 Daily reward</Link></div>
        </div>
        <Link href="/app/wallet" className="lg:col-span-2 card glow-gold anim-glow p-6 md:p-8 flex flex-col justify-center relative overflow-hidden">
          <div className="absolute inset-0 shimmer opacity-30" />
          <p className="text-xs tracking-[.3em] text-gray-300">YOUR BALANCE</p>
          <p className="text-5xl md:text-6xl font-black text-gold-grad mt-2">{u.wallet.available.toLocaleString()}</p>
          <p className="tracking-[.3em] text-gold font-bold">POINTS</p>
          {u.wallet.reserved > 0 && <p className="text-xs text-gray-400 mt-2">+ {u.wallet.reserved} pending in requests</p>}
          {u.wallet.frozen && <p className="text-xs text-red-300 mt-2">⚠️ Wallet frozen by admin</p>}
        </Link>
      </section>

      {ann.length > 0 && <section className="space-y-2">{ann.map((a) => <div key={a.id} className="card p-4 border-l-4 !border-l-gold"><p className="font-bold text-gold">📣 {a.title}</p><p className="text-sm text-gray-300 whitespace-pre-line">{a.body}</p></div>)}</section>}

      <section className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-7 gap-3">
        {CARDS.map((c) => <Link key={c.href + c.t} href={c.href} className="card card-hover p-4 text-center"><div className="text-3xl mb-2">{c.icon}</div><div className="font-bold text-sm">{c.t}</div><div className="text-xs text-gray-500">{c.d}</div></Link>)}
      </section>

      <section className="grid lg:grid-cols-3 gap-5">
        <div className="card p-5"><h3 className="font-bold mb-3 text-gold">🕹️ Recently played</h3>
          {recentGames.length ? recentGames.map((g) => { const m = GAME_META[g.gameKey as GameKey]; return <Link key={g.id} href={`/app/games/${g.gameKey}`} className="flex items-center justify-between py-2 border-b border-white/5 text-sm"><span>{m?.icon} {m?.name}</span><span className={g.reward > 0 ? "text-green-400 font-bold" : "text-gray-500"}>{g.reward > 0 ? `+${g.reward}` : String((g.result as { label?: string })?.label ?? "—")}</span></Link>; }) : <p className="text-sm text-gray-500">No games yet — try your luck!</p>}
        </div>
        <div className="card p-5"><h3 className="font-bold mb-3 text-gold">📜 Recent transactions</h3>
          {recentTx.map((t) => <div key={t.id} className="flex items-center justify-between py-2 border-b border-white/5 text-sm"><div><div>{TX_LABEL[t.type] ?? t.type}</div><div className="text-xs text-gray-500">{fmt(t.createdAt)}</div></div><span className={t.amount > 0 ? "text-green-400 font-bold" : t.amount < 0 ? "text-red-300 font-bold" : "text-gray-400"}>{t.amount > 0 ? "+" : ""}{t.amount}</span></div>)}
          <Link href="/app/history" className="text-xs text-gold mt-3 inline-block">View all →</Link>
        </div>
        <div className="card p-5"><h3 className="font-bold mb-3 text-gold">⏳ Pending requests</h3>
          {pending.length ? pending.map((r) => <div key={r.id} className="flex items-center justify-between py-2 border-b border-white/5 text-sm"><div><div className="font-semibold">#{r.code}</div><div className="text-xs text-gray-500">{r.kind === "withdrawal" ? `${r.robux} Robux` : `${r.points} points`}</div></div><Status s={r.status} /></div>) : <p className="text-sm text-gray-500">No pending requests.</p>}
        </div>
      </section>
    </div>
  );
}
