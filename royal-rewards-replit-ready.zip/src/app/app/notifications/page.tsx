import Link from "next/link";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { desc, eq } from "drizzle-orm";
import { PageTitle, fmt } from "@/components/bits";
import { MarkRead } from "@/components/MarkRead";

export default async function N() {
  const u = await requireUser();
  const rows = await db.select().from(notifications).where(eq(notifications.userId, u.user.id)).orderBy(desc(notifications.createdAt)).limit(100);
  return (
    <div>
      <PageTitle title="Notifications" icon="🔔" />
      <MarkRead />
      <div className="space-y-2">{rows.map((n) => { const inner = <div className={`card p-4 ${n.read ? "opacity-70" : "!border-gold/60"}`}><div className="flex justify-between gap-2"><span className="font-bold">{n.title}</span><span className="text-xs text-gray-500 whitespace-nowrap">{fmt(n.createdAt)}</span></div><p className="text-sm text-gray-400">{n.body}</p></div>; return n.link ? <Link key={n.id} href={n.link} className="block">{inner}</Link> : <div key={n.id}>{inner}</div>; })}
        {!rows.length && <p className="text-gray-500">No notifications yet.</p>}</div>
    </div>
  );
}
