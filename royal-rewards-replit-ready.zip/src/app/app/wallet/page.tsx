import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { PageTitle, Stat } from "@/components/bits";

export default async function Wallet() {
  const u = await requireUser(); const w = u.wallet;
  return (
    <div>
      <PageTitle title="My Wallet" sub="Your points are stored securely and can only change through verified server transactions." icon="👛" />
      <div className="card glow-gold p-8 text-center mb-6 relative overflow-hidden"><div className="absolute inset-0 shimmer opacity-20" /><p className="tracking-[.3em] text-xs text-gray-300">AVAILABLE POINTS</p><p className="text-6xl font-black text-gold-grad">{w.available.toLocaleString()}</p>{w.frozen && <p className="text-red-300 mt-2">⚠️ Your wallet is frozen. Contact admin.</p>}</div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Stat label="Available" value={w.available} icon="🪙" />
        <Stat label="Pending" value={w.reserved} icon="⏳" hint="Reserved in withdrawal requests" />
        <Stat label="Total earned" value={w.totalEarned} icon="📈" />
        <Stat label="Total withdrawn" value={w.totalWithdrawn} icon="🏆" />
      </div>
      <div className="flex flex-wrap gap-3 mt-6"><Link href="/app/redeem" className="btn-gold">🎁 Redeem rewards</Link><Link href="/app/add-points" className="btn-ghost">➕ Request points</Link><Link href="/app/history" className="btn-ghost">📜 History</Link></div>
    </div>
  );
}
