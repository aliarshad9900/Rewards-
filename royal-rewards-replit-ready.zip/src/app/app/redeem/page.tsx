import { requireUser } from "@/lib/auth";
import { getSettings } from "@/lib/core";
import { PageTitle } from "@/components/bits";
import { RequestForm } from "@/components/RequestForm";

export default async function Redeem() {
  const u = await requireUser(); const s = await getSettings();
  return (
    <div className="grid lg:grid-cols-3 gap-5">
      <div className="lg:col-span-2"><PageTitle title="Redeem Rewards" sub="Submit a redemption request for administrator review." icon="🎁" />
        <RequestForm kind="withdrawal" balance={u.wallet.available} options={s.redeemOptions} rateP={s.rateP} rateR={s.rateR} /></div>
      <aside className="space-y-4 lg:pt-16">
        <div className="card glow-gold p-5 text-center"><p className="text-xs tracking-widest text-gray-400">AVAILABLE</p><p className="text-4xl font-black text-gold">{u.wallet.available.toLocaleString()}</p><p className="text-sm text-gray-400">points</p></div>
        <div className="card p-5"><p className="text-xs tracking-widest text-gray-400">CONVERSION RATE</p><p className="text-xl font-bold text-gold">{s.rateP} points = {s.rateR} Robux</p></div>
        <div className="card p-5 text-sm text-gray-300 space-y-2"><p className="font-bold text-gold">Eligibility & terms</p><p>⏱️ Processing: {s.processingTime}</p><p>{s.rewardNotice}</p><p className="text-xs text-gray-500">Statuses: Pending → Under Review → Approved → Completed (or Rejected with points returned).</p></div>
      </aside>
    </div>
  );
}
