import { requireUser } from "@/lib/auth";
import { getSettings } from "@/lib/core";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { and, eq, sql } from "drizzle-orm";
import { UserShell } from "@/components/UserShell";
import { Logo } from "@/components/Logo";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const u = await requireUser();
  const s = await getSettings();
  if (u.user.status !== "active" || s.maintenance) {
    return <main className="min-h-screen grid place-items-center p-6"><div className="card glow-gold p-8 max-w-md text-center space-y-4"><Logo name={s.siteName} logo={s.logo} /><div className="text-5xl">{s.maintenance ? "🛠️" : "⛔"}</div><p className="text-gray-300">{s.maintenance ? s.maintenanceMessage : "Your account has been suspended. Please contact support."}</p><form action="/api/auth/logout" method="post"><a href="/login" className="btn-ghost">Back</a></form></div></main>;
  }
  const [{ c }] = await db.select({ c: sql<number>`count(*)::int` }).from(notifications).where(and(eq(notifications.userId, u.user.id), eq(notifications.read, false)));
  return <UserShell userNumber={u.user.userNumber} balance={u.wallet.available} unread={c} avatar={u.profile?.avatar ?? "👑"} siteName={s.siteName} logo={s.logo} globalEvent={s.globalEvent} globalEventPercent={s.globalEventPercent}>{children}</UserShell>;
}
