import { requireUser } from "@/lib/auth";
import { PageTitle, fmt } from "@/components/bits";
import { ProfileForms } from "@/components/ProfileForms";
export default async function Profile() {
  const u = await requireUser();
  return (<div><PageTitle title="Profile & Settings" icon="👤" />
    <div className="card p-6 mb-5 flex items-center gap-5"><div className="w-20 h-20 rounded-full grid place-items-center text-4xl bg-gradient-to-br from-purple-600 to-amber-500 glow-gold">{u.profile?.avatar ?? "👑"}</div><div><div className="text-xl font-bold">{u.profile?.displayName ?? u.user.username}</div><div className="text-gold font-mono">{u.user.userNumber}</div><div className="text-xs text-gray-500">@{u.user.username} · joined {fmt(u.user.createdAt)}</div></div></div>
    <ProfileForms displayName={u.profile?.displayName ?? ""} avatar={u.profile?.avatar ?? "👑"} bio={u.profile?.bio ?? ""} /></div>);
}
