import { requireUser } from "@/lib/auth";
import { getSettings } from "@/lib/core";
import { PageTitle } from "@/components/bits";
import { RequestForm } from "@/components/RequestForm";

export default async function AddPoints() {
  const u = await requireUser(); const s = await getSettings();
  return (
    <div className="grid lg:grid-cols-3 gap-5">
      <div className="lg:col-span-2"><PageTitle title="Add Points Request" sub="Ask an administrator to credit points to your wallet." icon="➕" />
        <RequestForm kind="add_points" balance={u.wallet.available} min={s.minAddPoints} max={s.maxAddPoints} /></div>
      <aside className="space-y-4 lg:pt-16">
        <div className="card glow-gold p-5 text-center"><p className="text-xs tracking-widest text-gray-400">CURRENT BALANCE</p><p className="text-4xl font-black text-gold">{u.wallet.available.toLocaleString()}</p></div>
        <div className="card p-5 text-sm text-gray-300 space-y-2"><p className="font-bold text-gold">How it works</p><ol className="list-decimal pl-5 space-y-1"><li>Choose the amount.</li><li>Review the summary and submit.</li><li>You are taken to a private chat with admin.</li><li>Admin reviews and approves or rejects.</li><li>If approved, points are added securely and you are notified.</li></ol></div>
      </aside>
    </div>
  );
}
