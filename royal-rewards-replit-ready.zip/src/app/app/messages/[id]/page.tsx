import { ChatClient } from "@/components/ChatClient";
export default async function P({ params }: { params: Promise<{ id: string }> }) { return <ChatClient id={Number((await params).id)} />; }
