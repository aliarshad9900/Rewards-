import Link from "next/link";
import { db } from "@/db";
import { conversations } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { desc, eq } from "drizzle-orm";
import { PageTitle, Status, fmt } from "@/components/bits";
import { NewConversation } from "@/components/NewConversation";

export default async function Msgs() {
  const u = await requireUser();
  const rows = await db.select().from(conversations).where(eq(conversations.userId, u.user.id)).orderBy(desc(conversations.updatedAt));
  return (
    <div className="grid lg:grid-cols-3 gap-5">
      <div className="lg:col-span-2"><PageTitle title="Messages" sub="Private conversations with the Royal Rewards team." icon="💬" />
        <div className="space-y-2">{rows.map((c) => <Link key={c.id} href={`/app/messages/${c.id}`} className="card card-hover p-4 flex items-center justify-between gap-3"><div><div className="font-bold">{c.subject}</div><div className="text-xs text-gray-500">Updated {fmt(c.updatedAt)}</div></div><div className="flex items-center gap-2">{c.userUnread > 0 && <span className="badge bg-red-500 text-white">{c.userUnread} new</span>}<Status s={c.status} /></div></Link>)}
          {!rows.length && <p className="text-gray-500">No conversations yet.</p>}</div></div>
      <NewConversation />
    </div>
  );
}
