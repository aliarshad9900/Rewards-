import { notFound } from "next/navigation";
import { GAME_KEYS, type GameKey } from "@/lib/gameMeta";
import { GameClient } from "@/components/games/GameClient";
export default async function P({ params }: { params: Promise<{ key: string }> }) {
  const { key } = await params;
  if (!(GAME_KEYS as readonly string[]).includes(key)) notFound();
  return <GameClient gameKey={key as GameKey} />;
}
