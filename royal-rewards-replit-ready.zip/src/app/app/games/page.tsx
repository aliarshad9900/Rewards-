import Link from "next/link";
import { db } from "@/db";
import { gameSettings } from "@/db/schema";
import { ensureGames } from "@/lib/games";
import { GAME_KEYS, GAME_META } from "@/lib/gameMeta";
import { PageTitle } from "@/components/bits";

export default async function Games() {
  await ensureGames();
  const rows = await db.select().from(gameSettings);
  const map = Object.fromEntries(rows.map((r) => [r.key, r]));
  return (
    <div>
      <PageTitle title="Royal Games" sub="Every result is decided securely on our servers." icon="🎮" />
      <div className="grid sm:grid-cols-2 xl:grid-cols-4 gap-5">
        {GAME_KEYS.map((k, i) => { const m = GAME_META[k], g = map[k]; return (
          <Link key={k} href={`/app/games/${k}`} className={`card card-hover overflow-hidden group ${g?.enabled ? "" : "opacity-50"}`} style={{ animationDelay: `${i * 50}ms` }}>
            <div className={`h-36 bg-gradient-to-br ${m.grad} relative flex items-center justify-center`}>
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(255,255,255,.25),transparent_50%)]" />
              <span className="text-7xl drop-shadow-[0_8px_16px_rgba(0,0,0,.5)] transition-transform duration-300 group-hover:scale-110 group-hover:-rotate-6">{m.icon}</span>
              {!g?.enabled && <span className="absolute top-2 right-2 badge bg-black/70 text-gray-300">Disabled</span>}
            </div>
            <div className="p-4"><div className="font-bold text-lg">{m.name}</div><div className="text-sm text-gray-400">{m.tagline}</div>
              <div className="mt-3 flex justify-between items-center text-xs"><span className="text-gold">{g?.entryCost ? `Entry: ${g.entryCost} pts` : "Free to play"}</span><span className="btn-gold !py-1 !px-3 text-xs">PLAY</span></div></div>
          </Link>); })}
      </div>
    </div>
  );
}
