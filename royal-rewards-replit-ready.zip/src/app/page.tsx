import { redirect } from "next/navigation";
import { getUser } from "@/lib/auth";
import { AuthLayout } from "@/components/AuthLayout";
import { AuthForm } from "@/components/AuthForm";
export default async function Home() {
  if (await getUser()) redirect("/app");
  return <AuthLayout><AuthForm mode="login" /></AuthLayout>;
}
