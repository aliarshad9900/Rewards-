import type { Metadata, Viewport } from "next";
import "./globals.css";
import { getSettings } from "@/lib/core";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Royal Rewards", description: "Play games. Earn points. Unlock rewards." };
export const viewport: Viewport = { themeColor: "#07040c", width: "device-width", initialScale: 1 };

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  let gold = "#f5c542", purple = "#1c1030";
  try { const s = await getSettings(); if (/^#[0-9a-f]{6}$/i.test(s.gold)) gold = s.gold; if (/^#[0-9a-f]{6}$/i.test(s.purple)) purple = s.purple; } catch {}
  return (
    <html lang="en">
      <body style={{ ["--gold" as string]: gold, ["--purple" as string]: purple }} className="antialiased">{children}</body>
    </html>
  );
}
