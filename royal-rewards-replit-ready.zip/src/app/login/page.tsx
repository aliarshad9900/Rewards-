import { AuthLayout } from "@/components/AuthLayout";
import { AuthForm } from "@/components/AuthForm";
export default function P() { return <AuthLayout><AuthForm mode="login" /></AuthLayout>; }
