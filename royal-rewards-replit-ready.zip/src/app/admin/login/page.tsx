import { redirect } from "next/navigation";
import { getAdmin } from "@/lib/auth";
import { Logo } from "@/components/Logo";
import { DevLogin } from "@/components/admin/DevLogin";

export default async function AdminLogin({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  if (await getAdmin()) redirect("/admin");
  const { error } = await searchParams;
  const dev = !!process.env.ADMIN_DEV_LOGIN_SECRET && process.env.ADMIN_DEV_LOGIN_SECRET.length >= 12;
  return (
    <main className="min-h-screen grid place-items-center p-5">
      <div className="card glow-gold p-8 w-full max-w-md text-center space-y-5 anim-fade">
        <div className="flex justify-center"><Logo size="lg" /></div>
        <h1 className="text-xl font-bold">Administrator Control Centre</h1>
        <p className="text-sm text-gray-400">Admin access requires Google sign-in. Your Google identity is verified on the server; only invited administrators and the verified owner account are allowed.</p>
        {error && <p className="text-red-300 text-sm bg-red-950/50 rounded-lg p-2">{error}</p>}
        <a href="/api/auth/google" className="btn-gold w-full !bg-white"><svg width="18" height="18" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9 3.5l6.7-6.7C35.6 2.4 30.2 0 24 0 14.6 0 6.6 5.4 2.6 13.2l7.8 6C12.3 13.6 17.7 9.5 24 9.5z"/><path fill="#4285F4" d="M46.1 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.4c-.5 2.9-2.2 5.3-4.6 6.9l7.4 5.7c4.3-4 6.9-9.9 6.9-17.1z"/><path fill="#FBBC05" d="M10.4 28.8c-.5-1.4-.8-3-.8-4.8s.3-3.3.8-4.8l-7.8-6C.9 16.6 0 20.2 0 24s.9 7.4 2.6 10.8l7.8-6z"/><path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.4-5.7c-2.1 1.4-4.8 2.3-8.5 2.3-6.3 0-11.7-4.1-13.6-9.7l-7.8 6C6.6 42.6 14.6 48 24 48z"/></svg> Sign in with Google</a>
        {dev && <DevLogin />}
        <a href="/login" className="text-xs text-gray-500 hover:text-gold block">← Back to player sign-in</a>
      </div>
    </main>
  );
}
