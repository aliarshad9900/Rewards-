"use server";
import crypto from "crypto";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { db } from "@/db";
import { admins, announcements, gameSettings, notifications, passwordResets, sessions, users, wallets } from "@/db/schema";
import { eq } from "drizzle-orm";
import { OWNER_EMAIL, PERMS, requireAdmin, sha256 } from "@/lib/auth";
import { AppError, applyGlobalEvent, audit, getSettings, notify, sanitize, setSetting, walletChange, type SiteSettings } from "@/lib/core";
import { validateConfig } from "@/lib/games";
import { GAME_KEYS, type GameKey } from "@/lib/gameMeta";
import { setRequestStatus } from "@/lib/requests";

const back = (path: string, msg: string, ok = true): never => redirect(`${path}${path.includes("?") ? "&" : "?"}${ok ? "msg" : "err"}=${encodeURIComponent(msg)}`);
async function run(path: string, fn: () => Promise<string>) {
  let m: string;
  try { m = await fn(); } catch (e) { if (e instanceof AppError) back(path, e.message, false); throw e; }
  revalidatePath("/admin", "layout");
  back(path, m!);
}

export async function userAction(fd: FormData) {
  const a = await requireAdmin("users");
  const id = Number(fd.get("userId")); const act = String(fd.get("act")); const path = `/admin/users?id=${id}`;
  await run(path, async () => {
    const [u] = await db.select().from(users).where(eq(users.id, id)); if (!u) throw new AppError("User not found");
    if (act === "suspend") { await db.update(users).set({ status: "suspended" }).where(eq(users.id, id)); await db.delete(sessions).where(eq(sessions.userId, id)); }
    else if (act === "restore") await db.update(users).set({ status: "active" }).where(eq(users.id, id));
    else if (act === "unflag") await db.update(users).set({ flagged: false }).where(eq(users.id, id));
    else if (act === "flag") await db.update(users).set({ flagged: true }).where(eq(users.id, id));
    else if (act === "reset") {
      const code = crypto.randomBytes(5).toString("hex").toUpperCase();
      await db.insert(passwordResets).values({ userId: id, tokenHash: sha256(code), expiresAt: new Date(Date.now() + 3600_000) });
      await audit(a.email, "reset_code_issued", u.userNumber);
      return `One-time reset code for ${u.userNumber}: ${code} (valid 1 hour, shown once). Give it to the verified user; they enter it at /forgot.`;
    } else throw new AppError("Unknown action");
    await audit(a.email, "user_" + act, u.userNumber);
    return `User ${u.userNumber}: ${act} done`;
  });
}

export async function adjustPoints(fd: FormData) {
  const a = await requireAdmin("wallets");
  const num = String(fd.get("userNumber")).trim().toUpperCase(); const amount = Math.trunc(Number(fd.get("amount"))); const reason = sanitize(fd.get("reason"), 300);
  const path = String(fd.get("back") || "/admin/wallets");
  await run(path, async () => {
    if (!amount || Math.abs(amount) > 1_000_000) throw new AppError("Enter a non-zero amount");
    if (reason.length < 3) throw new AppError("An explanation is required for every manual adjustment");
    const [u] = await db.select().from(users).where(eq(users.userNumber, num)); if (!u) throw new AppError("User not found");
    const adjusted = amount > 0 ? await applyGlobalEvent(amount) : { points: amount, label: "" };
    const finalAmount = adjusted.points;
    await db.transaction(async (tx) => {
      await walletChange(tx, { userId: u.id, available: finalAmount, earned: finalAmount > 0 ? finalAmount : 0, type: "admin_adjust", description: `Admin adjustment: ${reason}${adjusted.label ? ` (${adjusted.label})` : ""}`, bypassFreeze: true });
      await notify(tx, { userId: u.id, title: finalAmount > 0 ? `➕ ${finalAmount} points added by admin` : `➖ ${-finalAmount} points deducted by admin`, body: `${reason}${adjusted.label ? ` (${adjusted.label})` : ""}`, link: "/app/history" });
      await audit(a.email, "points_adjust", `${num} ${amount > 0 ? "+" : ""}${amount} → ${finalAmount}: ${reason}`, tx);
    });
    return `${finalAmount > 0 ? "Added" : "Deducted"} ${Math.abs(finalAmount)} points ${finalAmount > 0 ? "to" : "from"} ${num}`;
  });
}

export async function freezeWallet(fd: FormData) {
  const a = await requireAdmin("wallets");
  const id = Number(fd.get("userId")); const freeze = fd.get("freeze") === "1"; const path = String(fd.get("back") || "/admin/wallets");
  await run(path, async () => {
    await db.update(wallets).set({ frozen: freeze }).where(eq(wallets.userId, id));
    await notify(db, { userId: id, title: freeze ? "⚠️ Wallet frozen" : "✅ Wallet unfrozen", body: freeze ? "Contact admin for details." : "" });
    await audit(a.email, freeze ? "wallet_freeze" : "wallet_unfreeze", String(id));
    return freeze ? "Wallet frozen" : "Wallet unfrozen";
  });
}

export async function saveGame(fd: FormData) {
  const a = await requireAdmin("games");
  const key = String(fd.get("key")) as GameKey;
  await run("/admin/games#" + key, async () => {
    if (!GAME_KEYS.includes(key)) throw new AppError("Unknown game");
    let cfg: Record<string, unknown>;
    try { cfg = JSON.parse(String(fd.get("config"))); } catch { throw new AppError("Invalid config JSON"); }
    const config = validateConfig(key, cfg);
    const entryCost = Math.trunc(Number(fd.get("entryCost"))), dailyLimit = Math.trunc(Number(fd.get("dailyLimit")));
    if (!(entryCost >= 0 && entryCost <= 100000) || !(dailyLimit >= 0 && dailyLimit <= 10000)) throw new AppError("Invalid cost or limit");
    await db.update(gameSettings).set({ enabled: fd.get("enabled") === "on", entryCost, dailyLimit, instructions: sanitize(fd.get("instructions"), 1500), config }).where(eq(gameSettings.key, key));
    await audit(a.email, "game_update", `${key}: cost=${entryCost} limit=${dailyLimit} ${JSON.stringify(config).slice(0, 500)}`);
    return `${key} settings saved`;
  });
}

export async function requestStatus(fd: FormData) {
  const a = await requireAdmin("requests");
  const path = String(fd.get("back") || "/admin");
  await run(path, async () => { const r = await setRequestStatus(Number(fd.get("id")), String(fd.get("status")), a.email, sanitize(fd.get("note"), 500)); return `${r.code} → ${r.status}`; });
}

export async function saveSettings(fd: FormData) {
  const a = await requireAdmin("settings");
  await run("/admin/settings", async () => {
    const str = (k: string, max = 200) => sanitize(fd.get(k), max);
    const num = (k: string, min: number, max: number) => { const n = Math.trunc(Number(fd.get(k))); if (!(n >= min && n <= max)) throw new AppError(`${k} must be ${min}–${max}`); return n; };
    const color = (k: string) => { const v = String(fd.get(k)); if (!/^#[0-9a-f]{6}$/i.test(v)) throw new AppError("Invalid colour"); return v; };
    const opts = String(fd.get("redeemOptions")).split(",").map((x) => Math.trunc(Number(x.trim()))).filter((n) => n > 0 && n <= 100000);
    if (!opts.length) throw new AppError("Provide at least one redemption option");
    const financial = { rateP: num("rateP", 1, 1_000_000), rateR: num("rateR", 1, 1_000_000), welcomeBonus: num("welcomeBonus", 0, 100000) };
    const upd: Partial<SiteSettings> = {
      siteName: str("siteName", 40) || "ROYAL REWARDS", logo: str("logo", 300) || "👑", gold: color("gold"), purple: color("purple"),
      redeemOptions: opts, minAddPoints: num("minAddPoints", 1, 1_000_000), maxAddPoints: num("maxAddPoints", 1, 10_000_000),
      maintenance: fd.get("maintenance") === "on", maintenanceMessage: str("maintenanceMessage", 500), processingTime: str("processingTime", 100),
      rewardNotice: str("rewardNotice", 1500), terms: str("terms", 8000),
      aiAllowed: ["announcement_draft", "game_instructions"].filter((k) => fd.get("ai_" + k) === "on"),
      globalEvent: (["off", "blessing", "curse"].includes(String(fd.get("globalEvent"))) ? String(fd.get("globalEvent")) : "off") as SiteSettings["globalEvent"],
      globalEventPercent: num("globalEventPercent", 1, 100),
      ...financial,
    };
    const previous = await getSettings();
    for (const [k, v] of Object.entries(upd)) await setSetting(k as keyof SiteSettings, v);
    if (previous.globalEvent !== upd.globalEvent || previous.globalEventPercent !== upd.globalEventPercent) {
      const label = upd.globalEvent === "blessing" ? `Blessing active: +${upd.globalEventPercent}% bonus points` : upd.globalEvent === "curse" ? `Curse active: ${upd.globalEventPercent}% fewer reward points` : "The global points event has ended";
      const activeUsers = await db.select({ id: users.id }).from(users).where(eq(users.status, "active"));
      if (activeUsers.length) await db.insert(notifications).values(activeUsers.map((u) => ({ userId: u.id, title: upd.globalEvent === "blessing" ? "✨ Global Blessing" : upd.globalEvent === "curse" ? "🌑 Global Curse" : "📢 Global event ended", body: label, link: "/app" })));
      await audit(a.email, "global_event_change", label);
    }
    await audit(a.email, "settings_update", JSON.stringify({ ...financial, maintenance: upd.maintenance, globalEvent: upd.globalEvent, globalEventPercent: upd.globalEventPercent }));
    return "Settings saved";
  });
}

export async function announcementAction(fd: FormData) {
  const a = await requireAdmin("settings");
  await run("/admin/settings", async () => {
    const act = String(fd.get("act"));
    if (act === "create") {
      const title = sanitize(fd.get("title"), 100), body = sanitize(fd.get("body"), 1000);
      if (!title || !body) throw new AppError("Title and body required");
      await db.insert(announcements).values({ title, body, active: true });
      const all = await db.select({ id: users.id }).from(users).where(eq(users.status, "active"));
      if (all.length) await db.insert(notifications).values(all.map((u) => ({ userId: u.id, title: `📣 ${title}`, body: body.slice(0, 120), link: "/app" })));
    } else {
      const id = Number(fd.get("id"));
      if (act === "delete") await db.delete(announcements).where(eq(announcements.id, id));
      else await db.update(announcements).set({ active: act === "publish" }).where(eq(announcements.id, id));
    }
    await audit(a.email, "announcement_" + act, "");
    return "Announcement updated";
  });
}

export async function adminManage(fd: FormData) {
  const a = await requireAdmin("owner");
  await run("/admin/admins", async () => {
    const act = String(fd.get("act"));
    const perms = PERMS.filter((p) => fd.get("perm_" + p) === "on") as string[];
    const role = String(fd.get("role")); if (act !== "remove" && !["admin", "support"].includes(role)) throw new AppError("Invalid role");
    if (act === "invite") {
      const email = String(fd.get("email")).trim().toLowerCase();
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw new AppError("Invalid email");
      if (email === OWNER_EMAIL) throw new AppError("That is the owner account");
      await db.insert(admins).values({ email, role, permissions: role === "support" ? ["chat"] : perms }).onConflictDoUpdate({ target: admins.email, set: { role, permissions: role === "support" ? ["chat"] : perms, active: true } });
      await audit(a.email, "admin_invite", `${email} as ${role} [${perms.join(",")}]`);
      return `${email} can now sign in with Google as ${role}`;
    }
    const id = Number(fd.get("id"));
    const [t] = await db.select().from(admins).where(eq(admins.id, id));
    if (!t || t.role === "owner") throw new AppError("Cannot modify the owner");
    if (act === "remove") { await db.update(admins).set({ active: false }).where(eq(admins.id, id)); await db.delete(sessions).where(eq(sessions.adminId, id)); }
    else await db.update(admins).set({ role, permissions: role === "support" ? ["chat"] : perms }).where(eq(admins.id, id));
    await audit(a.email, "admin_" + act, `${t.email} ${role} [${perms.join(",")}]`);
    return `Administrator ${t.email} updated`;
  });
}

export async function markAdminNotifs() {
  await requireAdmin();
  await db.update(notifications).set({ read: true }).where(eq(notifications.forAdmin, true));
  revalidatePath("/admin", "layout");
}
