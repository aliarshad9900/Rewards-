import { db } from "@/db";
import { announcements } from "@/db/schema";
import { desc } from "drizzle-orm";
import { requireAdmin } from "@/lib/auth";
import { getSettings } from "@/lib/core";
import { PageTitle, fmt } from "@/components/bits";
import { Flash } from "@/components/admin/Flash";
import { announcementAction, saveSettings } from "../../actions";

export default async function S({ searchParams }: { searchParams: Promise<{ msg?: string; err?: string }> }) {
  await requireAdmin("settings"); const sp = await searchParams; const s = await getSettings();
  const anns = await db.select().from(announcements).orderBy(desc(announcements.createdAt));
  const F = ({ n, l, v, t = "text" }: { n: string; l: string; v: string | number; t?: string }) => <div><label className="label">{l}</label><input name={n} type={t} defaultValue={v} className={t === "color" ? "h-11 w-full rounded-lg bg-transparent" : "input"} required={t !== "text"} /></div>;
  return (
    <div className="space-y-6"><PageTitle title="Website Settings" icon="⚙️" /><Flash sp={sp} />
      <form action={saveSettings} className="space-y-6">
        <div className="card p-5 grid md:grid-cols-4 gap-4"><h3 className="md:col-span-4 font-bold text-gold">Branding</h3>
          <F n="siteName" l="Website name" v={s.siteName} /><F n="logo" l="Logo (emoji or https image URL)" v={s.logo} /><F n="gold" l="Gold colour" v={s.gold} t="color" /><F n="purple" l="Purple colour" v={s.purple} t="color" /></div>
        <div className="card p-5 grid md:grid-cols-4 gap-4"><h3 className="md:col-span-4 font-bold text-gold">Rewards & points</h3>
          <F n="rateP" l="Points" v={s.rateP} t="number" /><F n="rateR" l="= Robux" v={s.rateR} t="number" />
          <F n="redeemOptions" l="Redemption options (Robux, comma-separated)" v={s.redeemOptions.join(", ")} /><F n="welcomeBonus" l="Welcome bonus (new accounts)" v={s.welcomeBonus} t="number" />
          <F n="minAddPoints" l="Min add-points request" v={s.minAddPoints} t="number" /><F n="maxAddPoints" l="Max add-points request" v={s.maxAddPoints} t="number" /><F n="processingTime" l="Processing time text" v={s.processingTime} />
          <div className="md:col-span-4"><label className="label">Reward terms / eligibility notice</label><textarea name="rewardNotice" defaultValue={s.rewardNotice} className="input min-h-20" /></div>
          <p className="md:col-span-4 text-xs text-gray-500">Daily reward amounts and streak rules are configured under Games → Daily Reward.</p></div>
        <div className="card p-5 grid md:grid-cols-3 gap-4"><h3 className="md:col-span-3 font-bold text-gold">✨ Global Blessing / Curse</h3>
          <div><label className="label">Global event</label><select name="globalEvent" defaultValue={s.globalEvent} className="input"><option value="off">Off — normal rewards</option><option value="blessing">Blessing — increase rewards</option><option value="curse">Curse — reduce rewards</option></select></div>
          <F n="globalEventPercent" l="Percentage change (1–100%)" v={s.globalEventPercent} t="number" />
          <p className="text-xs text-gray-500 self-end">Applies to newly credited points (game wins, daily rewards, welcome bonuses, approved add-points and positive admin grants). Existing balances and refunds are not changed. Players receive an in-app notification when the event changes. Example: 10% Blessing = +10%; 10% Curse = −10%.</p>
        </div>
        <div className="card p-5 space-y-3"><h3 className="font-bold text-gold">Maintenance & terms</h3>
          <label className="flex items-center gap-2"><input type="checkbox" name="maintenance" defaultChecked={s.maintenance} className="w-5 h-5 accent-amber-400" /> Maintenance mode (players see a maintenance screen; admin panel stays available)</label>
          <F n="maintenanceMessage" l="Maintenance message" v={s.maintenanceMessage} />
          <div><label className="label">Terms & conditions</label><textarea name="terms" defaultValue={s.terms} className="input min-h-32" /></div></div>
        <div className="card p-5 space-y-2"><h3 className="font-bold text-gold">AI assistant permissions (ordinary settings only)</h3>
          <label className="flex items-center gap-2"><input type="checkbox" name="ai_announcement_draft" defaultChecked={s.aiAllowed.includes("announcement_draft")} /> May create inactive announcement drafts</label>
          <label className="flex items-center gap-2"><input type="checkbox" name="ai_game_instructions" defaultChecked={s.aiAllowed.includes("game_instructions")} /> May update game instruction text</label>
          <p className="text-xs text-gray-500">The AI can never approve requests, change points, permissions, or financial/redemption policy.</p></div>
        <button className="btn-gold">Save all settings</button>
      </form>
      <div className="card p-5 space-y-4"><h3 className="font-bold text-gold">📣 Announcements</h3>
        <form action={announcementAction} className="grid md:grid-cols-[1fr_2fr_auto] gap-2"><input type="hidden" name="act" value="create" /><input name="title" placeholder="Title" className="input" required /><input name="body" placeholder="Message" className="input" required /><button className="btn-gold">Publish & notify</button></form>
        {anns.map((a) => <div key={a.id} className="flex flex-wrap justify-between gap-2 border-b border-white/5 pb-2"><div><b>{a.title}</b> <span className={`badge ${a.active ? "b-approved" : "b-pending"}`}>{a.active ? "live" : "draft"}</span><p className="text-sm text-gray-400">{a.body}</p><p className="text-xs text-gray-600">{fmt(a.createdAt)}</p></div>
          <div className="flex gap-2">{(["publish", "unpublish", "delete"] as const).filter((x) => x === "delete" || (x === "publish") !== a.active).map((x) => <form key={x} action={announcementAction}><input type="hidden" name="act" value={x} /><input type="hidden" name="id" value={a.id} /><button className={x === "delete" ? "btn-danger !py-1 text-xs" : "btn-ghost !py-1 text-xs"}>{x}</button></form>)}</div></div>)}
      </div>
    </div>
  );
}
