import { db } from "@/db";
import { conversations, notifications } from "@/db/schema";
import { and, eq, gt, sql } from "drizzle-orm";
import { PERMS, hasPerm, requireAdmin } from "@/lib/auth";
import { AdminShell } from "@/components/admin/AdminShell";

export default async function L({ children }: { children: React.ReactNode }) {
  const a = await requireAdmin();
  const perms = [...PERMS, "owner"].filter((p) => hasPerm(a, p as never));
  const [[n], [c]] = await Promise.all([
    db.select({ c: sql<number>`count(*)::int` }).from(notifications).where(and(eq(notifications.forAdmin, true), eq(notifications.read, false))),
    db.select({ c: sql<number>`count(*)::int` }).from(conversations).where(gt(conversations.adminUnread, 0)),
  ]);
  return <AdminShell perms={perms} email={a.email} role={a.role} unread={n.c} unreadChats={c.c}>{children}</AdminShell>;
}
