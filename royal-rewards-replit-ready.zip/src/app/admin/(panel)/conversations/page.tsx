import Link from "next/link";
import { db } from "@/db";
import { conversations, users } from "@/db/schema";
import { and, desc, eq, gt, ilike, type SQL } from "drizzle-orm";
import { requireAdmin } from "@/lib/auth";
import { PageTitle, Status, fmt } from "@/components/bits";

export default async function Convs({ searchParams }: { searchParams: Promise<{ q?: string; f?: string }> }) {
  await requireAdmin("chat"); const sp = await searchParams;
  const conds: SQL[] = [];
  if (sp.q) conds.push(ilike(users.userNumber, `%${sp.q}%`));
  if (sp.f === "unread") conds.push(gt(conversations.adminUnread, 0));
  if (sp.f === "open" || sp.f === "closed") conds.push(eq(conversations.status, sp.f));
  const rows = await db.select({ c: conversations, n: users.userNumber }).from(conversations).innerJoin(users, eq(users.id, conversations.userId)).where(conds.length ? and(...conds) : undefined).orderBy(desc(conversations.updatedAt)).limit(200);
  return (
    <div><PageTitle title="Conversations" icon="💬" />
      <form className="card p-4 mb-4 flex flex-wrap gap-2"><input name="q" defaultValue={sp.q} placeholder="Search User Number" className="input flex-1 min-w-40" /><select name="f" defaultValue={sp.f ?? ""} className="input w-40"><option value="">All</option><option value="unread">Unread</option><option value="open">Open</option><option value="closed">Closed</option></select><button className="btn-gold">Search</button></form>
      <div className="space-y-2">{rows.map(({ c, n }) => <Link key={c.id} href={`/admin/conversations/${c.id}`} className="card card-hover p-4 flex justify-between items-center gap-3"><div><div className="font-bold">{c.subject}</div><div className="text-xs text-gray-400">{n} · {fmt(c.updatedAt)} {c.requestId ? "· request" : "· general"}</div></div><div className="flex items-center gap-2">{c.adminUnread > 0 && <span className="badge bg-red-500 text-white">{c.adminUnread} unread</span>}<Status s={c.status} /></div></Link>)}
        {!rows.length && <p className="text-gray-500">No conversations.</p>}</div>
    </div>
  );
}
