import { requireAdmin } from "@/lib/auth";
import { ChatClient } from "@/components/ChatClient";
export default async function P({ params }: { params: Promise<{ id: string }> }) { await requireAdmin("chat"); return <ChatClient admin id={Number((await params).id)} />; }
