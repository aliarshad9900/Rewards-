import { db } from "@/db";
import { auditLogs } from "@/db/schema";
import { desc, ilike, or } from "drizzle-orm";
import { requireAdmin } from "@/lib/auth";
import { PageTitle, fmt } from "@/components/bits";

export default async function Audit({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  await requireAdmin("audit"); const { q } = await searchParams;
  const rows = await db.select().from(auditLogs).where(q ? or(ilike(auditLogs.actor, `%${q}%`), ilike(auditLogs.action, `%${q}%`), ilike(auditLogs.details, `%${q}%`)) : undefined).orderBy(desc(auditLogs.createdAt)).limit(400);
  return (<div><PageTitle title="Audit Logs" icon="📜" />
    <form className="card p-4 mb-4 flex gap-2"><input name="q" defaultValue={q} placeholder="Search actor, action, details" className="input" /><button className="btn-gold">Search</button></form>
    <div className="card overflow-x-auto"><table className="table min-w-[700px]"><thead><tr><th>Time</th><th>Actor</th><th>Action</th><th>Details</th></tr></thead><tbody>
      {rows.map((r) => <tr key={r.id}><td className="whitespace-nowrap">{fmt(r.createdAt)}</td><td className="text-gold">{r.actor}</td><td>{r.action}</td><td className="text-gray-300 break-all">{r.details}</td></tr>)}</tbody></table></div></div>);
}
