import { db } from "@/db";
import { admins } from "@/db/schema";
import { asc } from "drizzle-orm";
import { PERMS, requireAdmin } from "@/lib/auth";
import { PageTitle } from "@/components/bits";
import { Flash } from "@/components/admin/Flash";
import { adminManage } from "../../actions";

export default async function A({ searchParams }: { searchParams: Promise<{ msg?: string; err?: string }> }) {
  await requireAdmin("owner"); const sp = await searchParams;
  const rows = await db.select().from(admins).orderBy(asc(admins.id));
  const Perms = ({ has }: { has: string[] }) => <div className="flex flex-wrap gap-3">{PERMS.map((p) => <label key={p} className="flex items-center gap-1 text-sm"><input type="checkbox" name={"perm_" + p} defaultChecked={has.includes(p)} />{p}</label>)}</div>;
  const Role = ({ v }: { v: string }) => <select name="role" defaultValue={v} className="input w-36"><option value="admin">Admin</option><option value="support">Support (chat only)</option></select>;
  return (
    <div className="space-y-5"><PageTitle title="Administrators" sub="Only the owner can grant or remove permissions. Invited admins sign in with their Google account." icon="🛡️" /><Flash sp={sp} />
      <form action={adminManage} className="card p-5 space-y-3"><input type="hidden" name="act" value="invite" /><h3 className="font-bold text-gold">Invite administrator</h3>
        <div className="flex flex-wrap gap-2"><input name="email" type="email" placeholder="google-account@gmail.com" required className="input flex-1 min-w-56" /><Role v="admin" /></div><Perms has={["requests", "chat"]} /><button className="btn-gold">Invite</button></form>
      {rows.map((a) => <div key={a.id} className="card p-4 space-y-2"><div className="flex flex-wrap justify-between gap-2"><div><b>{a.email}</b> <span className="badge bg-gold/20 text-gold">{a.role}</span> {!a.active && <span className="badge b-rejected">removed</span>}<div className="text-xs text-gray-500">{a.name}</div></div></div>
        {a.role === "owner" ? <p className="text-sm text-gray-400">Primary owner — complete access, verified via Google OAuth.</p> :
          <form action={adminManage} className="space-y-2"><input type="hidden" name="id" value={a.id} /><Role v={a.role} /><Perms has={a.permissions} /><div className="flex gap-2"><button name="act" value="update" className="btn-gold !py-1.5 text-sm">Save</button>{a.active && <button name="act" value="remove" className="btn-danger !py-1.5 text-sm">Remove access</button>}</div></form>}</div>)}
    </div>
  );
}
