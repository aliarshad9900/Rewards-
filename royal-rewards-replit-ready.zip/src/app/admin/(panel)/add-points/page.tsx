import { requireAdmin } from "@/lib/auth";
import { RequestsPage } from "@/components/admin/RequestsPage";
export default async function P({ searchParams }: { searchParams: Promise<{ status?: string; msg?: string; err?: string }> }) { await requireAdmin("requests"); return <RequestsPage kind="add_points" sp={await searchParams} />; }
