import Link from "next/link";
import { db } from "@/db";
import { gameSessions, transactions, users, wallets, requests } from "@/db/schema";
import { desc, eq, ilike, or, sql } from "drizzle-orm";
import { requireAdmin } from "@/lib/auth";
import { PageTitle, Status, TX_LABEL, fmt } from "@/components/bits";
import { Flash } from "@/components/admin/Flash";
import { userAction, adjustPoints, freezeWallet } from "../../actions";

export default async function Users({ searchParams }: { searchParams: Promise<{ q?: string; id?: string; msg?: string; err?: string; flagged?: string }> }) {
  await requireAdmin("users"); const sp = await searchParams;
  if (sp.id) return <UserDetail id={Number(sp.id)} sp={sp} />;
  const q = (sp.q ?? "").trim();
  const rows = await db.select({ u: users, w: wallets }).from(users).innerJoin(wallets, eq(wallets.userId, users.id))
    .where(sp.flagged ? eq(users.flagged, true) : q ? or(ilike(users.username, `%${q}%`), ilike(users.userNumber, `%${q}%`)) : undefined).orderBy(desc(users.createdAt)).limit(200);
  if (rows.length === 1 && q) return <UserDetail id={rows[0].u.id} sp={sp} />;
  return (
    <div><PageTitle title="User Management" icon="👥" /><Flash sp={sp} />
      <form className="card p-4 mb-4 flex gap-2 flex-wrap"><input name="q" defaultValue={q} placeholder="Search username or User Number" className="input flex-1 min-w-48" /><button className="btn-gold">Search</button><Link href="/admin/users?flagged=1" className="btn-ghost">⚠️ Suspicious</Link></form>
      <div className="card overflow-x-auto"><table className="table min-w-[700px]"><thead><tr><th>User #</th><th>Username</th><th>Balance</th><th>Pending</th><th>Status</th><th>Joined</th><th>Last active</th></tr></thead><tbody>
        {rows.map(({ u, w }) => <tr key={u.id}><td><Link href={`/admin/users?id=${u.id}`} className="text-gold font-mono">{u.userNumber}</Link></td><td>{u.username} {u.flagged && "⚠️"}</td><td>{w.available}{w.frozen && " 🧊"}</td><td>{w.reserved}</td><td><span className={`badge ${u.status === "active" ? "b-approved" : "b-rejected"}`}>{u.status}</span></td><td>{fmt(u.createdAt)}</td><td>{fmt(u.lastActiveAt)}</td></tr>)}
        {!rows.length && <tr><td colSpan={7} className="text-center text-gray-500 py-6">No users found.</td></tr>}</tbody></table></div>
    </div>
  );
}

async function UserDetail({ id, sp }: { id: number; sp: { msg?: string; err?: string } }) {
  const [row] = await db.select({ u: users, w: wallets }).from(users).innerJoin(wallets, eq(wallets.userId, users.id)).where(eq(users.id, id));
  if (!row) return <p>User not found</p>;
  const { u, w } = row;
  const [txs, games, reqs] = await Promise.all([
    db.select().from(transactions).where(eq(transactions.userId, id)).orderBy(desc(transactions.createdAt)).limit(100),
    db.select({ key: gameSessions.gameKey, n: sql<number>`count(*)::int`, won: sql<number>`coalesce(sum(${gameSessions.reward}),0)::int`, spent: sql<number>`coalesce(sum(${gameSessions.cost}),0)::int` }).from(gameSessions).where(eq(gameSessions.userId, id)).groupBy(gameSessions.gameKey),
    db.select().from(requests).where(eq(requests.userId, id)).orderBy(desc(requests.createdAt)),
  ]);
  const Btn = ({ act, label, cls = "btn-ghost" }: { act: string; label: string; cls?: string }) => <form action={userAction}><input type="hidden" name="userId" value={id} /><input type="hidden" name="act" value={act} /><button className={cls}>{label}</button></form>;
  const backPath = `/admin/users?id=${id}`;
  return (
    <div className="space-y-5"><Link href="/admin/users" className="text-sm text-gray-400">← All users</Link><Flash sp={sp} />
      <div className="card p-6 flex flex-wrap gap-6 justify-between">
        <div><div className="text-2xl font-black text-gold font-mono">{u.userNumber}</div><div>{u.username} {u.flagged && <span className="badge b-rejected">flagged</span>}</div><div className="text-xs text-gray-500">Joined {fmt(u.createdAt)} · Last active {fmt(u.lastActiveAt)}</div><span className={`badge mt-2 ${u.status === "active" ? "b-approved" : "b-rejected"}`}>{u.status}</span></div>
        <div className="grid grid-cols-2 gap-x-6 text-sm"><span>Available: <b className="text-gold">{w.available}</b></span><span>Pending: <b>{w.reserved}</b></span><span>Earned: <b>{w.totalEarned}</b></span><span>Withdrawn: <b>{w.totalWithdrawn}</b></span><span>Wallet: <b>{w.frozen ? "🧊 Frozen" : "Active"}</b></span></div>
        <div className="flex flex-wrap gap-2 items-start">
          {u.status === "active" ? <Btn act="suspend" label="⛔ Suspend" cls="btn-danger" /> : <Btn act="restore" label="✅ Restore" cls="btn-gold" />}
          {u.flagged ? <Btn act="unflag" label="Clear flag" /> : <Btn act="flag" label="⚠️ Flag" />}
          <Btn act="reset" label="🔑 Issue reset code" />
          <form action={freezeWallet}><input type="hidden" name="userId" value={id} /><input type="hidden" name="freeze" value={w.frozen ? "0" : "1"} /><input type="hidden" name="back" value={backPath} /><button className="btn-ghost">{w.frozen ? "Unfreeze wallet" : "🧊 Freeze wallet"}</button></form>
        </div>
      </div>
      <form action={adjustPoints} className="card p-4 flex flex-wrap gap-2 items-end"><input type="hidden" name="userNumber" value={u.userNumber} /><input type="hidden" name="back" value={backPath} />
        <div><label className="label">Adjust points (+/-)</label><input name="amount" type="number" required className="input w-36" /></div><div className="flex-1 min-w-48"><label className="label">Explanation (required)</label><input name="reason" required minLength={3} className="input" /></div><button className="btn-gold">Apply</button></form>
      <div className="grid lg:grid-cols-2 gap-5">
        <div className="card p-4"><h3 className="font-bold text-gold mb-2">Game activity</h3><table className="table"><thead><tr><th>Game</th><th>Plays</th><th>Spent</th><th>Won</th></tr></thead><tbody>{games.map((g) => <tr key={g.key}><td>{g.key}</td><td>{g.n}</td><td>{g.spent}</td><td>{g.won}</td></tr>)}</tbody></table></div>
        <div className="card p-4"><h3 className="font-bold text-gold mb-2">Requests</h3><table className="table"><tbody>{reqs.map((r) => <tr key={r.id}><td>{r.code}</td><td>{r.kind === "withdrawal" ? `${r.robux} Robux` : `${r.points} pts`}</td><td><Status s={r.status} /></td></tr>)}</tbody></table></div>
      </div>
      <div className="card p-4 overflow-x-auto"><h3 className="font-bold text-gold mb-2">Wallet history</h3><table className="table min-w-[600px]"><thead><tr><th>ID</th><th>Date</th><th>Type</th><th>Amount</th><th>Description</th></tr></thead><tbody>{txs.map((t) => <tr key={t.id}><td className="font-mono text-xs">{t.id}</td><td>{fmt(t.createdAt)}</td><td>{TX_LABEL[t.type] ?? t.type}</td><td className={t.amount >= 0 ? "text-green-400" : "text-red-300"}>{t.amount}</td><td>{t.description}</td></tr>)}</tbody></table></div>
    </div>
  );
}
