import Link from "next/link";
import { db } from "@/db";
import { conversations, gameSessions, requests, transactions, users, wallets } from "@/db/schema";
import { and, desc, eq, gt, gte, sql } from "drizzle-orm";
import { requireAdmin } from "@/lib/auth";
import { Stat, TX_LABEL, fmt, PageTitle } from "@/components/bits";

export default async function Dash({ searchParams }: { searchParams: Promise<{ denied?: string }> }) {
  const a = await requireAdmin(); const sp = await searchParams;
  const day = new Date(Date.now() - 86400_000);
  const [[u], [act], [w], [wr], [ap], [gp], [unread], recent] = await Promise.all([
    db.select({ c: sql<number>`count(*)::int` }).from(users),
    db.select({ c: sql<number>`count(*)::int` }).from(users).where(gte(users.lastActiveAt, day)),
    db.select({ issued: sql<number>`coalesce(sum(${wallets.totalEarned}),0)::int`, redeemed: sql<number>`coalesce(sum(${wallets.totalWithdrawn}),0)::int`, avail: sql<number>`coalesce(sum(${wallets.available}),0)::int` }).from(wallets),
    db.select({ c: sql<number>`count(*)::int` }).from(requests).where(and(eq(requests.kind, "withdrawal"), sql`${requests.status} in ('pending','under_review')`)),
    db.select({ c: sql<number>`count(*)::int` }).from(requests).where(and(eq(requests.kind, "add_points"), sql`${requests.status} in ('pending','under_review')`)),
    db.select({ c: sql<number>`count(*)::int` }).from(gameSessions).where(eq(gameSessions.status, "finished")),
    db.select({ c: sql<number>`coalesce(sum(${conversations.adminUnread}),0)::int` }).from(conversations).where(gt(conversations.adminUnread, 0)),
    db.select({ t: transactions, n: users.userNumber }).from(transactions).innerJoin(users, eq(users.id, transactions.userId)).orderBy(desc(transactions.createdAt)).limit(10),
  ]);
  return (
    <div className="space-y-6">
      <PageTitle title="Admin Dashboard" sub={`Welcome back, ${a.name ?? a.email}. All figures are live from the database.`} icon="📊" />
      {sp.denied && <div className="card p-3 text-red-300">You do not have permission for that section.</div>}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
        <Stat label="Registered users" value={u.c} icon="👥" />
        <Stat label="Active (24h)" value={act.c} icon="🟢" />
        <Stat label="Points issued" value={w.issued} icon="🪙" hint={`${w.avail.toLocaleString()} currently available`} />
        <Stat label="Points redeemed" value={w.redeemed} icon="🏆" />
        <Stat label="Games played" value={gp.c} icon="🎮" />
        <Link href="/admin/withdrawals?status=pending"><Stat label="Pending withdrawals" value={wr.c} icon="💸" /></Link>
        <Link href="/admin/add-points?status=pending"><Stat label="Pending add-points" value={ap.c} icon="➕" /></Link>
        <Link href="/admin/conversations"><Stat label="Unread messages" value={unread.c} icon="💬" /></Link>
      </div>
      <div className="card p-5 overflow-x-auto"><h3 className="font-bold text-gold mb-3">Recent transactions</h3>
        <table className="table min-w-[600px]"><thead><tr><th>ID</th><th>User</th><th>Type</th><th>Amount</th><th>Date</th></tr></thead><tbody>
          {recent.map(({ t, n }) => <tr key={t.id}><td className="font-mono text-xs">{t.id}</td><td><Link className="text-gold" href={`/admin/users?q=${n}`}>{n}</Link></td><td>{TX_LABEL[t.type] ?? t.type}</td><td className={t.amount >= 0 ? "text-green-400" : "text-red-300"}>{t.amount}</td><td>{fmt(t.createdAt)}</td></tr>)}
          {!recent.length && <tr><td colSpan={5} className="text-gray-500 text-center py-6">No transactions yet.</td></tr>}</tbody></table></div>
    </div>
  );
}
