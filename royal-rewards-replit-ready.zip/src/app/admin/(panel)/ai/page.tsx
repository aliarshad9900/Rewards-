import { requireAdmin } from "@/lib/auth";
import { PageTitle } from "@/components/bits";
import { AIChat } from "@/components/admin/AIChat";
export default async function P() {
  await requireAdmin("ai");
  return <div><PageTitle title="AI Management Assistant" sub={process.env.OPENAI_API_KEY ? "Powered by OpenAI + live platform data." : "Running built-in analytics mode. Set OPENAI_API_KEY for conversational AI."} icon="🤖" /><AIChat /></div>;
}
