import Link from "next/link";
import { db } from "@/db";
import { transactions, users, wallets } from "@/db/schema";
import { and, desc, eq, type SQL } from "drizzle-orm";
import { requireAdmin } from "@/lib/auth";
import { PageTitle, TX_LABEL, fmt } from "@/components/bits";
import { Flash } from "@/components/admin/Flash";
import { adjustPoints, freezeWallet } from "../../actions";

export default async function Wallets({ searchParams }: { searchParams: Promise<{ type?: string; user?: string; msg?: string; err?: string }> }) {
  await requireAdmin("wallets"); const sp = await searchParams;
  const conds: SQL[] = [];
  if (sp.type && TX_LABEL[sp.type]) conds.push(eq(transactions.type, sp.type));
  if (sp.user) conds.push(eq(users.userNumber, sp.user.toUpperCase()));
  const [txs, frozen] = await Promise.all([
    db.select({ t: transactions, n: users.userNumber }).from(transactions).innerJoin(users, eq(users.id, transactions.userId)).where(conds.length ? and(...conds) : undefined).orderBy(desc(transactions.createdAt)).limit(300),
    db.select({ n: users.userNumber, id: users.id }).from(wallets).innerJoin(users, eq(users.id, wallets.userId)).where(eq(wallets.frozen, true)),
  ]);
  return (
    <div className="space-y-5"><PageTitle title="Points Management" icon="👛" /><Flash sp={sp} />
      <div className="grid lg:grid-cols-2 gap-5">
        <form action={adjustPoints} className="card p-5 space-y-3"><h3 className="font-bold text-gold">Add / deduct points</h3>
          <input name="userNumber" placeholder="User Number (e.g. RR100001)" required className="input uppercase" />
          <input name="amount" type="number" placeholder="Amount (negative to deduct)" required className="input" />
          <input name="reason" placeholder="Explanation (required, recorded in audit log)" required minLength={3} className="input" />
          <button className="btn-gold w-full">Apply adjustment</button></form>
        <div className="card p-5"><h3 className="font-bold text-gold mb-2">🧊 Frozen wallets</h3>
          {frozen.map((f) => <form key={f.id} action={freezeWallet} className="flex justify-between items-center py-1"><Link href={`/admin/users?id=${f.id}`} className="text-gold">{f.n}</Link><input type="hidden" name="userId" value={f.id} /><input type="hidden" name="freeze" value="0" /><button className="btn-ghost !py-1 text-sm">Unfreeze</button></form>)}
          {!frozen.length && <p className="text-sm text-gray-500">None. Freeze wallets from a user&apos;s detail page.</p>}</div>
      </div>
      <form className="card p-4 flex flex-wrap gap-2 items-end"><div><label className="label">Type</label><select name="type" defaultValue={sp.type ?? ""} className="input"><option value="">All</option>{Object.entries(TX_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></div><div><label className="label">User Number</label><input name="user" defaultValue={sp.user} className="input" /></div><button className="btn-gold">Filter</button></form>
      <div className="card overflow-x-auto"><table className="table min-w-[760px]"><thead><tr><th>ID</th><th>User</th><th>Date</th><th>Type</th><th>Amount</th><th>Status</th><th>Description</th></tr></thead><tbody>
        {txs.map(({ t, n }) => <tr key={t.id}><td className="font-mono text-xs">{t.id}</td><td className="text-gold">{n}</td><td className="whitespace-nowrap">{fmt(t.createdAt)}</td><td>{TX_LABEL[t.type] ?? t.type}</td><td className={t.amount >= 0 ? "text-green-400" : "text-red-300"}>{t.amount}</td><td>{t.status}</td><td>{t.description}</td></tr>)}</tbody></table></div>
    </div>
  );
}
