import Link from "next/link";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { requireAdmin } from "@/lib/auth";
import { PageTitle, fmt } from "@/components/bits";
import { markAdminNotifs } from "../../actions";

export default async function N() {
  await requireAdmin();
  const rows = await db.select().from(notifications).where(eq(notifications.forAdmin, true)).orderBy(desc(notifications.createdAt)).limit(150);
  return (<div><PageTitle title="Admin Notifications" icon="🔔" />
    <form action={markAdminNotifs} className="mb-4"><button className="btn-ghost">Mark all as read</button></form>
    <div className="space-y-2">{rows.map((n) => <Link key={n.id} href={n.link ?? "#"} className={`card block p-4 ${n.read ? "opacity-60" : "!border-gold/60"}`}><div className="flex justify-between"><b>{n.title}</b><span className="text-xs text-gray-500">{fmt(n.createdAt)}</span></div><p className="text-sm text-gray-400">{n.body}</p></Link>)}
      {!rows.length && <p className="text-gray-500">No notifications.</p>}</div></div>);
}
