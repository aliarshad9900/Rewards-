import { db } from "@/db";
import { gameSessions, gameSettings } from "@/db/schema";
import { sql } from "drizzle-orm";
import { requireAdmin } from "@/lib/auth";
import { ensureGames } from "@/lib/games";
import { GAME_KEYS, GAME_META } from "@/lib/gameMeta";
import { PageTitle } from "@/components/bits";
import { Flash } from "@/components/admin/Flash";
import { GameEditor } from "@/components/admin/GameEditor";
import { saveGame } from "../../actions";

export default async function Games({ searchParams }: { searchParams: Promise<{ msg?: string; err?: string }> }) {
  await requireAdmin("games"); const sp = await searchParams; await ensureGames();
  const [rows, stats] = await Promise.all([
    db.select().from(gameSettings),
    db.select({ key: gameSessions.gameKey, plays: sql<number>`count(*)::int`, players: sql<number>`count(distinct ${gameSessions.userId})::int`, cost: sql<number>`coalesce(sum(${gameSessions.cost}),0)::int`, reward: sql<number>`coalesce(sum(${gameSessions.reward}),0)::int`, wins: sql<number>`count(*) filter (where ${gameSessions.reward} > 0)::int` }).from(gameSessions).groupBy(gameSessions.gameKey),
  ]);
  const st = Object.fromEntries(stats.map((s) => [s.key, s]));
  return (
    <div><PageTitle title="Game Management" sub="Probabilities are validated on the server and must total exactly 100%." icon="🎮" /><Flash sp={sp} />
      <div className="space-y-5">{GAME_KEYS.map((k) => { const g = rows.find((r) => r.key === k)!; const s = st[k]; return (
        <div key={k} id={k} className="card p-5 scroll-mt-20">
          <div className="flex flex-wrap justify-between gap-3 mb-4"><h3 className="text-xl font-bold">{GAME_META[k].icon} {g.name}</h3>
            <div className="flex flex-wrap gap-4 text-xs text-gray-400"><span>Plays: <b className="text-white">{s?.plays ?? 0}</b></span><span>Players: <b className="text-white">{s?.players ?? 0}</b></span><span>Wins: <b className="text-white">{s?.wins ?? 0}</b></span><span>Points in: <b className="text-white">{s?.cost ?? 0}</b></span><span>Points out: <b className="text-white">{s?.reward ?? 0}</b></span>{s?.cost ? <span>Payout: <b className="text-gold">{Math.round((s.reward / s.cost) * 100)}%</b></span> : null}</div></div>
          <GameEditor action={saveGame} g={{ key: g.key, enabled: g.enabled, entryCost: g.entryCost, dailyLimit: g.dailyLimit, instructions: g.instructions, config: g.config }} />
        </div>); })}</div>
    </div>
  );
}
