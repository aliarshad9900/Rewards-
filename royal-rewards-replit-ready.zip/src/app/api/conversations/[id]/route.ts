import { db } from "@/db";
import { conversations, messages, requests } from "@/db/schema";
import { apiUser } from "@/lib/auth";
import { AppError, errorJson, notify, rateLimit, sanitize } from "@/lib/core";
import { and, asc, eq, sql } from "drizzle-orm";

async function load(userId: number, id: number) {
  const [c] = await db.select().from(conversations).where(and(eq(conversations.id, id), eq(conversations.userId, userId)));
  if (!c) throw new AppError("Conversation not found", 404);
  return c;
}
export async function GET(_: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const u = await apiUser(); if (!u) throw new AppError("Unauthorized", 401);
    const c = await load(u.user.id, Number((await ctx.params).id));
    const msgs = await db.select({ id: messages.id, sender: messages.sender, senderName: messages.senderName, body: messages.body, createdAt: messages.createdAt })
      .from(messages).where(and(eq(messages.conversationId, c.id), eq(messages.internal, false))).orderBy(asc(messages.id));
    const [r] = c.requestId ? await db.select({ code: requests.code, kind: requests.kind, points: requests.points, robux: requests.robux, status: requests.status }).from(requests).where(eq(requests.id, c.requestId)) : [null];
    if (c.userUnread) await db.update(conversations).set({ userUnread: 0 }).where(eq(conversations.id, c.id));
    return Response.json({ conversation: { id: c.id, subject: c.subject, status: c.status }, request: r, messages: msgs });
  } catch (e) { return errorJson(e); }
}
export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const u = await apiUser(); if (!u) throw new AppError("Unauthorized", 401);
    if (!rateLimit("msg:" + u.user.id, 20, 60_000)) throw new AppError("Slow down", 429);
    const c = await load(u.user.id, Number((await ctx.params).id));
    if (c.status === "closed") throw new AppError("This conversation is closed");
    const body = sanitize((await req.json()).body, 2000);
    if (!body) throw new AppError("Message empty");
    await db.insert(messages).values({ conversationId: c.id, sender: "user", senderName: u.user.userNumber, body });
    await db.update(conversations).set({ adminUnread: sql`${conversations.adminUnread} + 1`, updatedAt: new Date() }).where(eq(conversations.id, c.id));
    await notify(db, { forAdmin: true, title: "💬 New user message", body: `${u.user.userNumber}: ${body.slice(0, 80)}`, link: `/admin/conversations/${c.id}` });
    return Response.json({ ok: true });
  } catch (e) { return errorJson(e); }
}
