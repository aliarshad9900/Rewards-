import { db } from "@/db";
import { conversations, messages } from "@/db/schema";
import { apiUser } from "@/lib/auth";
import { AppError, errorJson, notify, rateLimit, sanitize } from "@/lib/core";

export async function POST(req: Request) {
  try {
    const u = await apiUser(); if (!u) throw new AppError("Unauthorized", 401);
    if (!rateLimit("conv:" + u.user.id, 5, 3600_000)) throw new AppError("Too many conversations", 429);
    const { subject, body } = await req.json();
    const s = sanitize(subject, 100), b = sanitize(body, 2000);
    if (!s || !b) throw new AppError("Subject and message required");
    const id = await db.transaction(async (tx) => {
      const [c] = await tx.insert(conversations).values({ userId: u.user.id, subject: s, adminUnread: 1 }).returning();
      await tx.insert(messages).values({ conversationId: c.id, sender: "user", senderName: u.user.userNumber, body: b });
      await notify(tx, { forAdmin: true, title: "💬 New support conversation", body: `${u.user.userNumber}: ${s}`, link: `/admin/conversations/${c.id}` });
      return c.id;
    });
    return Response.json({ ok: true, id });
  } catch (e) { return errorJson(e); }
}
