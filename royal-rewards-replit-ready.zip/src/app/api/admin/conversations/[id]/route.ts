import { db } from "@/db";
import { conversations, messages, requests, users } from "@/db/schema";
import { apiAdmin, hasPerm } from "@/lib/auth";
import { AppError, audit, errorJson, notify, sanitize } from "@/lib/core";
import { setRequestStatus } from "@/lib/requests";
import { asc, eq, sql } from "drizzle-orm";

export async function GET(_: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const a = await apiAdmin("chat"); if (!a) throw new AppError("Forbidden", 403);
    const id = Number((await ctx.params).id);
    const [c] = await db.select({ c: conversations, u: { userNumber: users.userNumber, username: users.username, id: users.id } }).from(conversations).innerJoin(users, eq(users.id, conversations.userId)).where(eq(conversations.id, id));
    if (!c) throw new AppError("Not found", 404);
    const msgs = await db.select().from(messages).where(eq(messages.conversationId, id)).orderBy(asc(messages.id));
    const [r] = c.c.requestId ? await db.select().from(requests).where(eq(requests.id, c.c.requestId)) : [null];
    if (c.c.adminUnread) await db.update(conversations).set({ adminUnread: 0 }).where(eq(conversations.id, id));
    return Response.json({ conversation: { id, subject: c.c.subject, status: c.c.status }, user: c.u, request: r, messages: msgs, canManage: hasPerm(a, "requests") });
  } catch (e) { return errorJson(e); }
}

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const a = await apiAdmin("chat"); if (!a) throw new AppError("Forbidden", 403);
    const id = Number((await ctx.params).id);
    const [c] = await db.select().from(conversations).where(eq(conversations.id, id));
    if (!c) throw new AppError("Not found", 404);
    const b = await req.json();
    const name = a.role === "owner" ? "Royal Admin (Owner)" : `Admin ${a.name ?? ""}`.trim();
    if (b.action === "send" || b.action === "note") {
      const body = sanitize(b.body, 2000); if (!body) throw new AppError("Message empty");
      const internal = b.action === "note";
      await db.insert(messages).values({ conversationId: id, sender: "admin", senderName: name, body, internal });
      if (!internal) {
        await db.update(conversations).set({ userUnread: sql`${conversations.userUnread} + 1`, updatedAt: new Date() }).where(eq(conversations.id, id));
        await notify(db, { userId: c.userId, title: "💬 New message from admin", body: body.slice(0, 80), link: `/app/messages/${id}` });
      }
    } else if (b.action === "status") {
      if (!hasPerm(a, "requests")) throw new AppError("You lack request permissions", 403);
      if (!c.requestId) throw new AppError("No request attached");
      await setRequestStatus(c.requestId, String(b.status), a.email, sanitize(b.body, 500));
    } else if (b.action === "close" || b.action === "reopen") {
      await db.update(conversations).set({ status: b.action === "close" ? "closed" : "open", updatedAt: new Date() }).where(eq(conversations.id, id));
      await db.insert(messages).values({ conversationId: id, sender: "system", senderName: "Royal Rewards", body: b.action === "close" ? "Conversation closed as resolved." : "Conversation reopened." });
      await audit(a.email, "conversation_" + b.action, String(id));
    } else throw new AppError("Invalid action");
    return Response.json({ ok: true });
  } catch (e) { return errorJson(e); }
}
