import { db } from "@/db";
import { announcements, gameSessions, gameSettings, requests, users, wallets } from "@/db/schema";
import { apiAdmin } from "@/lib/auth";
import { AppError, audit, errorJson, getSettings, rateLimit, sanitize } from "@/lib/core";
import { GAME_KEYS } from "@/lib/gameMeta";
import { eq, gte, sql } from "drizzle-orm";

const ORDINARY = ["announcement_draft", "game_instructions"];
const SENSITIVE = /approve|withdraw|payout|add points|deduct|grant|owner|permission|rate|redemption|refund|balance of user/i;

async function gatherStats() {
  const games = await db.select({ key: gameSessions.gameKey, plays: sql<number>`count(*)::int`, cost: sql<number>`coalesce(sum(${gameSessions.cost}),0)::int`, reward: sql<number>`coalesce(sum(${gameSessions.reward}),0)::int`, wins: sql<number>`count(*) filter (where ${gameSessions.reward} > 0)::int` }).from(gameSessions).groupBy(gameSessions.gameKey);
  const settingsRows = await db.select({ key: gameSettings.key, enabled: gameSettings.enabled, entryCost: gameSettings.entryCost, config: gameSettings.config }).from(gameSettings);
  const pending = await db.select({ code: requests.code, kind: requests.kind, points: requests.points, robux: requests.robux, status: requests.status, user: users.userNumber, createdAt: requests.createdAt }).from(requests).innerJoin(users, eq(users.id, requests.userId)).where(sql`${requests.status} in ('pending','under_review','approved')`).limit(20);
  const heavy = await db.select({ user: users.userNumber, plays: sql<number>`count(*)::int`, won: sql<number>`coalesce(sum(${gameSessions.reward}),0)::int` }).from(gameSessions).innerJoin(users, eq(users.id, gameSessions.userId)).where(gte(gameSessions.createdAt, new Date(Date.now() - 86400_000))).groupBy(users.userNumber).orderBy(sql`count(*) desc`).limit(5);
  const flagged = await db.select({ u: users.userNumber }).from(users).where(eq(users.flagged, true));
  const [tot] = await db.select({ users: sql<number>`count(*)::int`, avail: sql<number>`coalesce(sum(${wallets.available}),0)::int` }).from(wallets);
  return { games, settingsRows, pending, heavy, flagged: flagged.map((f) => f.u), totals: tot };
}

function ruleBased(q: string, s: Awaited<ReturnType<typeof gatherStats>>, rate: string) {
  const lines: string[] = [];
  const ql = q.toLowerCase();
  const gameLines = s.games.map((g) => {
    const rtp = g.cost ? Math.round((g.reward / g.cost) * 100) : null;
    return `• ${g.key}: ${g.plays} plays, ${g.wins} wins, ${g.cost} pts in, ${g.reward} pts out${rtp !== null ? `, payout ratio ${rtp}%` : ""}`;
  });
  if (/pending|request|explain/.test(ql) || !ql) {
    lines.push(`📋 Open requests (${s.pending.length}):`);
    s.pending.forEach((p) => lines.push(`• ${p.code} by ${p.user}: ${p.kind === "withdrawal" ? `${p.robux} Robux (${p.points} pts reserved)` : `${p.points} pts requested`} – ${p.status}. ${p.status === "approved" ? "Approved but not yet fulfilled: mark Completed only after you deliver the reward manually." : "Needs a human decision – open the conversation to verify the user."}`));
    if (!s.pending.length) lines.push("• No open requests.");
  }
  if (/stat|game|analy|balance|reward|improve/.test(ql) || !ql) {
    lines.push("🎮 Game statistics:", ...(gameLines.length ? gameLines : ["• No games played yet."]));
    s.games.forEach((g) => { if (g.cost && g.reward / g.cost > 1) lines.push(`⚠️ ${g.key} pays out more than it takes in. Consider raising entry cost or lowering win probabilities.`); else if (g.cost && g.plays > 20 && g.reward / g.cost < 0.3) lines.push(`💡 ${g.key} pays back under 30% – players may feel it is unfair. Consider raising rewards.`); });
    const disabled = s.settingsRows.filter((r) => !r.enabled).map((r) => r.key);
    if (disabled.length) lines.push(`• Disabled games: ${disabled.join(", ")}`);
  }
  if (/unusual|suspic|fraud|abuse/.test(ql) || !ql) {
    lines.push("🛡️ Activity check (last 24h):");
    s.heavy.forEach((h) => lines.push(`• ${h.user}: ${h.plays} plays, won ${h.won} pts${h.plays > 150 ? " ← unusually high volume" : ""}`));
    lines.push(s.flagged.length ? `• Flagged accounts: ${s.flagged.join(", ")}` : "• No flagged accounts.");
  }
  if (/setting|help|how/.test(ql)) lines.push(`⚙️ Settings guide: entry costs and probabilities live in Games; the redemption rate (currently ${rate}) and welcome bonus live in Website Settings; only the owner can change administrators. I cannot change financial settings or approve anything — those require a human.`);
  lines.push(`\nPlatform: ${s.totals.users} wallets holding ${s.totals.avail} available points.`);
  return lines.join("\n");
}

export async function POST(req: Request) {
  try {
    const a = await apiAdmin("ai"); if (!a) throw new AppError("Forbidden", 403);
    if (!rateLimit("ai:" + a.id, 20, 60_000)) throw new AppError("Slow down", 429);
    const b = await req.json();
    const site = await getSettings();
    if (b.apply) {
      const t = String(b.apply.type);
      if (!ORDINARY.includes(t) || !site.aiAllowed.includes(t)) throw new AppError("This action is not permitted for the AI assistant. Sensitive actions require the owner.", 403);
      if (t === "announcement_draft") {
        await db.insert(announcements).values({ title: sanitize(b.apply.title, 100) || "Announcement", body: sanitize(b.apply.body, 1000), active: false });
        await audit(a.email, "ai_action", "Created inactive announcement draft");
        return Response.json({ ok: true, message: "Draft announcement created (inactive). Publish it from Website Settings." });
      }
      if (t === "game_instructions") {
        const key = String(b.apply.key);
        if (!(GAME_KEYS as readonly string[]).includes(key)) throw new AppError("Unknown game");
        await db.update(gameSettings).set({ instructions: sanitize(b.apply.body, 1000) }).where(eq(gameSettings.key, key));
        await audit(a.email, "ai_action", `Updated ${key} instructions`);
        return Response.json({ ok: true, message: `Instructions for ${key} updated.` });
      }
    }
    const q = sanitize(b.message, 1000);
    const stats = await gatherStats();
    const rate = `${site.rateP} pts = ${site.rateR} Robux`;
    let reply = "";
    let action: unknown = null;
    if (SENSITIVE.test(q) && /\b(do|please|go|now)\b/i.test(q)) {
      reply = "🔒 I can't perform sensitive actions (approving withdrawals, sending rewards, changing points, permissions or financial policies). Please handle these manually. I can explain the request or analyse the data instead.\n\n";
    }
    const key = process.env.OPENAI_API_KEY;
    if (key) {
      try {
        const r = await fetch("https://api.openai.com/v1/chat/completions", {
          method: "POST", headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
          body: JSON.stringify({ model: process.env.OPENAI_MODEL || "gpt-4o-mini", messages: [
            { role: "system", content: `You are the Royal Rewards admin assistant. Help admins analyse game stats, detect unusual activity, suggest reward balance, explain requests and settings. You must NEVER approve withdrawals, send rewards, change points, permissions or financial policies – tell the admin to do those manually. You may propose ONE ordinary action by ending with a line: ACTION: {"type":"announcement_draft","title":"...","body":"..."} or ACTION: {"type":"game_instructions","key":"wheel|box|bunny|lucky|memory|treasure|cards|daily","body":"..."}. Redemption rate: ${rate}. Data: ${JSON.stringify(stats).slice(0, 12000)}` },
            { role: "user", content: q || "Give me an overview." }] }),
        });
        if (r.ok) {
          const j = await r.json();
          let text: string = j.choices?.[0]?.message?.content ?? "";
          const m = text.match(/ACTION:\s*(\{[\s\S]*\})\s*$/);
          if (m) { try { action = JSON.parse(m[1]); text = text.replace(m[0], "").trim(); } catch {} }
          reply += text;
        }
      } catch {}
    }
    if (!reply.trim() || (!key && !reply.includes("Platform:"))) reply += ruleBased(q, stats, rate);
    if (!action && /announce/i.test(q)) action = { type: "announcement_draft", title: "News from the Royal Court", body: sanitize(q.replace(/.*announce(ment)?:?/i, ""), 500) || "New rewards and games are waiting for you!" };
    return Response.json({ reply, action, mode: key ? "openai" : "built-in analytics" });
  } catch (e) { return errorJson(e); }
}
