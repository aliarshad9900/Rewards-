import { db } from "@/db";
import { notifications } from "@/db/schema";
import { apiUser } from "@/lib/auth";
import { eq } from "drizzle-orm";
export async function POST() {
  const u = await apiUser();
  if (!u) return Response.json({ error: "Unauthorized" }, { status: 401 });
  await db.update(notifications).set({ read: true }).where(eq(notifications.userId, u.user.id));
  return Response.json({ ok: true });
}
