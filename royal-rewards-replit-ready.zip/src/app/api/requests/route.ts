import { apiUser } from "@/lib/auth";
import { AppError, errorJson, rateLimit, sanitize } from "@/lib/core";
import { createRequest } from "@/lib/requests";

export async function POST(req: Request) {
  try {
    const u = await apiUser(); if (!u) throw new AppError("Unauthorized", 401);
    if (!rateLimit("req:" + u.user.id, 10, 3600_000)) throw new AppError("Too many requests. Try later.", 429);
    const { kind, amount, key, note } = await req.json();
    if (kind !== "withdrawal" && kind !== "add_points") throw new AppError("Invalid kind");
    const r = await createRequest(u.user, kind, Number(amount), String(key ?? ""), sanitize(note, 500));
    return Response.json({ ok: true, code: r.request.code, conversationId: r.conversationId });
  } catch (e) { return errorJson(e); }
}
