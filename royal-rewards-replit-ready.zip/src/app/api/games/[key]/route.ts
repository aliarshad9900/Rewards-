import { apiUser } from "@/lib/auth";
import { AppError, errorJson } from "@/lib/core";
import { claimDaily, gameState, playGame, startGame } from "@/lib/games";

export async function GET(_: Request, ctx: { params: Promise<{ key: string }> }) {
  try {
    const u = await apiUser(); if (!u) throw new AppError("Unauthorized", 401);
    const { key } = await ctx.params;
    return Response.json({ ...(await gameState(u.user.id, key)), balance: u.wallet.available });
  } catch (e) { return errorJson(e); }
}
export async function POST(req: Request, ctx: { params: Promise<{ key: string }> }) {
  try {
    const u = await apiUser(); if (!u) throw new AppError("Unauthorized", 401);
    const { key } = await ctx.params;
    const body = await req.json();
    let data: unknown;
    if (body.action === "start") data = { session: await startGame(u.user.id, u.user.userNumber, key) };
    else if (body.action === "play") data = await playGame(u.user.id, key, String(body.sessionId), Number(body.choice ?? 0));
    else if (body.action === "claim" && key === "daily") data = await claimDaily(u.user.id);
    else throw new AppError("Invalid action");
    const fresh = await apiUser();
    return Response.json({ ...(data as object), balance: fresh?.wallet.available });
  } catch (e) { return errorJson(e); }
}
