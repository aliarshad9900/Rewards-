import { db } from "@/db";
import { passwordResets, sessions, users } from "@/db/schema";
import { hashPassword, sha256 } from "@/lib/auth";
import { AppError, audit, errorJson, rateLimit } from "@/lib/core";
import { and, eq, gt } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const ip = req.headers.get("x-forwarded-for") ?? "local";
    if (!rateLimit("reset:" + ip, 10, 3600_000)) throw new AppError("Too many attempts", 429);
    const { userNumber, code, password } = await req.json();
    if (typeof password !== "string" || password.length < 8) throw new AppError("Password must be at least 8 characters");
    const [u] = await db.select().from(users).where(eq(users.userNumber, String(userNumber ?? "").toUpperCase()));
    if (!u) throw new AppError("Invalid or expired code");
    const [r] = await db.select().from(passwordResets).where(and(eq(passwordResets.userId, u.id), eq(passwordResets.tokenHash, sha256(String(code ?? "").trim())), eq(passwordResets.used, false), gt(passwordResets.expiresAt, new Date())));
    if (!r) throw new AppError("Invalid or expired code");
    await db.transaction(async (tx) => {
      await tx.update(passwordResets).set({ used: true }).where(eq(passwordResets.id, r.id));
      await tx.update(users).set({ passwordHash: hashPassword(password) }).where(eq(users.id, u.id));
      await tx.delete(sessions).where(eq(sessions.userId, u.id));
    });
    await audit(u.userNumber, "password_reset", "completed");
    return Response.json({ ok: true });
  } catch (e) { return errorJson(e); }
}
