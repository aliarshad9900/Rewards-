import { db } from "@/db";
import { profiles, users, wallets } from "@/db/schema";
import { createSession, hashPassword } from "@/lib/auth";
import { AppError, applyGlobalEvent, audit, errorJson, getSettings, notify, rateLimit, walletChange } from "@/lib/core";
import { eq } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const ip = req.headers.get("x-forwarded-for") ?? "local";
    if (!rateLimit("reg:" + ip, 5, 3600_000)) throw new AppError("Too many registrations from this network. Try later.", 429);
    const { username, password, confirm } = await req.json();
    if (typeof username !== "string" || !/^[a-zA-Z0-9_]{3,20}$/.test(username)) throw new AppError("Username must be 3–20 letters, numbers or _");
    if (typeof password !== "string" || password.length < 8 || password.length > 128) throw new AppError("Password must be at least 8 characters");
    if (password !== confirm) throw new AppError("Passwords do not match");
    const [taken] = await db.select({ id: users.id }).from(users).where(eq(users.username, username));
    if (taken) throw new AppError("Username already taken");
    const s = await getSettings();
    const user = await db.transaction(async (tx) => {
      const [u] = await tx.insert(users).values({ username, userNumber: "TMP-" + username, passwordHash: hashPassword(password) }).returning();
      const userNumber = "RR" + (100000 + u.id);
      await tx.update(users).set({ userNumber }).where(eq(users.id, u.id));
      await tx.insert(profiles).values({ userId: u.id, displayName: username });
      await tx.insert(wallets).values({ userId: u.id, welcomeBonusGiven: true });
      if (s.welcomeBonus > 0) {
        const adjusted = await applyGlobalEvent(s.welcomeBonus);
        await walletChange(tx, { userId: u.id, available: adjusted.points, earned: adjusted.points, type: "welcome_bonus", description: `New account welcome bonus${adjusted.label ? ` (${adjusted.label})` : ""}` });
        await notify(tx, { userId: u.id, title: `👑 Welcome bonus: +${adjusted.points} points`, body: `Thanks for joining Royal Rewards!${adjusted.label ? ` ${adjusted.label} applied.` : ""}` });
      }
      await audit(userNumber, "register", username, tx);
      return { ...u, userNumber };
    });
    await createSession("user", user.id);
    return Response.json({ ok: true, userNumber: user.userNumber });
  } catch (e) { return errorJson(e); }
}
