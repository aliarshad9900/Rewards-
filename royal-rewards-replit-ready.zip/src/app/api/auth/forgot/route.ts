import { db } from "@/db";
import { users } from "@/db/schema";
import { AppError, audit, errorJson, notify, rateLimit } from "@/lib/core";
import { and, eq } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const ip = req.headers.get("x-forwarded-for") ?? "local";
    if (!rateLimit("forgot:" + ip, 5, 3600_000)) throw new AppError("Too many requests", 429);
    const { userNumber, username } = await req.json();
    const [u] = await db.select().from(users).where(and(eq(users.userNumber, String(userNumber ?? "").toUpperCase()), eq(users.username, String(username ?? ""))));
    if (u) {
      await notify(db, { forAdmin: true, title: "🔑 Password reset requested", body: `${u.userNumber} (${u.username}) requested a reset code`, link: `/admin/users?q=${u.userNumber}` });
      await audit(u.userNumber, "password_reset_requested", "");
    }
    return Response.json({ ok: true, message: "If the details match an account, an administrator will verify your identity and provide a one-time reset code." });
  } catch (e) { return errorJson(e); }
}
