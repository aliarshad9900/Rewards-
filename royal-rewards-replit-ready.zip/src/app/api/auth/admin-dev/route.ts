import crypto from "crypto";
import { db } from "@/db";
import { admins } from "@/db/schema";
import { createSession, OWNER_EMAIL } from "@/lib/auth";
import { AppError, audit, errorJson, rateLimit } from "@/lib/core";
import { eq } from "drizzle-orm";

// DEV/TESTING ONLY: enabled only if ADMIN_DEV_LOGIN_SECRET is set on the server.
export async function POST(req: Request) {
  try {
    const secret = process.env.ADMIN_DEV_LOGIN_SECRET;
    if (!secret || secret.length < 12) throw new AppError("Developer login disabled", 404);
    if (!rateLimit("devlogin", 5, 900_000)) throw new AppError("Too many attempts", 429);
    const { key } = await req.json();
    const a1 = Buffer.from(String(key ?? "")), a2 = Buffer.from(secret);
    if (a1.length !== a2.length || !crypto.timingSafeEqual(a1, a2)) throw new AppError("Invalid key", 401);
    let [a] = await db.select().from(admins).where(eq(admins.email, OWNER_EMAIL));
    if (!a) [a] = await db.insert(admins).values({ email: OWNER_EMAIL, name: "Owner", role: "owner" }).returning();
    await createSession("admin", a.id);
    await audit(OWNER_EMAIL, "admin_dev_login", "developer secret used");
    return Response.json({ ok: true });
  } catch (e) { return errorJson(e); }
}
