import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession, verifyPassword } from "@/lib/auth";
import { AppError, audit, errorJson, rateLimit } from "@/lib/core";
import { eq } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const ip = req.headers.get("x-forwarded-for") ?? "local";
    const { userNumber, password } = await req.json();
    const num = String(userNumber ?? "").trim().toUpperCase();
    if (!rateLimit("login:" + ip, 20, 900_000) || !rateLimit("login:" + num, 8, 900_000)) throw new AppError("Too many login attempts. Try again in 15 minutes.", 429);
    const [u] = await db.select().from(users).where(eq(users.userNumber, num));
    if (!u || !verifyPassword(String(password ?? ""), u.passwordHash)) throw new AppError("Invalid User Number or password", 401);
    if (u.status !== "active") throw new AppError("This account is suspended. Contact support.", 403);
    await createSession("user", u.id);
    await db.update(users).set({ lastActiveAt: new Date() }).where(eq(users.id, u.id));
    await audit(u.userNumber, "login", "");
    return Response.json({ ok: true });
  } catch (e) { return errorJson(e); }
}
