import { destroySession } from "@/lib/auth";
export async function POST() { await destroySession("user"); return Response.json({ ok: true }); }
