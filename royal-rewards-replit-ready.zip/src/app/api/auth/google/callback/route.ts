import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { admins } from "@/db/schema";
import { createSession, OWNER_EMAIL } from "@/lib/auth";
import { audit } from "@/lib/core";
import { eq } from "drizzle-orm";

const fail = (req: NextRequest, m: string) => NextResponse.redirect(new URL("/admin/login?error=" + encodeURIComponent(m), req.url));

export async function GET(req: NextRequest) {
  const code = req.nextUrl.searchParams.get("code");
  const state = req.nextUrl.searchParams.get("state");
  const saved = req.cookies.get("rr_oauth_state")?.value;
  if (!code || !state || !saved || state !== saved) return fail(req, "Invalid OAuth state");
  const origin = process.env.APP_URL || req.nextUrl.origin;
  const tokRes = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ code, client_id: process.env.GOOGLE_CLIENT_ID ?? "", client_secret: process.env.GOOGLE_CLIENT_SECRET ?? "", redirect_uri: origin + "/api/auth/google/callback", grant_type: "authorization_code" }),
  });
  if (!tokRes.ok) return fail(req, "Google token exchange failed");
  const tok = await tokRes.json();
  // Verify identity server-side by asking Google directly with the access token
  const infoRes = await fetch("https://openidconnect.googleapis.com/v1/userinfo", { headers: { Authorization: `Bearer ${tok.access_token}` } });
  if (!infoRes.ok) return fail(req, "Could not verify Google account");
  const info = await infoRes.json();
  const email = String(info.email ?? "").toLowerCase();
  if (!email || info.email_verified !== true) return fail(req, "Google email not verified");
  let [a] = await db.select().from(admins).where(eq(admins.email, email));
  if (email === OWNER_EMAIL) {
    if (!a) [a] = await db.insert(admins).values({ email, name: info.name ?? "Owner", role: "owner", permissions: [] }).returning();
    else if (a.role !== "owner" || !a.active) [a] = await db.update(admins).set({ role: "owner", active: true }).where(eq(admins.id, a.id)).returning();
  }
  if (!a || !a.active) { await audit(email, "admin_login_denied", "not an administrator"); return fail(req, "This Google account is not an administrator"); }
  if (a.role === "owner" && email !== OWNER_EMAIL) return fail(req, "Invalid owner account");
  if (info.name && a.name !== info.name) await db.update(admins).set({ name: info.name }).where(eq(admins.id, a.id));
  await createSession("admin", a.id);
  await audit(email, "admin_login", a.role);
  const res = NextResponse.redirect(new URL("/admin", req.url));
  res.cookies.delete("rr_oauth_state");
  return res;
}
