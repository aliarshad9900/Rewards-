import crypto from "crypto";
import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest) {
  const clientId = process.env.GOOGLE_CLIENT_ID;
  if (!clientId) return NextResponse.redirect(new URL("/admin/login?error=Google+OAuth+is+not+configured+(GOOGLE_CLIENT_ID)", req.url));
  const origin = process.env.APP_URL || req.nextUrl.origin;
  const state = crypto.randomBytes(24).toString("hex");
  const u = new URL("https://accounts.google.com/o/oauth2/v2/auth");
  u.searchParams.set("client_id", clientId);
  u.searchParams.set("redirect_uri", origin + "/api/auth/google/callback");
  u.searchParams.set("response_type", "code");
  u.searchParams.set("scope", "openid email profile");
  u.searchParams.set("state", state);
  u.searchParams.set("prompt", "select_account");
  const res = NextResponse.redirect(u);
  res.cookies.set("rr_oauth_state", state, { httpOnly: true, sameSite: "lax", path: "/", maxAge: 600, secure: origin.startsWith("https") });
  return res;
}
