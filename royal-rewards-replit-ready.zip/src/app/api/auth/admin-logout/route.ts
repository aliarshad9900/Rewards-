import { destroySession } from "@/lib/auth";
export async function POST() { await destroySession("admin"); return Response.json({ ok: true }); }
