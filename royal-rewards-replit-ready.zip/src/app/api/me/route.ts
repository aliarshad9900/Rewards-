import { db } from "@/db";
import { notifications } from "@/db/schema";
import { apiUser } from "@/lib/auth";
import { and, eq, sql } from "drizzle-orm";

export async function GET() {
  const u = await apiUser();
  if (!u) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const [{ c }] = await db.select({ c: sql<number>`count(*)::int` }).from(notifications).where(and(eq(notifications.userId, u.user.id), eq(notifications.read, false)));
  return Response.json({ userNumber: u.user.userNumber, balance: u.wallet.available, unread: c });
}
