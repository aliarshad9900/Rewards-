import { db } from "@/db";
import { profiles, sessions, users } from "@/db/schema";
import { apiUser, hashPassword, verifyPassword } from "@/lib/auth";
import { AppError, audit, errorJson, sanitize } from "@/lib/core";
import { and, eq, ne } from "drizzle-orm";

const AVATARS = ["👑", "🦁", "🐉", "🗡️", "🛡️", "💎", "🏰", "🔮", "🐰", "🦅"];
export async function POST(req: Request) {
  try {
    const u = await apiUser(); if (!u) throw new AppError("Unauthorized", 401);
    const b = await req.json();
    if (b.action === "profile") {
      const avatar = AVATARS.includes(b.avatar) ? b.avatar : "👑";
      await db.update(profiles).set({ displayName: sanitize(b.displayName, 30) || u.user.username, avatar, bio: sanitize(b.bio, 200) }).where(eq(profiles.userId, u.user.id));
    } else if (b.action === "password") {
      if (!verifyPassword(String(b.current ?? ""), u.user.passwordHash)) throw new AppError("Current password incorrect");
      if (typeof b.next !== "string" || b.next.length < 8) throw new AppError("New password must be at least 8 characters");
      await db.update(users).set({ passwordHash: hashPassword(b.next) }).where(eq(users.id, u.user.id));
      await audit(u.user.userNumber, "password_changed", "");
    } else if (b.action === "logout_all") {
      await db.delete(sessions).where(and(eq(sessions.userId, u.user.id), ne(sessions.id, "")));
    } else throw new AppError("Invalid action");
    return Response.json({ ok: true });
  } catch (e) { return errorJson(e); }
}
